# Add project specific ProGuard rules here.
# Room, Compose and kotlinx.serialization all ship consumer rules, so this
# file is intentionally minimal.
-keepattributes *Annotation*
