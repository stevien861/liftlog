package com.stevie.liftlog.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.recommendation.WarmupCalculator

/** Renders nothing when the working weight is too close to the bar for a warm-up ramp to make sense. */
@Composable
fun WarmupSuggestionCard(workingWeightKg: Double, barWeightKg: Double, modifier: Modifier = Modifier) {
    val sets = WarmupCalculator.suggest(workingWeightKg, barWeightKg)
    if (sets.isEmpty()) return

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Suggested warm-up", style = MaterialTheme.typography.titleMedium)
            sets.forEachIndexed { index, set ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${index + 1}. ${formatKg(set.weightKg)}kg x ${set.reps} reps",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
