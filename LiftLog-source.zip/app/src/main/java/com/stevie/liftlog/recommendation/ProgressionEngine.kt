package com.stevie.liftlog.recommendation

import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.SetEntryEntity
import kotlin.math.round

/**
 * What the engine is telling the user to do next session for a given
 * exercise.
 */
enum class RecommendationAction {
    INCREASE,
    HOLD,
    DECREASE,
    INSUFFICIENT_DATA
}

data class Recommendation(
    val action: RecommendationAction,
    /** The weight (kg) to use next session. Null only for INSUFFICIENT_DATA. */
    val suggestedWeightKg: Double?,
    /** The weight actually used in the last logged session, for display. Null only for INSUFFICIENT_DATA. */
    val lastWorkingWeightKg: Double?,
    val rationale: String
)

/**
 * Simple, transparent progressive-overload logic:
 *
 *  1. Look at the most recent logged session for the exercise. The
 *     "working weight" for that session is the heaviest weight used in it
 *     (lighter warm-up sets below that weight are ignored).
 *  2. If EVERY working set met or beat the top of the exercise's target rep
 *     range -> recommend increasing the weight by the exercise's configured
 *     increment next time. That's the reward for progressive overload.
 *  3. If any working set fell short of the bottom of the rep range, and the
 *     previous session *at the same weight* also fell short -> the weight has
 *     been too heavy for two sessions running, so recommend a ~10% deload to
 *     let reps (and form) recover.
 *  4. If it's only the first miss at this weight, or reps landed inside the
 *     target range without reaching the top -> hold the same weight and keep
 *     pushing for more reps before adding load.
 *  5. No logged sessions yet -> INSUFFICIENT_DATA.
 *
 * This mirrors standard beginner/intermediate strength programming (e.g.
 * Starting Strength / StrongLifts-style linear progression): add weight on
 * success, repeat on a partial miss, deload on a repeated miss.
 */
object ProgressionEngine {

    fun recommend(exercise: ExerciseEntity, history: List<SetEntryEntity>): Recommendation {
        val sessions = groupIntoSessionsDescending(history)

        val latest = sessions.getOrNull(0)
            ?: return Recommendation(
                action = RecommendationAction.INSUFFICIENT_DATA,
                suggestedWeightKg = null,
                lastWorkingWeightKg = null,
                rationale = "Log a session for ${exercise.name} to get a weight recommendation."
            )

        val latestWorkingWeight = latest.sets.maxOf { it.weightKg }
        val latestWorkingSets = latest.sets.filter { it.weightKg.approxEquals(latestWorkingWeight) }

        val repLow = exercise.targetRepRangeLow
        val repHigh = exercise.targetRepRangeHigh

        val allHitTop = latestWorkingSets.all { it.reps >= repHigh }
        val anyBelowLow = latestWorkingSets.any { it.reps < repLow }

        if (allHitTop) {
            val next = roundToNearestHalf(latestWorkingWeight + exercise.weightIncrementKg)
            return Recommendation(
                action = RecommendationAction.INCREASE,
                suggestedWeightKg = next,
                lastWorkingWeightKg = latestWorkingWeight,
                rationale = "You hit $repHigh+ reps on all ${latestWorkingSets.size} working set(s) at " +
                    "${latestWorkingWeight.formatKg()}kg last time. Add weight - try ${next.formatKg()}kg next session."
            )
        }

        if (anyBelowLow) {
            val previous = sessions.getOrNull(1)
            val previousMissedAtSameWeight = previous != null && run {
                val prevWorkingWeight = previous.sets.maxOf { it.weightKg }
                if (!prevWorkingWeight.approxEquals(latestWorkingWeight)) return@run false
                val prevWorkingSets = previous.sets.filter { it.weightKg.approxEquals(prevWorkingWeight) }
                prevWorkingSets.any { it.reps < repLow }
            }

            return if (previousMissedAtSameWeight) {
                val deload = roundToNearestHalf(latestWorkingWeight * 0.9)
                Recommendation(
                    action = RecommendationAction.DECREASE,
                    suggestedWeightKg = deload,
                    lastWorkingWeightKg = latestWorkingWeight,
                    rationale = "You've missed $repLow reps on a working set two sessions in a row at " +
                        "${latestWorkingWeight.formatKg()}kg. Drop to ${deload.formatKg()}kg next session to " +
                        "rebuild reps before pushing weight again."
                )
            } else {
                Recommendation(
                    action = RecommendationAction.HOLD,
                    suggestedWeightKg = latestWorkingWeight,
                    lastWorkingWeightKg = latestWorkingWeight,
                    rationale = "You missed $repLow reps on a working set at ${latestWorkingWeight.formatKg()}kg " +
                        "last time. Repeat ${latestWorkingWeight.formatKg()}kg next session before changing the weight."
                )
            }
        }

        // Reps landed inside the target range without reaching the top.
        return Recommendation(
            action = RecommendationAction.HOLD,
            suggestedWeightKg = latestWorkingWeight,
            lastWorkingWeightKg = latestWorkingWeight,
            rationale = "You're inside the $repLow-$repHigh rep target at ${latestWorkingWeight.formatKg()}kg " +
                "but haven't hit the top yet. Stay at ${latestWorkingWeight.formatKg()}kg and aim for more reps."
        )
    }

    private data class Session(val dateEpochDay: Long, val sets: List<SetEntryEntity>)

    private fun groupIntoSessionsDescending(history: List<SetEntryEntity>): List<Session> =
        history.groupBy { it.dateEpochDay }
            .map { (date, sets) -> Session(date, sets) }
            .sortedByDescending { it.dateEpochDay }

    private fun Double.approxEquals(other: Double, epsilon: Double = 0.01): Boolean =
        kotlin.math.abs(this - other) < epsilon

    private fun roundToNearestHalf(value: Double): Double = round(value * 2.0) / 2.0

    private fun Double.formatKg(): String =
        if (this == round(this)) this.toInt().toString() else this.toString()
}
