package com.stevie.liftlog.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.recommendation.PlateCalculator

@Composable
fun PlateCalculatorDialog(
    targetWeightKg: Double,
    barWeightKg: Double,
    onDismiss: () -> Unit
) {
    val breakdown = PlateCalculator.calculate(targetWeightKg, barWeightKg)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Plate calculator") },
        text = {
            Column {
                Text("${formatKg(breakdown.barWeightKg)}kg bar", style = MaterialTheme.typography.bodyLarge)

                if (breakdown.platesPerSide.isEmpty()) {
                    Text(
                        "Just the bar - no plates needed for ${formatKg(targetWeightKg)}kg.",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                } else {
                    Text(
                        "Load each side, heaviest first:",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    breakdown.platesPerSide.forEach { plate ->
                        Text(
                            "• ${formatKg(plate)}kg",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 4.dp, start = 8.dp)
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                Text("Total: ${formatKg(breakdown.achievedTotalKg)}kg", style = MaterialTheme.typography.titleMedium)

                if (!breakdown.isExact) {
                    Text(
                        "Closest you can load with standard plates - exact ${formatKg(targetWeightKg)}kg isn't " +
                            "possible with 1.25kg smallest plates.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("Done") }
        }
    )
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
