package com.stevie.liftlog.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.ui.components.categoryColor
import com.stevie.liftlog.ui.components.categoryIcon

/** First-run welcome flow - a single scrollable page rather than a swipeable pager, to keep this simple and safe. */
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Text("Welcome to LiftLog", style = MaterialTheme.typography.titleLarge)
        Text(
            "Your training partner for tracking sets, smashing PRs, and knowing exactly when to add weight.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp)
        )

        Spacer(modifier = Modifier.height(32.dp))
        Text("Six muscle groups, covered", style = MaterialTheme.typography.titleMedium)
        Text(
            "Every exercise is filed under Back, Chest, Arms, Shoulders, Forearms or Legs, with common " +
                "exercises already pre-loaded so you're not starting from a blank screen.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )
        MuscleCategory.entries.chunked(3).forEach { row ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { category ->
                    Card(modifier = Modifier.weight(1f)) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(categoryIcon(category), contentDescription = null, tint = categoryColor(category))
                            Text(
                                category.displayName,
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text("Know when to add weight", style = MaterialTheme.typography.titleMedium)
        Text(
            "Hit the top of your rep range and LiftLog tells you to add weight next time. Miss it twice in " +
                "a row and it suggests a deload. No guesswork.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))
        Text("Guided workouts, built in", style = MaterialTheme.typography.titleMedium)
        Text(
            "Start a routine, log your sets, and let LiftLog run your rest timer between them - plus " +
                "warm-up suggestions, a plate calculator, and a streak to keep you honest.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))
        Button(onClick = onFinish, modifier = Modifier.fillMaxWidth()) {
            Text("Let's go")
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}
