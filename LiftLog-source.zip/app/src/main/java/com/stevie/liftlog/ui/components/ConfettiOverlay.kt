package com.stevie.liftlog.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * A short, one-shot confetti burst played whenever [trigger] becomes a new, non-null value (an
 * achievement, a broken record, a finished workout, ...). Purely decorative, drawn with Canvas -
 * no external animation library or bundled asset - and resets automatically the next time
 * [trigger] changes to a different value.
 */
@Composable
fun ConfettiOverlay(trigger: Any?, modifier: Modifier = Modifier) {
    if (trigger == null) return

    val progress = remember(trigger) { Animatable(0f) }
    val particles = remember(trigger) { List(36) { ConfettiParticle.random() } }

    LaunchedEffect(trigger) {
        progress.snapTo(0f)
        progress.animateTo(1f, animationSpec = tween(durationMillis = 1600, easing = LinearEasing))
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val t = progress.value
        if (t <= 0f) return@Canvas
        particles.forEach { particle ->
            val startY = particle.startYFraction * size.height
            val travel = size.height * 1.3f * particle.fallSpeedFactor
            val y = startY + t * travel
            if (y < -20f || y > size.height + 20f) return@forEach
            val baseX = particle.startXFraction * size.width
            val x = baseX + sin(t * particle.swayFrequency * 2f * PI.toFloat() + particle.phase) * particle.swayAmplitude
            drawRect(
                color = particle.color,
                topLeft = Offset(x - particle.sizePx / 2f, y - particle.sizePx / 2f),
                size = Size(particle.sizePx, particle.sizePx)
            )
        }
    }
}

private data class ConfettiParticle(
    val startXFraction: Float,
    val startYFraction: Float,
    val fallSpeedFactor: Float,
    val swayAmplitude: Float,
    val swayFrequency: Float,
    val phase: Float,
    val sizePx: Float,
    val color: Color
) {
    companion object {
        private val palette = listOf(
            Color(0xFFFFC107), Color(0xFFFF5252), Color(0xFF4CAF50),
            Color(0xFF448AFF), Color(0xFFAB47BC), Color(0xFF26C6DA)
        )

        fun random(): ConfettiParticle = ConfettiParticle(
            startXFraction = Random.nextFloat(),
            startYFraction = -0.3f - Random.nextFloat() * 0.2f,
            fallSpeedFactor = 0.8f + Random.nextFloat() * 0.6f,
            swayAmplitude = 8f + Random.nextFloat() * 16f,
            swayFrequency = 1f + Random.nextFloat() * 2f,
            phase = Random.nextFloat() * 6.28f,
            sizePx = 8f + Random.nextFloat() * 8f,
            color = palette[Random.nextInt(palette.size)]
        )
    }
}
