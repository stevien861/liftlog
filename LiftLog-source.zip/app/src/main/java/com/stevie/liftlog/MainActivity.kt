package com.stevie.liftlog

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.stevie.liftlog.ui.navigation.LiftLogNavHost
import com.stevie.liftlog.ui.theme.LiftLogTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LiftLogTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    LiftLogNavHost(repository = (application as LiftLogApplication).repository)
                }
            }
        }
    }
}
