package com.stevie.liftlog.data

/**
 * A starter list of common exercises per category so the app isn't empty on
 * first launch. All of these are [ExerciseEntity.isCustom] = false; the user
 * can rename, retarget, or delete them freely, and can add their own on top
 * from any category screen.
 *
 * Rep ranges and weight increments are reasonable strength/hypertrophy
 * defaults (heavy compound lifts: low reps, bigger jumps; isolation and
 * small joints: higher reps, smaller jumps) and are editable per exercise.
 */
object DefaultExercises {

    fun seed(): List<ExerciseEntity> = listOf(
        // Back
        ExerciseEntity(name = "Deadlift", category = MuscleCategory.BACK, targetRepRangeLow = 4, targetRepRangeHigh = 6, weightIncrementKg = 5.0, isCustom = false),
        ExerciseEntity(name = "Barbell Row", category = MuscleCategory.BACK, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Lat Pulldown", category = MuscleCategory.BACK, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Pull-Up", category = MuscleCategory.BACK, targetRepRangeLow = 5, targetRepRangeHigh = 10, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Seated Cable Row", category = MuscleCategory.BACK, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 2.5, isCustom = false),

        // Chest
        ExerciseEntity(name = "Barbell Bench Press", category = MuscleCategory.CHEST, targetRepRangeLow = 5, targetRepRangeHigh = 8, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Incline Dumbbell Press", category = MuscleCategory.CHEST, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 2.0, isCustom = false),
        ExerciseEntity(name = "Push-Up", category = MuscleCategory.CHEST, targetRepRangeLow = 10, targetRepRangeHigh = 20, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Cable Fly", category = MuscleCategory.CHEST, targetRepRangeLow = 10, targetRepRangeHigh = 15, weightIncrementKg = 1.25, isCustom = false),

        // Arms
        ExerciseEntity(name = "Barbell Bicep Curl", category = MuscleCategory.ARMS, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 1.25, isCustom = false),
        ExerciseEntity(name = "Hammer Curl", category = MuscleCategory.ARMS, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 1.25, isCustom = false),
        ExerciseEntity(name = "Tricep Pushdown", category = MuscleCategory.ARMS, targetRepRangeLow = 10, targetRepRangeHigh = 15, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Skull Crusher", category = MuscleCategory.ARMS, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 2.0, isCustom = false),

        // Shoulders
        ExerciseEntity(name = "Overhead Press", category = MuscleCategory.SHOULDERS, targetRepRangeLow = 5, targetRepRangeHigh = 8, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Lateral Raise", category = MuscleCategory.SHOULDERS, targetRepRangeLow = 10, targetRepRangeHigh = 15, weightIncrementKg = 1.0, isCustom = false),
        ExerciseEntity(name = "Rear Delt Fly", category = MuscleCategory.SHOULDERS, targetRepRangeLow = 10, targetRepRangeHigh = 15, weightIncrementKg = 1.0, isCustom = false),
        ExerciseEntity(name = "Face Pull", category = MuscleCategory.SHOULDERS, targetRepRangeLow = 12, targetRepRangeHigh = 15, weightIncrementKg = 2.5, isCustom = false),

        // Forearms
        ExerciseEntity(name = "Wrist Curl", category = MuscleCategory.FOREARMS, targetRepRangeLow = 12, targetRepRangeHigh = 20, weightIncrementKg = 1.25, isCustom = false),
        ExerciseEntity(name = "Reverse Wrist Curl", category = MuscleCategory.FOREARMS, targetRepRangeLow = 12, targetRepRangeHigh = 20, weightIncrementKg = 1.25, isCustom = false),
        ExerciseEntity(name = "Reverse Curl", category = MuscleCategory.FOREARMS, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 1.25, isCustom = false),

        // Legs
        ExerciseEntity(name = "Back Squat", category = MuscleCategory.LEGS, targetRepRangeLow = 4, targetRepRangeHigh = 6, weightIncrementKg = 5.0, isCustom = false),
        ExerciseEntity(name = "Leg Press", category = MuscleCategory.LEGS, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 5.0, isCustom = false),
        ExerciseEntity(name = "Romanian Deadlift", category = MuscleCategory.LEGS, targetRepRangeLow = 8, targetRepRangeHigh = 12, weightIncrementKg = 5.0, isCustom = false),
        ExerciseEntity(name = "Walking Lunge", category = MuscleCategory.LEGS, targetRepRangeLow = 10, targetRepRangeHigh = 15, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Leg Extension", category = MuscleCategory.LEGS, targetRepRangeLow = 10, targetRepRangeHigh = 15, weightIncrementKg = 2.5, isCustom = false),
        ExerciseEntity(name = "Calf Raise", category = MuscleCategory.LEGS, targetRepRangeLow = 12, targetRepRangeHigh = 20, weightIncrementKg = 2.5, isCustom = false)
    )
}
