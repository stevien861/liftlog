package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.RoutineEntity
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.stats.WorkoutStats
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

/** Backs the Home dashboard: a quick snapshot rather than the full detail on the Stats screen. */
class HomeViewModel(repository: WorkoutRepository) : ViewModel() {

    val exercises: StateFlow<List<ExerciseEntity>> = repository.observeExercises()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val routines: StateFlow<List<RoutineEntity>> = repository.observeRoutines()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val today = LocalDate.now().toEpochDay()

    val streakDays: StateFlow<Int> = repository.observeWorkoutDates()
        .map { dates -> WorkoutStats.computeStreakDays(dates.toSet(), today) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val thisWeekVolumeKg: StateFlow<Double> = repository.observeAllSets()
        .map { sets -> WorkoutStats.volumeInLastNDays(sets, today, 7) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)
}
