package com.stevie.liftlog.recommendation

import kotlin.math.abs

/**
 * The result of [PlateCalculator.calculate]: which plates to slide onto EACH side of the bar, in
 * the order you'd normally load them (heaviest first, closest to the bar).
 */
data class PlateBreakdown(
    val barWeightKg: Double,
    val platesPerSide: List<Double>,
    val achievedTotalKg: Double,
    val targetWeightKg: Double
) {
    /** False when the target can't be hit exactly with the available plates (e.g. odd numbers with only 1.25kg smallest plates). */
    val isExact: Boolean get() = abs(achievedTotalKg - targetWeightKg) < 0.01
}

/**
 * Turns "I want to lift 100kg" into "20kg bar + 25kg + 15kg per side", the way you'd actually load
 * a barbell in a gym: heaviest plates first, working down to the smallest, on each side.
 */
object PlateCalculator {

    /** Standard kg plate sizes found in most gyms, heaviest first. */
    val STANDARD_PLATES_KG = listOf(25.0, 20.0, 15.0, 10.0, 5.0, 2.5, 1.25)

    /** Standard Olympic barbell weight. */
    const val DEFAULT_BAR_WEIGHT_KG = 20.0

    fun calculate(
        targetWeightKg: Double,
        barWeightKg: Double = DEFAULT_BAR_WEIGHT_KG,
        availablePlatesKg: List<Double> = STANDARD_PLATES_KG
    ): PlateBreakdown {
        if (targetWeightKg <= barWeightKg) {
            return PlateBreakdown(barWeightKg, emptyList(), barWeightKg, targetWeightKg)
        }

        var remainingPerSide = (targetWeightKg - barWeightKg) / 2.0
        val plates = mutableListOf<Double>()
        for (plate in availablePlatesKg.sortedDescending()) {
            while (remainingPerSide + 1e-6 >= plate) {
                plates += plate
                remainingPerSide -= plate
            }
        }

        val achieved = barWeightKg + plates.sumOf { it } * 2.0
        return PlateBreakdown(barWeightKg, plates, achieved, targetWeightKg)
    }
}
