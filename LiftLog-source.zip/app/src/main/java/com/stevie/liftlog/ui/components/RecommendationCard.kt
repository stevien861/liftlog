package com.stevie.liftlog.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.recommendation.Recommendation
import com.stevie.liftlog.recommendation.RecommendationAction
import com.stevie.liftlog.ui.theme.LiftLogColors

@Composable
fun RecommendationCard(recommendation: Recommendation?, modifier: Modifier = Modifier) {
    if (recommendation == null || recommendation.action == RecommendationAction.INSUFFICIENT_DATA) {
        Card(modifier = modifier.fillMaxWidth(), colors = CardDefaults.cardColors()) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text("No recommendation yet", style = MaterialTheme.typography.labelLarge)
                    Text(
                        recommendation?.rationale ?: "Log a session to get a weight recommendation.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        return
    }

    val (accentColor, icon, headline) = when (recommendation.action) {
        RecommendationAction.INCREASE -> Triple(
            LiftLogColors.increase,
            Icons.Filled.KeyboardArrowUp,
            "Add weight next session"
        )
        RecommendationAction.DECREASE -> Triple(
            LiftLogColors.decrease,
            Icons.Filled.KeyboardArrowDown,
            "Drop the weight next session"
        )
        RecommendationAction.HOLD -> Triple(
            LiftLogColors.hold,
            Icons.Filled.Remove,
            "Repeat this weight"
        )
        RecommendationAction.INSUFFICIENT_DATA -> Triple(
            MaterialTheme.colorScheme.onSurfaceVariant,
            Icons.Filled.Info,
            "No recommendation yet"
        )
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = accentColor.copy(alpha = 0.12f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(28.dp))
                Column(modifier = Modifier.padding(start = 10.dp)) {
                    Text(headline, style = MaterialTheme.typography.titleMedium, color = accentColor)
                    recommendation.suggestedWeightKg?.let {
                        Text(
                            "Suggested: ${formatKg(it)} kg",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
            Text(
                recommendation.rationale,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(top = 8.dp),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
