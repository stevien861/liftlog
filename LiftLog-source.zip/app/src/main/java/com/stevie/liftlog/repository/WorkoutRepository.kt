package com.stevie.liftlog.repository

import com.stevie.liftlog.data.AppDatabase
import com.stevie.liftlog.data.BodyWeightEntity
import com.stevie.liftlog.data.DefaultRoutines
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.data.RoutineEntity
import com.stevie.liftlog.data.RoutineExerciseEntity
import com.stevie.liftlog.data.SetEntryEntity
import com.stevie.liftlog.recommendation.ProgressionEngine
import com.stevie.liftlog.recommendation.Recommendation
import com.stevie.liftlog.stats.NewRecord
import com.stevie.liftlog.stats.PersonalRecords
import com.stevie.liftlog.util.ExportPayload
import com.stevie.liftlog.util.toEntity
import com.stevie.liftlog.util.toExported
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import java.time.LocalDate

enum class ImportMode { REPLACE_ALL, MERGE }

class WorkoutRepository(private val db: AppDatabase) {

    private val exerciseDao = db.exerciseDao()
    private val setDao = db.setDao()
    private val maintenanceDao = db.maintenanceDao()
    private val routineDao = db.routineDao()
    private val bodyWeightDao = db.bodyWeightDao()

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    // ---- Exercises -----------------------------------------------------

    fun observeExercises(): Flow<List<ExerciseEntity>> = exerciseDao.observeAll()

    fun observeExercisesByCategory(category: MuscleCategory): Flow<List<ExerciseEntity>> =
        exerciseDao.observeByCategory(category)

    fun observeExercise(exerciseId: Long): Flow<ExerciseEntity?> = exerciseDao.observeById(exerciseId)

    suspend fun getExercise(exerciseId: Long): ExerciseEntity? = exerciseDao.getById(exerciseId)

    suspend fun addExercise(
        name: String,
        category: MuscleCategory,
        repRangeLow: Int,
        repRangeHigh: Int,
        weightIncrementKg: Double,
        notes: String = ""
    ): Long = exerciseDao.insert(
        ExerciseEntity(
            name = name,
            category = category,
            targetRepRangeLow = repRangeLow,
            targetRepRangeHigh = repRangeHigh,
            weightIncrementKg = weightIncrementKg,
            isCustom = true,
            notes = notes
        )
    )

    suspend fun updateExercise(exercise: ExerciseEntity) = exerciseDao.update(exercise)

    /** Hides the exercise from lists but keeps its logged history intact. */
    suspend fun archiveExercise(exercise: ExerciseEntity) =
        exerciseDao.update(exercise.copy(isArchived = true))

    /** Permanently deletes the exercise AND (via cascade) every set logged against it. */
    suspend fun deleteExercisePermanently(exercise: ExerciseEntity) = exerciseDao.delete(exercise)

    /**
     * Inserts the built-in starter exercise list and default routines the very first time the app
     * runs. Routines are seeded second because they reference exercises by their real database
     * IDs, which only exist once [com.stevie.liftlog.data.DefaultExercises] has been inserted.
     */
    suspend fun ensureSeeded() {
        if (exerciseDao.count() == 0) {
            exerciseDao.insertAll(com.stevie.liftlog.data.DefaultExercises.seed())
        }
        if (routineDao.count() == 0) {
            DefaultRoutines.seed().forEachIndexed { routineIndex, template ->
                val exerciseIds = template.exerciseNamesInOrder.mapNotNull { exerciseDao.getByName(it)?.id }
                if (exerciseIds.isEmpty()) return@forEachIndexed
                val routineId = routineDao.insert(
                    RoutineEntity(name = template.name, isCustom = false, sortOrder = routineIndex)
                )
                routineDao.insertRoutineExercises(
                    exerciseIds.mapIndexed { order, exerciseId ->
                        RoutineExerciseEntity(routineId = routineId, exerciseId = exerciseId, sortOrder = order)
                    }
                )
            }
        }
    }

    // ---- Sets / logging --------------------------------------------------

    fun observeAllSets(): Flow<List<SetEntryEntity>> = setDao.observeAll()

    fun observeSetsForExercise(exerciseId: Long): Flow<List<SetEntryEntity>> =
        setDao.observeForExercise(exerciseId)

    fun observeSetsForExerciseOnDate(exerciseId: Long, date: LocalDate): Flow<List<SetEntryEntity>> =
        setDao.observeForExerciseOnDate(exerciseId, date.toEpochDay())

    fun observeWorkoutDates(): Flow<List<Long>> = setDao.observeWorkoutDates()

    suspend fun logSet(exerciseId: Long, date: LocalDate, weightKg: Double, reps: Int, notes: String = ""): Long {
        val epochDay = date.toEpochDay()
        val nextSetNumber = (setDao.maxSetNumber(exerciseId, epochDay) ?: 0) + 1
        return setDao.insert(
            SetEntryEntity(
                exerciseId = exerciseId,
                dateEpochDay = epochDay,
                setNumber = nextSetNumber,
                weightKg = weightKg,
                reps = reps,
                notes = notes
            )
        )
    }

    /**
     * Same as [logSet], but also reports whether the new set just broke an all-time personal
     * record for this exercise (heaviest weight ever, or best estimated 1-rep max ever) - see
     * [PersonalRecords.checkForNewRecords]. The "before" history is captured first so the new set
     * is never compared against itself.
     */
    suspend fun logSetAndCheckRecords(
        exerciseId: Long,
        date: LocalDate,
        weightKg: Double,
        reps: Int,
        notes: String = ""
    ): List<NewRecord> {
        val priorHistory = setDao.getForExerciseOnce(exerciseId)
        logSet(exerciseId, date, weightKg, reps, notes)
        val candidateSet = SetEntryEntity(
            exerciseId = exerciseId,
            dateEpochDay = date.toEpochDay(),
            setNumber = 0,
            weightKg = weightKg,
            reps = reps
        )
        return PersonalRecords.checkForNewRecords(priorHistory, candidateSet)
    }

    suspend fun updateSet(set: SetEntryEntity) = setDao.update(set)

    suspend fun deleteSet(set: SetEntryEntity) = setDao.delete(set)

    // ---- Recommendation ---------------------------------------------------

    /** Recomputes the progressive-overload recommendation whenever the exercise or its history changes. */
    fun observeRecommendation(exerciseId: Long): Flow<Recommendation?> =
        combine(
            exerciseDao.observeById(exerciseId),
            setDao.observeForExercise(exerciseId)
        ) { exercise, history ->
            exercise?.let { ProgressionEngine.recommend(it, history) }
        }

    // ---- Routines -----------------------------------------------------

    fun observeRoutines(): Flow<List<RoutineEntity>> = routineDao.observeAll()

    fun observeRoutine(routineId: Long): Flow<RoutineEntity?> = routineDao.observeById(routineId)

    fun observeRoutineExercises(routineId: Long): Flow<List<RoutineExerciseEntity>> =
        routineDao.observeExercisesForRoutine(routineId)

    /** Creates a routine with the given exercises, in the order given. */
    suspend fun createRoutine(name: String, exerciseIdsInOrder: List<Long>): Long {
        val routineId = routineDao.insert(RoutineEntity(name = name, isCustom = true, sortOrder = Int.MAX_VALUE))
        routineDao.insertRoutineExercises(
            exerciseIdsInOrder.mapIndexed { order, exerciseId ->
                RoutineExerciseEntity(routineId = routineId, exerciseId = exerciseId, sortOrder = order)
            }
        )
        return routineId
    }

    /** Replaces a routine's name and full exercise list/order in one go - what the routine editor's "Save" does. */
    suspend fun updateRoutine(routine: RoutineEntity, newName: String, exerciseIdsInOrder: List<Long>) {
        routineDao.update(routine.copy(name = newName))
        routineDao.clearRoutineExercises(routine.id)
        routineDao.insertRoutineExercises(
            exerciseIdsInOrder.mapIndexed { order, exerciseId ->
                RoutineExerciseEntity(routineId = routine.id, exerciseId = exerciseId, sortOrder = order)
            }
        )
    }

    suspend fun deleteRoutine(routine: RoutineEntity) = routineDao.delete(routine)

    // ---- Body weight -----------------------------------------------------

    fun observeBodyWeightHistory(): Flow<List<BodyWeightEntity>> = bodyWeightDao.observeAll()

    fun observeLatestBodyWeight(): Flow<BodyWeightEntity?> = bodyWeightDao.observeLatest()

    /** Logging again for a date that already has an entry replaces it (see [com.stevie.liftlog.data.BodyWeightDao]). */
    suspend fun logBodyWeight(date: LocalDate, weightKg: Double) {
        bodyWeightDao.insert(BodyWeightEntity(dateEpochDay = date.toEpochDay(), weightKg = weightKg))
    }

    suspend fun deleteBodyWeightEntry(entry: BodyWeightEntity) = bodyWeightDao.delete(entry)

    // ---- Export / import ---------------------------------------------------

    suspend fun exportToJson(): String {
        val exercises = exerciseDao.getAllOnce().map { it.toExported() }
        val sets = setDao.getAllOnce().map { it.toExported() }
        val routines = routineDao.getAllOnce().map { it.toExported() }
        val routineExercises = routineDao.getAllRoutineExercisesOnce().map { it.toExported() }
        val bodyWeightEntries = bodyWeightDao.getAllOnce().map { it.toExported() }
        val payload = ExportPayload(
            exportedAtEpochDay = LocalDate.now().toEpochDay(),
            exercises = exercises,
            sets = sets,
            routines = routines,
            routineExercises = routineExercises,
            bodyWeightEntries = bodyWeightEntries
        )
        return json.encodeToString(ExportPayload.serializer(), payload)
    }

    /**
     * @return the number of exercises and sets imported, or throws if the
     * JSON can't be parsed as a LiftLog export. Routines and body weight are
     * imported alongside them but aren't reflected in this count - it exists
     * for the on-screen "imported X exercises and Y sets" confirmation.
     */
    suspend fun importFromJson(jsonText: String, mode: ImportMode): Pair<Int, Int> {
        val payload = json.decodeFromString(ExportPayload.serializer(), jsonText)

        return when (mode) {
            ImportMode.REPLACE_ALL -> {
                setDao.deleteAll()
                maintenanceDao.deleteAllExercises()
                routineDao.deleteAll()
                bodyWeightDao.deleteAll()

                exerciseDao.insertAll(payload.exercises.map { it.toEntity() })
                setDao.insertAll(payload.sets.map { it.toEntity() })
                payload.bodyWeightEntries.forEach { bodyWeightDao.insert(it.toEntity()) }

                val routineIdRemap = HashMap<Long, Long>()
                payload.routines.forEach { exportedRoutine ->
                    val newId = routineDao.insert(exportedRoutine.toEntity(overrideId = 0))
                    routineIdRemap[exportedRoutine.id] = newId
                }
                val routineExercisesToInsert = payload.routineExercises.mapNotNull { exported ->
                    val newRoutineId = routineIdRemap[exported.routineId] ?: return@mapNotNull null
                    exported.toEntity(overrideId = 0, overrideRoutineId = newRoutineId)
                }
                routineDao.insertRoutineExercises(routineExercisesToInsert)

                payload.exercises.size to payload.sets.size
            }

            ImportMode.MERGE -> {
                val exerciseIdRemap = HashMap<Long, Long>()
                payload.exercises.forEach { exported ->
                    val newId = exerciseDao.insert(exported.toEntity(overrideId = 0))
                    exerciseIdRemap[exported.id] = newId
                }
                val setsToInsert = payload.sets.mapNotNull { exported ->
                    val newExerciseId = exerciseIdRemap[exported.exerciseId] ?: return@mapNotNull null
                    exported.toEntity(overrideId = 0, overrideExerciseId = newExerciseId)
                }
                setDao.insertAll(setsToInsert)

                payload.bodyWeightEntries.forEach { bodyWeightDao.insert(it.toEntity(overrideId = 0)) }

                val routineIdRemap = HashMap<Long, Long>()
                payload.routines.forEach { exportedRoutine ->
                    val newId = routineDao.insert(exportedRoutine.toEntity(overrideId = 0))
                    routineIdRemap[exportedRoutine.id] = newId
                }
                val routineExercisesToInsert = payload.routineExercises.mapNotNull { exported ->
                    val newRoutineId = routineIdRemap[exported.routineId] ?: return@mapNotNull null
                    val newExerciseId = exerciseIdRemap[exported.exerciseId] ?: return@mapNotNull null
                    exported.toEntity(overrideId = 0, overrideRoutineId = newRoutineId, overrideExerciseId = newExerciseId)
                }
                routineDao.insertRoutineExercises(routineExercisesToInsert)

                payload.exercises.size to setsToInsert.size
            }
        }
    }
}
