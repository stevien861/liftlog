package com.stevie.liftlog.repository

import com.stevie.liftlog.data.AppDatabase
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.data.SetEntryEntity
import com.stevie.liftlog.recommendation.ProgressionEngine
import com.stevie.liftlog.recommendation.Recommendation
import com.stevie.liftlog.util.ExportPayload
import com.stevie.liftlog.util.toEntity
import com.stevie.liftlog.util.toExported
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import java.time.LocalDate

enum class ImportMode { REPLACE_ALL, MERGE }

class WorkoutRepository(private val db: AppDatabase) {

    private val exerciseDao = db.exerciseDao()
    private val setDao = db.setDao()
    private val maintenanceDao = db.maintenanceDao()

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    // ---- Exercises -----------------------------------------------------

    fun observeExercises(): Flow<List<ExerciseEntity>> = exerciseDao.observeAll()

    fun observeExercisesByCategory(category: MuscleCategory): Flow<List<ExerciseEntity>> =
        exerciseDao.observeByCategory(category)

    fun observeExercise(exerciseId: Long): Flow<ExerciseEntity?> = exerciseDao.observeById(exerciseId)

    suspend fun getExercise(exerciseId: Long): ExerciseEntity? = exerciseDao.getById(exerciseId)

    suspend fun addExercise(
        name: String,
        category: MuscleCategory,
        repRangeLow: Int,
        repRangeHigh: Int,
        weightIncrementKg: Double,
        notes: String = ""
    ): Long = exerciseDao.insert(
        ExerciseEntity(
            name = name,
            category = category,
            targetRepRangeLow = repRangeLow,
            targetRepRangeHigh = repRangeHigh,
            weightIncrementKg = weightIncrementKg,
            isCustom = true,
            notes = notes
        )
    )

    suspend fun updateExercise(exercise: ExerciseEntity) = exerciseDao.update(exercise)

    /** Hides the exercise from lists but keeps its logged history intact. */
    suspend fun archiveExercise(exercise: ExerciseEntity) =
        exerciseDao.update(exercise.copy(isArchived = true))

    /** Permanently deletes the exercise AND (via cascade) every set logged against it. */
    suspend fun deleteExercisePermanently(exercise: ExerciseEntity) = exerciseDao.delete(exercise)

    /** Inserts the built-in starter exercise list the very first time the app runs. */
    suspend fun ensureSeeded() {
        if (exerciseDao.count() == 0) {
            exerciseDao.insertAll(com.stevie.liftlog.data.DefaultExercises.seed())
        }
    }

    // ---- Sets / logging --------------------------------------------------

    fun observeSetsForExercise(exerciseId: Long): Flow<List<SetEntryEntity>> =
        setDao.observeForExercise(exerciseId)

    fun observeSetsForExerciseOnDate(exerciseId: Long, date: LocalDate): Flow<List<SetEntryEntity>> =
        setDao.observeForExerciseOnDate(exerciseId, date.toEpochDay())

    suspend fun logSet(exerciseId: Long, date: LocalDate, weightKg: Double, reps: Int, notes: String = ""): Long {
        val epochDay = date.toEpochDay()
        val nextSetNumber = (setDao.maxSetNumber(exerciseId, epochDay) ?: 0) + 1
        return setDao.insert(
            SetEntryEntity(
                exerciseId = exerciseId,
                dateEpochDay = epochDay,
                setNumber = nextSetNumber,
                weightKg = weightKg,
                reps = reps,
                notes = notes
            )
        )
    }

    suspend fun updateSet(set: SetEntryEntity) = setDao.update(set)

    suspend fun deleteSet(set: SetEntryEntity) = setDao.delete(set)

    // ---- Recommendation ---------------------------------------------------

    /** Recomputes the progressive-overload recommendation whenever the exercise or its history changes. */
    fun observeRecommendation(exerciseId: Long): Flow<Recommendation?> =
        combine(
            exerciseDao.observeById(exerciseId),
            setDao.observeForExercise(exerciseId)
        ) { exercise, history ->
            exercise?.let { ProgressionEngine.recommend(it, history) }
        }

    // ---- Export / import ---------------------------------------------------

    suspend fun exportToJson(): String {
        val exercises = exerciseDao.getAllOnce().map { it.toExported() }
        val sets = setDao.getAllOnce().map { it.toExported() }
        val payload = ExportPayload(
            exportedAtEpochDay = LocalDate.now().toEpochDay(),
            exercises = exercises,
            sets = sets
        )
        return json.encodeToString(ExportPayload.serializer(), payload)
    }

    /**
     * @return the number of exercises and sets imported, or throws if the
     * JSON can't be parsed as a LiftLog export.
     */
    suspend fun importFromJson(jsonText: String, mode: ImportMode): Pair<Int, Int> {
        val payload = json.decodeFromString(ExportPayload.serializer(), jsonText)

        return when (mode) {
            ImportMode.REPLACE_ALL -> {
                setDao.deleteAll()
                maintenanceDao.deleteAllExercises()
                exerciseDao.insertAll(payload.exercises.map { it.toEntity() })
                setDao.insertAll(payload.sets.map { it.toEntity() })
                payload.exercises.size to payload.sets.size
            }

            ImportMode.MERGE -> {
                val idRemap = HashMap<Long, Long>()
                payload.exercises.forEach { exported ->
                    val newId = exerciseDao.insert(exported.toEntity(overrideId = 0))
                    idRemap[exported.id] = newId
                }
                val setsToInsert = payload.sets.mapNotNull { exported ->
                    val newExerciseId = idRemap[exported.exerciseId] ?: return@mapNotNull null
                    exported.toEntity(overrideId = 0, overrideExerciseId = newExerciseId)
                }
                setDao.insertAll(setsToInsert)
                payload.exercises.size to setsToInsert.size
            }
        }
    }
}
