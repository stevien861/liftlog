package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.repository.ImportMode
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.util.AppPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface SettingsMessage {
    data class ExportReady(val json: String) : SettingsMessage
    data class ImportSucceeded(val exerciseCount: Int, val setCount: Int) : SettingsMessage
    data class Error(val message: String) : SettingsMessage
}

class SettingsViewModel(
    private val repository: WorkoutRepository,
    private val preferences: AppPreferences
) : ViewModel() {

    private val _lastMessage = MutableStateFlow<SettingsMessage?>(null)
    val lastMessage: StateFlow<SettingsMessage?> = _lastMessage.asStateFlow()

    private val _restTimerSeconds = MutableStateFlow(preferences.restTimerSeconds)
    val restTimerSeconds: StateFlow<Int> = _restTimerSeconds.asStateFlow()

    private val _barWeightKg = MutableStateFlow(preferences.barWeightKg.toDouble())
    val barWeightKg: StateFlow<Double> = _barWeightKg.asStateFlow()

    fun updateRestTimerSeconds(seconds: Int) {
        if (seconds <= 0) return
        preferences.restTimerSeconds = seconds
        _restTimerSeconds.value = seconds
    }

    fun updateBarWeightKg(kg: Double) {
        if (kg <= 0) return
        preferences.barWeightKg = kg.toFloat()
        _barWeightKg.value = kg
    }

    fun exportData(onReady: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val json = repository.exportToJson()
                _lastMessage.value = SettingsMessage.ExportReady(json)
                onReady(json)
            } catch (t: Throwable) {
                _lastMessage.value = SettingsMessage.Error("Export failed: ${t.message ?: "unknown error"}")
            }
        }
    }

    fun importData(jsonText: String, mode: ImportMode) {
        viewModelScope.launch {
            try {
                val (exerciseCount, setCount) = repository.importFromJson(jsonText, mode)
                _lastMessage.value = SettingsMessage.ImportSucceeded(exerciseCount, setCount)
            } catch (t: Throwable) {
                _lastMessage.value =
                    SettingsMessage.Error("Import failed: this doesn't look like a valid LiftLog backup file (${t.message ?: "parse error"}).")
            }
        }
    }

    fun clearMessage() {
        _lastMessage.value = null
    }
}
