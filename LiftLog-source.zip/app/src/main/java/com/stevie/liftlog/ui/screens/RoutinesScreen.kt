package com.stevie.liftlog.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.data.RoutineEntity
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.BottomDestination
import com.stevie.liftlog.ui.components.LiftLogBottomBar
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory
import com.stevie.liftlog.viewmodel.RoutinesViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutinesScreen(
    repository: WorkoutRepository,
    onStartRoutine: (Long) -> Unit,
    onEditRoutine: (Long) -> Unit,
    onCreateRoutine: () -> Unit,
    onNavigate: (BottomDestination) -> Unit
) {
    val viewModel: RoutinesViewModel = viewModel(factory = LiftLogViewModelFactory(repository))
    val routines by viewModel.routines.collectAsStateWithLifecycle()
    var pendingDelete by remember { mutableStateOf<RoutineEntity?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Routines") }) },
        bottomBar = { LiftLogBottomBar(current = BottomDestination.ROUTINES, onSelect = onNavigate) },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreateRoutine) {
                Icon(Icons.Filled.Add, contentDescription = "New routine")
            }
        }
    ) { padding ->
        if (routines.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "No routines yet. Tap + to build one - pick your exercises, put them in order, and " +
                        "you'll be able to start it from Home in one tap.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                items(routines, key = { it.id }) { routine ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(routine.name, style = MaterialTheme.typography.titleMedium)
                                if (!routine.isCustom) {
                                    Text(
                                        "Built-in routine",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            IconButton(onClick = { onEditRoutine(routine.id) }) {
                                Icon(Icons.Filled.Edit, contentDescription = "Edit routine")
                            }
                            IconButton(onClick = { pendingDelete = routine }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete routine")
                            }
                            IconButton(onClick = { onStartRoutine(routine.id) }) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = "Start routine")
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDelete?.let { routine ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete \"${routine.name}\"?") },
            text = { Text("This only removes the routine - your logged sets for its exercises are kept.") },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteRoutine(routine)
                    pendingDelete = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Cancel") }
            }
        )
    }
}
