package com.stevie.liftlog.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

/** The app's four top-level destinations, shown as bottom navigation on Home/Routines/Stats/Settings. */
enum class BottomDestination { HOME, ROUTINES, STATS, SETTINGS }

@Composable
fun LiftLogBottomBar(current: BottomDestination, onSelect: (BottomDestination) -> Unit) {
    NavigationBar {
        NavigationBarItem(
            selected = current == BottomDestination.HOME,
            onClick = { onSelect(BottomDestination.HOME) },
            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
            label = { Text("Home") }
        )
        NavigationBarItem(
            selected = current == BottomDestination.ROUTINES,
            onClick = { onSelect(BottomDestination.ROUTINES) },
            icon = { Icon(Icons.Filled.List, contentDescription = null) },
            label = { Text("Routines") }
        )
        NavigationBarItem(
            selected = current == BottomDestination.STATS,
            onClick = { onSelect(BottomDestination.STATS) },
            icon = { Icon(Icons.Filled.BarChart, contentDescription = null) },
            label = { Text("Stats") }
        )
        NavigationBarItem(
            selected = current == BottomDestination.SETTINGS,
            onClick = { onSelect(BottomDestination.SETTINGS) },
            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
            label = { Text("Settings") }
        )
    }
}
