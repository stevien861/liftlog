package com.stevie.liftlog.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * A minimal, dependency-free line chart (no external charting library) that
 * plots one value per session, oldest to newest, left to right. Used to show
 * top working weight over time for an exercise.
 */
@Composable
fun ProgressLineChart(
    points: List<Float>,
    modifier: Modifier = Modifier,
    lineColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.primary
) {
    if (points.size < 2) {
        Box(modifier = modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
            Text(
                "Log at least two sessions to see a trend line here.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val min = points.min()
    val max = points.max()
    val range = (max - min).takeIf { it > 0f } ?: 1f

    Canvas(modifier = modifier.fillMaxWidth().height(120.dp)) {
        val paddingPx = 12.dp.toPx()
        val chartWidth = size.width - paddingPx * 2
        val chartHeight = size.height - paddingPx * 2
        val stepX = if (points.size > 1) chartWidth / (points.size - 1) else 0f

        fun offsetFor(index: Int, value: Float): Offset {
            val x = paddingPx + stepX * index
            val normalized = (value - min) / range
            val y = paddingPx + chartHeight - (normalized * chartHeight)
            return Offset(x, y)
        }

        val path = androidx.compose.ui.graphics.Path()
        points.forEachIndexed { index, value ->
            val offset = offsetFor(index, value)
            if (index == 0) path.moveTo(offset.x, offset.y) else path.lineTo(offset.x, offset.y)
        }
        drawPath(path = path, color = lineColor, style = Stroke(width = 4.dp.toPx()))

        points.forEachIndexed { index, value ->
            val offset = offsetFor(index, value)
            drawCircle(color = lineColor, radius = 5.dp.toPx(), center = offset)
        }
    }
}
