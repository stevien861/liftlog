package com.stevie.liftlog.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single exercise the user can log sets against, e.g. "Barbell Bench Press"
 * filed under [MuscleCategory.CHEST].
 *
 * [targetRepRangeLow]/[targetRepRangeHigh] and [weightIncrementKg] drive the
 * progressive-overload recommendation in [com.stevie.liftlog.recommendation.ProgressionEngine] -
 * they're editable per exercise because a heavy compound lift (e.g. Squat,
 * usually progressed in 2.5-5kg jumps across a low rep range) behaves very
 * differently from a small isolation move (e.g. Lateral Raise, usually
 * progressed in 1-1.25kg jumps across a higher rep range).
 *
 * [targetSets] is how many working sets a guided workout session shows as the
 * goal for this exercise (informational only - logging more or fewer sets is
 * never blocked). [startingWeightKg] is an optional starting/target weight
 * used to prefill the "Log a set" weight field the first time an exercise is
 * logged, before [com.stevie.liftlog.recommendation.ProgressionEngine] has any
 * history to base a suggestion on; once there's logged history, the engine's
 * suggestion takes over.
 */
@Entity(tableName = "exercises")
data class ExerciseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: MuscleCategory,
    val targetRepRangeLow: Int = 8,
    val targetRepRangeHigh: Int = 12,
    val weightIncrementKg: Double = 2.5,
    val targetSets: Int = 3,
    val startingWeightKg: Double? = null,
    val isCustom: Boolean = true,
    val notes: String = "",
    val isArchived: Boolean = false
)
