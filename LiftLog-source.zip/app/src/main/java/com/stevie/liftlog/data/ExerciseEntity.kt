package com.stevie.liftlog.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single exercise the user can log sets against, e.g. "Barbell Bench Press"
 * filed under [MuscleCategory.CHEST].
 *
 * [targetRepRangeLow]/[targetRepRangeHigh] and [weightIncrementKg] drive the
 * progressive-overload recommendation in [com.stevie.liftlog.recommendation.ProgressionEngine] -
 * they're editable per exercise because a heavy compound lift (e.g. Squat,
 * usually progressed in 2.5-5kg jumps across a low rep range) behaves very
 * differently from a small isolation move (e.g. Lateral Raise, usually
 * progressed in 1-1.25kg jumps across a higher rep range).
 */
@Entity(tableName = "exercises")
data class ExerciseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: MuscleCategory,
    val targetRepRangeLow: Int = 8,
    val targetRepRangeHigh: Int = 12,
    val weightIncrementKg: Double = 2.5,
    val isCustom: Boolean = true,
    val notes: String = "",
    val isArchived: Boolean = false
)
