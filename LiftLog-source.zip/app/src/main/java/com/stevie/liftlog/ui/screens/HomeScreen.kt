package com.stevie.liftlog.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.data.RoutineEntity
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.BottomDestination
import com.stevie.liftlog.ui.components.IconBadge
import com.stevie.liftlog.ui.components.LiftLogBottomBar
import com.stevie.liftlog.ui.components.SectionHeader
import com.stevie.liftlog.ui.components.StatTile
import com.stevie.liftlog.ui.components.categoryColor
import com.stevie.liftlog.ui.components.categoryIcon
import com.stevie.liftlog.ui.theme.LiftLogColors
import com.stevie.liftlog.viewmodel.HomeViewModel
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: WorkoutRepository,
    onStartWorkout: (routineId: Long?) -> Unit,
    onBrowseExercises: () -> Unit,
    onCategoryClick: (MuscleCategory) -> Unit,
    onNavigate: (BottomDestination) -> Unit
) {
    val viewModel: HomeViewModel = viewModel(factory = LiftLogViewModelFactory(repository))
    val exercises by viewModel.exercises.collectAsStateWithLifecycle()
    val routines by viewModel.routines.collectAsStateWithLifecycle()
    val streakDays by viewModel.streakDays.collectAsStateWithLifecycle()
    val weeklyVolumeKg by viewModel.thisWeekVolumeKg.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { TopAppBar(title = { Text("LiftLog") }) },
        bottomBar = { LiftLogBottomBar(current = BottomDestination.HOME, onSelect = onNavigate) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Filled.LocalFireDepartment,
                    value = "$streakDays",
                    label = "Day streak",
                    tint = LiftLogColors.streak
                )
                StatTile(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Filled.Bolt,
                    value = "${formatKg(weeklyVolumeKg)}kg",
                    label = "This week",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader(title = "Start a workout")
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Card(
                        modifier = Modifier
                            .width(150.dp)
                            .height(96.dp)
                            .clickable { onStartWorkout(null) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                "Freestyle",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
                items(routines, key = { it.id }) { routine ->
                    RoutineStartCard(routine = routine, onClick = { onStartWorkout(routine.id) })
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
            SectionHeader(title = "Browse exercises", actionLabel = "See all", onActionClick = onBrowseExercises)
            Spacer(modifier = Modifier.height(10.dp))
            MuscleCategory.entries.chunked(2).forEach { row ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { category ->
                        val count = exercises.count { it.category == category }
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(104.dp)
                                .clickable { onCategoryClick(category) },
                            colors = CardDefaults.cardColors(
                                containerColor = categoryColor(category).copy(alpha = 0.12f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                IconBadge(icon = categoryIcon(category), tint = categoryColor(category), size = 32.dp)
                                Text(
                                    category.displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                                Text(
                                    if (count == 1) "1 exercise" else "$count exercises",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun RoutineStartCard(routine: RoutineEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(150.dp)
            .height(96.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onTertiaryContainer
            )
            Text(
                routine.name,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
