package com.stevie.liftlog.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A single bodyweight check-in. [dateEpochDay] is a unique index, so logging again for a date you
 * already recorded (e.g. correcting this morning's weigh-in) replaces that day's entry rather than
 * creating a duplicate - see [ExerciseDao]-style REPLACE inserts in [BodyWeightDao].
 */
@Entity(
    tableName = "body_weight_entries",
    indices = [Index("dateEpochDay", unique = true)]
)
data class BodyWeightEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateEpochDay: Long,
    val weightKg: Double
)
