package com.stevie.liftlog.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.repository.ImportMode
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory
import com.stevie.liftlog.viewmodel.SettingsMessage
import com.stevie.liftlog.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(repository: WorkoutRepository, onBack: () -> Unit) {
    val viewModel: SettingsViewModel = viewModel(factory = LiftLogViewModelFactory(repository))
    val message by viewModel.lastMessage.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pendingImportUri by remember { mutableStateOf<Uri?>(null) }
    var pendingExportJson by remember { mutableStateOf<String?>(null) }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val json = pendingExportJson
        if (uri != null && json != null) {
            scope.launch {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                }
            }
        }
        pendingExportJson = null
    }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pendingImportUri = uri
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Back up your data", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Save every exercise and logged set to a JSON file you choose - keep it somewhere safe, " +
                            "or move it to a new phone.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )
                    Button(
                        onClick = {
                            viewModel.exportData { json ->
                                pendingExportJson = json
                                createDocumentLauncher.launch("liftlog-backup-${LocalDate.now()}.json")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Export to a file") }
                }
            }

            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Restore from a backup", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Import a LiftLog JSON backup. Choose whether to replace everything currently on this " +
                            "phone, or merge it in alongside what's already here.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )
                    OutlinedButton(
                        onClick = { openDocumentLauncher.launch(arrayOf("application/json")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Choose a backup file to import") }
                }
            }

            message?.let { msg ->
                Card {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            when (msg) {
                                is SettingsMessage.ExportReady -> "Export ready."
                                is SettingsMessage.ImportSucceeded ->
                                    "Imported ${msg.exerciseCount} exercise(s) and ${msg.setCount} set(s)."
                                is SettingsMessage.Error -> msg.message
                            },
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }

    val importUri = pendingImportUri
    if (importUri != null) {
        ImportModeDialog(
            onDismiss = { pendingImportUri = null },
            onChoose = { mode ->
                scope.launch {
                    val text = context.contentResolver.openInputStream(importUri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    }
                    if (text != null) {
                        viewModel.importData(text, mode)
                    }
                    pendingImportUri = null
                }
            }
        )
    }
}

@Composable
private fun ImportModeDialog(onDismiss: () -> Unit, onChoose: (ImportMode) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import backup") },
        text = {
            Text(
                "Replace everything wipes what's currently on this phone first - use this on a fresh " +
                    "install. Merge adds the backup's exercises and sets alongside what's already here, " +
                    "which may create duplicate exercises."
            )
        },
        confirmButton = {
            Button(onClick = { onChoose(ImportMode.REPLACE_ALL) }) { Text("Replace everything") }
        },
        dismissButton = {
            TextButton(onClick = { onChoose(ImportMode.MERGE) }) { Text("Merge") }
        }
    )
}
