package com.stevie.liftlog.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.repository.ImportMode
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.BottomDestination
import com.stevie.liftlog.ui.components.LiftLogBottomBar
import com.stevie.liftlog.util.AppPreferences
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory
import com.stevie.liftlog.viewmodel.SettingsMessage
import com.stevie.liftlog.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    repository: WorkoutRepository,
    preferences: AppPreferences,
    onNavigate: (BottomDestination) -> Unit
) {
    val viewModel: SettingsViewModel =
        viewModel(factory = LiftLogViewModelFactory(repository, preferences = preferences))
    val message by viewModel.lastMessage.collectAsStateWithLifecycle()
    val restTimerSeconds by viewModel.restTimerSeconds.collectAsStateWithLifecycle()
    val barWeightKg by viewModel.barWeightKg.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pendingImportUri by remember { mutableStateOf<Uri?>(null) }
    var pendingExportJson by remember { mutableStateOf<String?>(null) }

    var restTimerText by remember(restTimerSeconds) { mutableStateOf(restTimerSeconds.toString()) }
    var barWeightText by remember(barWeightKg) { mutableStateOf(formatKg(barWeightKg)) }
    var animationStyleRobot by remember { mutableStateOf(preferences.animationStyleRobot) }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val json = pendingExportJson
        if (uri != null && json != null) {
            scope.launch {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                }
            }
        }
        pendingExportJson = null
    }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pendingImportUri = uri
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Settings") }) },
        bottomBar = { LiftLogBottomBar(current = BottomDestination.SETTINGS, onSelect = onNavigate) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Workout defaults", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Used for the guided workout's rest timer, and the plate calculator / warm-up suggestions.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = restTimerText,
                            onValueChange = { restTimerText = it },
                            label = { Text("Rest timer (sec)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = barWeightText,
                            onValueChange = { barWeightText = it },
                            label = { Text("Bar weight (kg)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    val restSecondsValue = restTimerText.toIntOrNull()
                    val barWeightValue = barWeightText.toDoubleOrNull()
                    Button(
                        onClick = {
                            restSecondsValue?.let { viewModel.updateRestTimerSeconds(it) }
                            barWeightValue?.let { viewModel.updateBarWeightKg(it) }
                        },
                        enabled = (restSecondsValue != null && restSecondsValue > 0) ||
                            (barWeightValue != null && barWeightValue > 0),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    ) { Text("Save defaults") }
                }
            }

            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Animation character", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Who performs the exercise demo animations on each exercise page.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !animationStyleRobot,
                            onClick = {
                                animationStyleRobot = false
                                preferences.animationStyleRobot = false
                            },
                            label = { Text("Human") },
                            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) }
                        )
                        FilterChip(
                            selected = animationStyleRobot,
                            onClick = {
                                animationStyleRobot = true
                                preferences.animationStyleRobot = true
                            },
                            label = { Text("Robot") },
                            leadingIcon = { Icon(Icons.Filled.SmartToy, contentDescription = null) }
                        )
                    }
                }
            }

            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Back up your data", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Save every exercise, routine and logged set to a JSON file you choose - keep it " +
                            "somewhere safe, or move it to a new phone.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )
                    Button(
                        onClick = {
                            viewModel.exportData { json ->
                                pendingExportJson = json
                                createDocumentLauncher.launch("liftlog-backup-${LocalDate.now()}.json")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Export to a file") }
                }
            }

            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Restore from a backup", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Import a LiftLog JSON backup. Choose whether to replace everything currently on this " +
                            "phone, or merge it in alongside what's already here.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )
                    OutlinedButton(
                        onClick = { openDocumentLauncher.launch(arrayOf("application/json")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Choose a backup file to import") }
                }
            }

            message?.let { msg ->
                Card {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            when (msg) {
                                is SettingsMessage.ExportReady -> "Export ready."
                                is SettingsMessage.ImportSucceeded ->
                                    "Imported ${msg.exerciseCount} exercise(s) and ${msg.setCount} set(s)."
                                is SettingsMessage.Error -> msg.message
                            },
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }

    val importUri = pendingImportUri
    if (importUri != null) {
        ImportModeDialog(
            onDismiss = { pendingImportUri = null },
            onChoose = { mode ->
                scope.launch {
                    val text = context.contentResolver.openInputStream(importUri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    }
                    if (text != null) {
                        viewModel.importData(text, mode)
                    }
                    pendingImportUri = null
                }
            }
        )
    }
}

@Composable
private fun ImportModeDialog(onDismiss: () -> Unit, onChoose: (ImportMode) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import backup") },
        text = {
            Text(
                "Replace everything wipes what's currently on this phone first - use this on a fresh " +
                    "install. Merge adds the backup's exercises and sets alongside what's already here, " +
                    "which may create duplicate exercises."
            )
        },
        confirmButton = {
            Button(onClick = { onChoose(ImportMode.REPLACE_ALL) }) { Text("Replace everything") }
        },
        dismissButton = {
            TextButton(onClick = { onChoose(ImportMode.MERGE) }) { Text("Merge") }
        }
    )
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
