package com.stevie.liftlog.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory
import com.stevie.liftlog.viewmodel.RoutineEditorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutineEditorScreen(
    repository: WorkoutRepository,
    routineId: Long?,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val viewModel: RoutineEditorViewModel =
        viewModel(factory = LiftLogViewModelFactory(repository, routineId = routineId))

    val name by viewModel.name.collectAsStateWithLifecycle()
    val selectedIds by viewModel.selectedExerciseIds.collectAsStateWithLifecycle()
    val allExercises by viewModel.allExercises.collectAsStateWithLifecycle()
    val exercisesById = allExercises.associateBy { it.id }
    val canSave = name.isNotBlank() && selectedIds.isNotEmpty()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (routineId != null) "Edit routine" else "New routine") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.save(onDone = onSaved) },
                        enabled = canSave
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = "Save routine")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = viewModel::updateName,
                    label = { Text("Routine name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Text(
                    "Exercises, in order (${selectedIds.size})",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            if (selectedIds.isEmpty()) {
                item {
                    Text(
                        "Tap exercises below to add them here, in the order you'll perform them.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(selectedIds, key = { it }) { exerciseId ->
                    val exercise = exercisesById[exerciseId]
                    val index = selectedIds.indexOf(exerciseId)
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 16.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                exercise?.name ?: "Exercise",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.moveExercise(index, (index - 1).coerceAtLeast(0)) },
                                enabled = index > 0
                            ) { Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Move up") }
                            IconButton(
                                onClick = {
                                    viewModel.moveExercise(index, (index + 1).coerceAtMost(selectedIds.size - 1))
                                },
                                enabled = index < selectedIds.size - 1
                            ) { Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Move down") }
                            IconButton(onClick = { viewModel.toggleExercise(exerciseId) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove")
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "All exercises",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            items(allExercises, key = { it.id }) { exercise ->
                val isSelected = selectedIds.contains(exercise.id)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleExercise(exercise.id) }
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(exercise.name, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            exercise.category.displayName,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        if (isSelected) Icons.Filled.Check else Icons.Filled.Add,
                        contentDescription = if (isSelected) "Selected" else "Add",
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
