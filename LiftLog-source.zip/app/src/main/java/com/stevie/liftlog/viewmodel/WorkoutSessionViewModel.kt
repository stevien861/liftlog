package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.SetEntryEntity
import com.stevie.liftlog.recommendation.Recommendation
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.stats.NewRecord
import com.stevie.liftlog.util.AppPreferences
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

/** One exercise's newly-broken record(s) during this workout, for the finish-workout summary. */
data class SessionRecord(val exerciseName: String, val records: List<NewRecord>)

/**
 * Drives the guided "start a workout" flow: walks through an ordered list of exercises (from a
 * routine, or built freestyle by adding exercises one at a time), logging sets against whichever
 * exercise is "current", and running an automatic rest countdown after each logged set.
 *
 * [routineId] is null for a freestyle session (the user picks exercises as they go).
 */
@OptIn(ExperimentalCoroutinesApi::class)
class WorkoutSessionViewModel(
    private val repository: WorkoutRepository,
    private val preferences: AppPreferences,
    routineId: Long?
) : ViewModel() {

    private val _exerciseIds = MutableStateFlow<List<Long>>(emptyList())
    val exerciseIds: StateFlow<List<Long>> = _exerciseIds.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _restSecondsRemaining = MutableStateFlow<Int?>(null)
    val restSecondsRemaining: StateFlow<Int?> = _restSecondsRemaining.asStateFlow()

    private val _sessionRecords = MutableStateFlow<List<SessionRecord>>(emptyList())
    val sessionRecords: StateFlow<List<SessionRecord>> = _sessionRecords.asStateFlow()

    private val _setsLoggedCount = MutableStateFlow(0)
    val setsLoggedCount: StateFlow<Int> = _setsLoggedCount.asStateFlow()

    private val _finished = MutableStateFlow(false)
    val finished: StateFlow<Boolean> = _finished.asStateFlow()

    val routineName: StateFlow<String?> = if (routineId != null) {
        repository.observeRoutine(routineId)
            .map { it?.name }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    } else {
        MutableStateFlow<String?>(null)
    }

    val allExercises: StateFlow<List<ExerciseEntity>> = repository.observeExercises()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val currentExerciseId: StateFlow<Long?> = combine(_exerciseIds, _currentIndex) { ids, index ->
        ids.getOrNull(index)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val currentExercise: StateFlow<ExerciseEntity?> = combine(currentExerciseId, allExercises) { id, all ->
        all.firstOrNull { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val currentRecommendation: StateFlow<Recommendation?> = currentExerciseId
        .flatMapLatest { id -> id?.let { repository.observeRecommendation(it) } ?: flowOf(null) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val currentTodaySets: StateFlow<List<SetEntryEntity>> = currentExerciseId
        .flatMapLatest { id ->
            id?.let { repository.observeSetsForExerciseOnDate(it, LocalDate.now()) } ?: flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private var restTimerJob: Job? = null

    init {
        if (routineId != null) {
            viewModelScope.launch {
                val routineExercises = repository.observeRoutineExercises(routineId).first()
                _exerciseIds.value = routineExercises.sortedBy { it.sortOrder }.map { it.exerciseId }
            }
        }
    }

    fun addExercise(exerciseId: Long) {
        if (_exerciseIds.value.contains(exerciseId)) return
        _exerciseIds.value = _exerciseIds.value + exerciseId
    }

    fun removeExerciseAt(index: Int) {
        val list = _exerciseIds.value.toMutableList()
        if (index !in list.indices) return
        list.removeAt(index)
        _exerciseIds.value = list
        if (_currentIndex.value >= list.size) {
            _currentIndex.value = (list.size - 1).coerceAtLeast(0)
        }
    }

    fun goToExercise(index: Int) {
        if (index in _exerciseIds.value.indices) _currentIndex.value = index
    }

    /** Moves to the next exercise, or marks the workout finished if this was the last one. */
    fun nextExercise() {
        skipRest()
        val next = _currentIndex.value + 1
        if (next < _exerciseIds.value.size) _currentIndex.value = next else _finished.value = true
    }

    fun previousExercise() {
        if (_currentIndex.value > 0) {
            skipRest()
            _currentIndex.value -= 1
        }
    }

    fun logSetForCurrentExercise(weightKg: Double, reps: Int) {
        val exerciseId = currentExerciseId.value ?: return
        val exerciseName = currentExercise.value?.name ?: return
        if (weightKg <= 0 || reps <= 0) return
        viewModelScope.launch {
            val records = repository.logSetAndCheckRecords(exerciseId, LocalDate.now(), weightKg, reps)
            _setsLoggedCount.value += 1
            if (records.isNotEmpty()) {
                _sessionRecords.value = _sessionRecords.value + SessionRecord(exerciseName, records)
            }
            startRestTimer()
        }
    }

    fun startRestTimer(seconds: Int = preferences.restTimerSeconds) {
        restTimerJob?.cancel()
        if (seconds <= 0) {
            _restSecondsRemaining.value = null
            return
        }
        _restSecondsRemaining.value = seconds
        restTimerJob = viewModelScope.launch {
            var remaining = seconds
            while (remaining > 0) {
                delay(1_000)
                remaining -= 1
                _restSecondsRemaining.value = remaining
            }
            _restSecondsRemaining.value = null
        }
    }

    fun addRestSeconds(deltaSeconds: Int) {
        val current = _restSecondsRemaining.value ?: return
        val updated = (current + deltaSeconds).coerceAtLeast(0)
        restTimerJob?.cancel()
        _restSecondsRemaining.value = updated
        if (updated > 0) {
            restTimerJob = viewModelScope.launch {
                var remaining = updated
                while (remaining > 0) {
                    delay(1_000)
                    remaining -= 1
                    _restSecondsRemaining.value = remaining
                }
                _restSecondsRemaining.value = null
            }
        }
    }

    fun skipRest() {
        restTimerJob?.cancel()
        _restSecondsRemaining.value = null
    }

    fun finishWorkout() {
        skipRest()
        _finished.value = true
    }

    override fun onCleared() {
        super.onCleared()
        restTimerJob?.cancel()
    }
}
