package com.stevie.liftlog.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BodyWeightDao {

    @Query("SELECT * FROM body_weight_entries ORDER BY dateEpochDay DESC")
    fun observeAll(): Flow<List<BodyWeightEntity>>

    @Query("SELECT * FROM body_weight_entries ORDER BY dateEpochDay DESC LIMIT 1")
    fun observeLatest(): Flow<BodyWeightEntity?>

    @Query("SELECT * FROM body_weight_entries")
    suspend fun getAllOnce(): List<BodyWeightEntity>

    /** Inserting for a [BodyWeightEntity.dateEpochDay] that already has an entry replaces it, thanks to the unique index. */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: BodyWeightEntity): Long

    @Delete
    suspend fun delete(entry: BodyWeightEntity)

    @Query("DELETE FROM body_weight_entries")
    suspend fun deleteAll()
}
