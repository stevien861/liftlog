package com.stevie.liftlog.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.achievements.Achievement
import com.stevie.liftlog.util.CelebrationEffects

/** A celebratory popup shown the moment an [Achievement] unlocks - confetti, a buzz, and a short chime. */
@Composable
fun AchievementUnlockedDialog(achievement: Achievement?, onDismiss: () -> Unit) {
    if (achievement == null) return

    val context = LocalContext.current
    LaunchedEffect(achievement) { CelebrationEffects.play(context) }

    ConfettiOverlay(trigger = achievement)

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.WorkspacePremium, contentDescription = null) },
        title = { Text("Achievement unlocked!") },
        text = {
            Column {
                Text(achievement.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    achievement.description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("Awesome") }
        }
    )
}
