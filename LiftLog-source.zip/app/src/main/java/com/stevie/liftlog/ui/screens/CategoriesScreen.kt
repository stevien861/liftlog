package com.stevie.liftlog.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.IconBadge
import com.stevie.liftlog.ui.components.categoryColor
import com.stevie.liftlog.ui.components.categoryIcon
import com.stevie.liftlog.viewmodel.ExerciseListViewModel
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory

/** Reached from Home's "See all" link - browses every exercise across all six categories. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoriesScreen(
    repository: WorkoutRepository,
    onCategoryClick: (MuscleCategory) -> Unit,
    onBack: () -> Unit
) {
    val viewModel: ExerciseListViewModel = viewModel(factory = LiftLogViewModelFactory(repository))
    val exercises by viewModel.exercises.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Browse Exercises") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            items(MuscleCategory.entries) { category ->
                val count = exercises.count { it.category == category }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onCategoryClick(category) },
                    colors = CardDefaults.cardColors(
                        containerColor = categoryColor(category).copy(alpha = 0.12f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        IconBadge(icon = categoryIcon(category), tint = categoryColor(category), size = 34.dp)
                        Text(
                            category.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        Text(
                            if (count == 1) "1 exercise" else "$count exercises",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
