package com.stevie.liftlog.ui.screens

import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.LiftLogApplication
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.AchievementUnlockedDialog
import com.stevie.liftlog.ui.components.ConfettiOverlay
import com.stevie.liftlog.ui.components.IconBadge
import com.stevie.liftlog.ui.components.PlateCalculatorDialog
import com.stevie.liftlog.ui.components.RecordCelebrationDialog
import com.stevie.liftlog.ui.components.RecommendationCard
import com.stevie.liftlog.ui.components.RestTimerBar
import com.stevie.liftlog.ui.components.WarmupSuggestionCard
import com.stevie.liftlog.ui.components.categoryColor
import com.stevie.liftlog.ui.components.categoryIcon
import com.stevie.liftlog.ui.theme.LiftLogColors
import com.stevie.liftlog.util.CelebrationEffects
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory
import com.stevie.liftlog.viewmodel.SessionRecord
import com.stevie.liftlog.viewmodel.WorkoutSessionViewModel

/**
 * The guided "start a workout" flow: walks through one exercise at a time (from a routine, or
 * freestyle when [routineId] is null), logging sets and running an automatic rest countdown
 * between them, and finishing with a short summary.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutSessionScreen(
    repository: WorkoutRepository,
    routineId: Long?,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val preferences = remember { (context.applicationContext as LiftLogApplication).preferences }
    val barWeightKg = preferences.barWeightKg.toDouble()

    val viewModel: WorkoutSessionViewModel = viewModel(
        factory = LiftLogViewModelFactory(repository, preferences = preferences, routineId = routineId)
    )

    val exerciseIds by viewModel.exerciseIds.collectAsStateWithLifecycle()
    val currentIndex by viewModel.currentIndex.collectAsStateWithLifecycle()
    val currentExercise by viewModel.currentExercise.collectAsStateWithLifecycle()
    val recommendation by viewModel.currentRecommendation.collectAsStateWithLifecycle()
    val todaySets by viewModel.currentTodaySets.collectAsStateWithLifecycle()
    val restSecondsRemaining by viewModel.restSecondsRemaining.collectAsStateWithLifecycle()
    val sessionRecords by viewModel.sessionRecords.collectAsStateWithLifecycle()
    val setsLoggedCount by viewModel.setsLoggedCount.collectAsStateWithLifecycle()
    val finished by viewModel.finished.collectAsStateWithLifecycle()
    val routineName by viewModel.routineName.collectAsStateWithLifecycle()
    val allExercises by viewModel.allExercises.collectAsStateWithLifecycle()
    val pendingAchievements by viewModel.pendingAchievements.collectAsStateWithLifecycle()

    var showAddExercise by remember { mutableStateOf(false) }
    var showPlateCalculator by remember { mutableStateOf(false) }
    var weightInput by remember(currentExercise?.id) { mutableStateOf("") }
    var repsInput by remember(currentExercise?.id) { mutableStateOf("") }

    var lastCelebratedCount by remember { mutableStateOf(0) }
    var celebrating by remember { mutableStateOf<SessionRecord?>(null) }
    LaunchedEffect(sessionRecords.size) {
        if (sessionRecords.size > lastCelebratedCount) {
            celebrating = sessionRecords.last()
            lastCelebratedCount = sessionRecords.size
        }
    }

    // A short buzz whenever the rest countdown reaches zero (or is skipped) - a quiet nudge that
    // doesn't require staring at the screen while resting between sets.
    var previousRestSeconds by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(restSecondsRemaining) {
        if (previousRestSeconds != null && restSecondsRemaining == null) {
            val vibrator = context.getSystemService(Vibrator::class.java)
            vibrator?.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
        }
        previousRestSeconds = restSecondsRemaining
    }

    if (finished) {
        WorkoutSummary(
            routineName = routineName,
            setsLoggedCount = setsLoggedCount,
            records = sessionRecords,
            onDone = onExit
        )
        AchievementUnlockedDialog(
            achievement = pendingAchievements.firstOrNull(),
            onDismiss = { viewModel.dismissAchievementCelebration() }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(routineName ?: "Freestyle workout") },
                navigationIcon = {
                    IconButton(onClick = onExit) {
                        Icon(Icons.Filled.Close, contentDescription = "Exit workout")
                    }
                },
                actions = {
                    if (routineId == null) {
                        IconButton(onClick = { showAddExercise = true }) {
                            Icon(Icons.Filled.Add, contentDescription = "Add exercise")
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (exerciseIds.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "Tap + to add the first exercise for this freestyle workout.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                item {
                    val exerciseCategory = currentExercise?.category
                    val accentColor = exerciseCategory?.let { categoryColor(it) } ?: MaterialTheme.colorScheme.primary
                    Card(
                        colors = CardDefaults.cardColors(containerColor = accentColor.copy(alpha = 0.10f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (exerciseCategory != null) {
                                    IconBadge(icon = categoryIcon(exerciseCategory), tint = accentColor, size = 36.dp)
                                }
                                Column(modifier = Modifier.padding(start = if (exerciseCategory != null) 12.dp else 0.dp)) {
                                    Text(
                                        "Exercise ${currentIndex + 1} of ${exerciseIds.size}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        currentExercise?.name ?: "",
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                }
                            }
                            LinearProgressIndicator(
                                progress = { (currentIndex + 1).toFloat() / exerciseIds.size },
                                color = accentColor,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 12.dp)
                                    .height(6.dp)
                            )
                        }
                    }
                }

                item { RecommendationCard(recommendation = recommendation) }

                val suggestedWeight = recommendation?.suggestedWeightKg
                if (suggestedWeight != null) {
                    item { WarmupSuggestionCard(workingWeightKg = suggestedWeight, barWeightKg = barWeightKg) }
                }

                if (restSecondsRemaining != null) {
                    item {
                        RestTimerBar(
                            secondsRemaining = restSecondsRemaining ?: 0,
                            onAdd30 = { viewModel.addRestSeconds(30) },
                            onSubtract30 = { viewModel.addRestSeconds(-30) },
                            onSkip = { viewModel.skipRest() }
                        )
                    }
                }

                item {
                    Card {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Log a set", style = MaterialTheme.typography.titleMedium)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = weightInput,
                                    onValueChange = { weightInput = it },
                                    label = { Text("Weight (kg)") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = repsInput,
                                    onValueChange = { repsInput = it },
                                    label = { Text("Reps") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            val weightValue = weightInput.toDoubleOrNull()
                            val repsValue = repsInput.toIntOrNull()

                            OutlinedButton(
                                onClick = {
                                    viewModel.onPlateCalculatorOpened()
                                    showPlateCalculator = true
                                },
                                enabled = weightValue != null && weightValue > 0,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                            ) { Text("Plate calculator") }

                            Button(
                                onClick = {
                                    viewModel.logSetForCurrentExercise(weightValue!!, repsValue!!)
                                    repsInput = ""
                                },
                                enabled = weightValue != null && weightValue > 0 && repsValue != null && repsValue > 0,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                            ) { Text("Log set") }

                            if (todaySets.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    "Logged today",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                todaySets.forEach { set ->
                                    Text(
                                        "Set ${set.setNumber}: ${formatKg(set.weightKg)} kg x ${set.reps} reps",
                                        style = MaterialTheme.typography.bodyLarge,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.previousExercise() },
                            enabled = currentIndex > 0
                        ) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = null)
                            Text(" Previous", modifier = Modifier.padding(start = 4.dp))
                        }
                        Button(onClick = { viewModel.nextExercise() }) {
                            Text(if (currentIndex == exerciseIds.size - 1) "Finish workout" else "Next")
                            if (currentIndex != exerciseIds.size - 1) {
                                Icon(
                                    Icons.Filled.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.padding(start = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPlateCalculator) {
        val target = weightInput.toDoubleOrNull() ?: recommendation?.suggestedWeightKg ?: barWeightKg
        PlateCalculatorDialog(
            targetWeightKg = target,
            barWeightKg = barWeightKg,
            onDismiss = { showPlateCalculator = false }
        )
    }

    if (showAddExercise) {
        AddExerciseDialog(
            allExercises = allExercises.map { it.id to it.name },
            alreadyAdded = exerciseIds.toSet(),
            onAdd = { viewModel.addExercise(it) },
            onDismiss = { showAddExercise = false }
        )
    }

    celebrating?.let { record ->
        RecordCelebrationDialog(
            exerciseName = record.exerciseName,
            records = record.records,
            onDismiss = { celebrating = null }
        )
    }

    AchievementUnlockedDialog(
        achievement = pendingAchievements.firstOrNull(),
        onDismiss = { viewModel.dismissAchievementCelebration() }
    )
}

@Composable
private fun AddExerciseDialog(
    allExercises: List<Pair<Long, String>>,
    alreadyAdded: Set<Long>,
    onAdd: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add exercise") },
        text = {
            LazyColumn {
                items(allExercises, key = { it.first }) { (id, name) ->
                    val isAdded = alreadyAdded.contains(id)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isAdded) { onAdd(id) }
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            name,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (isAdded) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                        )
                        if (isAdded) {
                            Text(
                                "Added",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        }
    )
}

@Composable
private fun WorkoutSummary(
    routineName: String?,
    setsLoggedCount: Int,
    records: List<SessionRecord>,
    onDone: () -> Unit
) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { CelebrationEffects.play(context) }

    ConfettiOverlay(trigger = "workout-finished")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        IconBadge(
            icon = Icons.Filled.CheckCircle,
            tint = MaterialTheme.colorScheme.primary,
            size = 64.dp
        )
        Text(
            "Workout complete",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(top = 16.dp)
        )
        Text(
            "${routineName ?: "Freestyle workout"} - " +
                (if (setsLoggedCount == 1) "1 set logged." else "$setsLoggedCount sets logged."),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp)
        )

        if (records.isNotEmpty()) {
            Spacer(modifier = Modifier.height(24.dp))
            Text("New records this workout", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            records.forEach { record ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconBadge(icon = Icons.Filled.EmojiEvents, tint = LiftLogColors.hold, size = 32.dp)
                        Text(
                            "${record.exerciseName}: " +
                                (if (record.records.size == 1) "1 record broken" else "${record.records.size} records broken"),
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Done") }
    }
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
