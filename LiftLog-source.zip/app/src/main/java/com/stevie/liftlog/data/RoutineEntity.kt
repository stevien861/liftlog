package com.stevie.liftlog.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A named, ordered workout plan (e.g. "Push Day", or a user's own custom split). The actual
 * exercises in it live in [RoutineExerciseEntity] rows, one per exercise, so the order and
 * membership can be edited freely without touching this row.
 */
@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val isCustom: Boolean = true,
    val sortOrder: Int = 0
)
