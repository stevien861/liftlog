package com.stevie.liftlog.achievements

/**
 * A milestone LiftLog can recognise. There's deliberately no database table for these - every
 * achievement is derived either from data already in Room (sets, routines, body weight) or from a
 * handful of small counters in [com.stevie.liftlog.util.AppPreferences], so adding this system
 * needed no schema change and no migration.
 */
enum class AchievementId {
    FIRST_SET,
    WEEK_STREAK,
    MONTH_STREAK,
    FIRST_RECORD,
    RECORD_COLLECTOR,
    ROUTINE_BUILDER,
    TEN_WORKOUTS,
    FIFTY_WORKOUTS,
    PLATE_MASTER,
    BODY_AWARE,
    ALL_ROUNDER
}

data class Achievement(val id: AchievementId, val title: String, val description: String)

object Achievements {
    val ALL: List<Achievement> = listOf(
        Achievement(AchievementId.FIRST_SET, "First Steps", "Log your very first set"),
        Achievement(AchievementId.WEEK_STREAK, "Week Warrior", "Reach a 7-day workout streak"),
        Achievement(AchievementId.MONTH_STREAK, "Iron Habit", "Reach a 30-day workout streak"),
        Achievement(AchievementId.FIRST_RECORD, "Record Breaker", "Break your first personal record"),
        Achievement(AchievementId.RECORD_COLLECTOR, "Record Collector", "Break 10 personal records"),
        Achievement(AchievementId.ROUTINE_BUILDER, "Routine Builder", "Create your own workout routine"),
        Achievement(AchievementId.TEN_WORKOUTS, "Regular", "Complete 10 guided workouts"),
        Achievement(AchievementId.FIFTY_WORKOUTS, "Fifty Club", "Complete 50 guided workouts"),
        Achievement(AchievementId.PLATE_MASTER, "Plate Master", "Use the plate calculator 5 times"),
        Achievement(AchievementId.BODY_AWARE, "Body Aware", "Log your body weight 7 times"),
        Achievement(AchievementId.ALL_ROUNDER, "All-Rounder", "Log a set in every muscle category")
    )
}

/** Everything [AchievementEngine] needs to decide what's unlocked. */
data class AchievementProgress(
    val hasLoggedAnySet: Boolean,
    val streakDays: Int,
    val recordsBrokenCount: Int,
    val hasCustomRoutine: Boolean,
    val workoutsCompletedCount: Int,
    val plateCalculatorUsesCount: Int,
    val bodyWeightEntryCount: Int,
    val categoriesWithSetsCount: Int,
    val totalCategoryCount: Int
)

/** The handful of counters that live in SharedPreferences rather than being derivable from Room. */
data class AchievementCounters(
    val recordsBrokenCount: Int,
    val workoutsCompletedCount: Int,
    val plateCalculatorUsesCount: Int
)

/**
 * Pure threshold logic - no database or Android dependency, so it's fully unit-testable. Every
 * scenario here was verified against a standalone Python mirror before being ported to Kotlin,
 * the same approach used for [com.stevie.liftlog.recommendation.ProgressionEngine].
 */
object AchievementEngine {
    fun unlockedIds(progress: AchievementProgress): Set<AchievementId> {
        val unlocked = mutableSetOf<AchievementId>()
        if (progress.hasLoggedAnySet) unlocked += AchievementId.FIRST_SET
        if (progress.streakDays >= 7) unlocked += AchievementId.WEEK_STREAK
        if (progress.streakDays >= 30) unlocked += AchievementId.MONTH_STREAK
        if (progress.recordsBrokenCount >= 1) unlocked += AchievementId.FIRST_RECORD
        if (progress.recordsBrokenCount >= 10) unlocked += AchievementId.RECORD_COLLECTOR
        if (progress.hasCustomRoutine) unlocked += AchievementId.ROUTINE_BUILDER
        if (progress.workoutsCompletedCount >= 10) unlocked += AchievementId.TEN_WORKOUTS
        if (progress.workoutsCompletedCount >= 50) unlocked += AchievementId.FIFTY_WORKOUTS
        if (progress.plateCalculatorUsesCount >= 5) unlocked += AchievementId.PLATE_MASTER
        if (progress.bodyWeightEntryCount >= 7) unlocked += AchievementId.BODY_AWARE
        if (progress.totalCategoryCount > 0 && progress.categoriesWithSetsCount >= progress.totalCategoryCount) {
            unlocked += AchievementId.ALL_ROUNDER
        }
        return unlocked
    }
}
