package com.stevie.liftlog.util

import android.content.Context
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * Haptic + a short notification-style sound for the app's bigger celebration moments (a broken
 * record, an unlocked achievement, finishing a workout). Uses the device's own default
 * notification tone rather than a bundled audio asset, so there's nothing to license or bundle,
 * and it degrades silently (via [runCatching]) if a device has no default tone or playback fails.
 */
object CelebrationEffects {
    fun play(context: Context) {
        val vibrator = context.getSystemService(Vibrator::class.java)
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 80, 60, 80, 60, 120), -1))

        runCatching {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION)
                ?: return@runCatching
            val player = MediaPlayer.create(context, uri) ?: return@runCatching
            player.setOnCompletionListener { it.release() }
            player.start()
        }
    }
}
