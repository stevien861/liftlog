package com.stevie.liftlog.util

import android.content.Context

/**
 * Small, non-database settings that don't belong in Room: whether the first-run welcome flow has
 * been completed, and a couple of user-adjustable defaults (rest timer length, barbell weight)
 * used across the guided workout, plate calculator and warm-up suggestions.
 */
class AppPreferences(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var onboardingComplete: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING_COMPLETE, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETE, value).apply()

    /** Default rest countdown, in seconds, started automatically after logging a set during a guided workout. */
    var restTimerSeconds: Int
        get() = prefs.getInt(KEY_REST_TIMER_SECONDS, DEFAULT_REST_TIMER_SECONDS)
        set(value) = prefs.edit().putInt(KEY_REST_TIMER_SECONDS, value).apply()

    /** Used by the plate calculator and warm-up suggestions; most gyms use a 20kg Olympic bar. */
    var barWeightKg: Float
        get() = prefs.getFloat(KEY_BAR_WEIGHT_KG, DEFAULT_BAR_WEIGHT_KG)
        set(value) = prefs.edit().putFloat(KEY_BAR_WEIGHT_KG, value).apply()

    companion object {
        private const val PREFS_NAME = "liftlog_prefs"
        private const val KEY_ONBOARDING_COMPLETE = "onboarding_complete"
        private const val KEY_REST_TIMER_SECONDS = "rest_timer_seconds"
        private const val KEY_BAR_WEIGHT_KG = "bar_weight_kg"
        const val DEFAULT_REST_TIMER_SECONDS = 90
        const val DEFAULT_BAR_WEIGHT_KG = 20.0f
    }
}
