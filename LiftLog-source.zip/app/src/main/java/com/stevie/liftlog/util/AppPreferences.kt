package com.stevie.liftlog.util

import android.content.Context

/**
 * Small, non-database settings that don't belong in Room: whether the first-run welcome flow has
 * been completed, and a couple of user-adjustable defaults (rest timer length, barbell weight)
 * used across the guided workout, plate calculator and warm-up suggestions.
 */
class AppPreferences(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var onboardingComplete: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING_COMPLETE, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETE, value).apply()

    /** Default rest countdown, in seconds, started automatically after logging a set during a guided workout. */
    var restTimerSeconds: Int
        get() = prefs.getInt(KEY_REST_TIMER_SECONDS, DEFAULT_REST_TIMER_SECONDS)
        set(value) = prefs.edit().putInt(KEY_REST_TIMER_SECONDS, value).apply()

    /** Used by the plate calculator and warm-up suggestions; most gyms use a 20kg Olympic bar. */
    var barWeightKg: Float
        get() = prefs.getFloat(KEY_BAR_WEIGHT_KG, DEFAULT_BAR_WEIGHT_KG)
        set(value) = prefs.edit().putFloat(KEY_BAR_WEIGHT_KG, value).apply()

    // ---- Achievement counters -------------------------------------------------
    // A few small running totals that aren't otherwise derivable from Room (or are, but cheaper
    // to track incrementally) - see com.stevie.liftlog.achievements.AchievementEngine.

    var recordsBrokenCount: Int
        get() = prefs.getInt(KEY_RECORDS_BROKEN_COUNT, 0)
        set(value) = prefs.edit().putInt(KEY_RECORDS_BROKEN_COUNT, value).apply()

    fun incrementRecordsBrokenCount(by: Int = 1) {
        recordsBrokenCount += by
    }

    var workoutsCompletedCount: Int
        get() = prefs.getInt(KEY_WORKOUTS_COMPLETED_COUNT, 0)
        set(value) = prefs.edit().putInt(KEY_WORKOUTS_COMPLETED_COUNT, value).apply()

    fun incrementWorkoutsCompletedCount() {
        workoutsCompletedCount += 1
    }

    var plateCalculatorUsesCount: Int
        get() = prefs.getInt(KEY_PLATE_CALCULATOR_USES_COUNT, 0)
        set(value) = prefs.edit().putInt(KEY_PLATE_CALCULATOR_USES_COUNT, value).apply()

    fun incrementPlateCalculatorUsesCount() {
        plateCalculatorUsesCount += 1
    }

    /** Achievement IDs (by name) already shown to the person, so a celebratory popup only appears once per achievement. */
    var seenAchievementIds: Set<String>
        get() = prefs.getStringSet(KEY_SEEN_ACHIEVEMENTS, emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_SEEN_ACHIEVEMENTS, value).apply()

    companion object {
        private const val PREFS_NAME = "liftlog_prefs"
        private const val KEY_ONBOARDING_COMPLETE = "onboarding_complete"
        private const val KEY_REST_TIMER_SECONDS = "rest_timer_seconds"
        private const val KEY_BAR_WEIGHT_KG = "bar_weight_kg"
        private const val KEY_RECORDS_BROKEN_COUNT = "records_broken_count"
        private const val KEY_WORKOUTS_COMPLETED_COUNT = "workouts_completed_count"
        private const val KEY_PLATE_CALCULATOR_USES_COUNT = "plate_calculator_uses_count"
        private const val KEY_SEEN_ACHIEVEMENTS = "seen_achievement_ids"
        const val DEFAULT_REST_TIMER_SECONDS = 90
        const val DEFAULT_BAR_WEIGHT_KG = 20.0f
    }
}
