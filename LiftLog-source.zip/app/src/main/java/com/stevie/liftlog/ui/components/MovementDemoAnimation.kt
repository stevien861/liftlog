package com.stevie.liftlog.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.data.MuscleCategory

/**
 * A small looping Canvas animation illustrating the correct movement pattern for a specific
 * exercise, drawn as a lifter figure actually performing that exact lift - a barbell deadlift
 * looks different from a Romanian deadlift, a seated cable row looks different from a bent-over
 * barbell row, and so on for all 26 default exercises. Not a real video, just a lightweight,
 * always-available, dependency-free visual cue shown on the exercise detail screen and
 * referenced in onboarding. Custom exercises the user adds fall back to a representative
 * animation for their muscle category (see [defaultPatternFor]).
 */
private enum class MovementPattern {
    // Back
    DEADLIFT, BENT_OVER_ROW, LAT_PULLDOWN, PULL_UP, SEATED_CABLE_ROW,
    // Chest
    BENCH_PRESS, INCLINE_DUMBBELL_PRESS, PUSH_UP, CABLE_FLY,
    // Arms
    BARBELL_CURL, HAMMER_CURL, TRICEP_PUSHDOWN, SKULL_CRUSHER,
    // Shoulders
    OVERHEAD_PRESS, LATERAL_RAISE, REAR_DELT_FLY, FACE_PULL,
    // Forearms
    WRIST_CURL, REVERSE_WRIST_CURL, REVERSE_CURL,
    // Legs
    SQUAT, LEG_PRESS, ROMANIAN_DEADLIFT, LUNGE, LEG_EXTENSION, CALF_RAISE
}

/** Exact match against [com.stevie.liftlog.data.DefaultExercises] names, lowercased. */
private val EXACT_PATTERNS: Map<String, MovementPattern> = mapOf(
    "deadlift" to MovementPattern.DEADLIFT,
    "barbell row" to MovementPattern.BENT_OVER_ROW,
    "lat pulldown" to MovementPattern.LAT_PULLDOWN,
    "pull-up" to MovementPattern.PULL_UP,
    "seated cable row" to MovementPattern.SEATED_CABLE_ROW,
    "barbell bench press" to MovementPattern.BENCH_PRESS,
    "incline dumbbell press" to MovementPattern.INCLINE_DUMBBELL_PRESS,
    "push-up" to MovementPattern.PUSH_UP,
    "cable fly" to MovementPattern.CABLE_FLY,
    "barbell bicep curl" to MovementPattern.BARBELL_CURL,
    "hammer curl" to MovementPattern.HAMMER_CURL,
    "tricep pushdown" to MovementPattern.TRICEP_PUSHDOWN,
    "skull crusher" to MovementPattern.SKULL_CRUSHER,
    "overhead press" to MovementPattern.OVERHEAD_PRESS,
    "lateral raise" to MovementPattern.LATERAL_RAISE,
    "rear delt fly" to MovementPattern.REAR_DELT_FLY,
    "face pull" to MovementPattern.FACE_PULL,
    "wrist curl" to MovementPattern.WRIST_CURL,
    "reverse wrist curl" to MovementPattern.REVERSE_WRIST_CURL,
    "reverse curl" to MovementPattern.REVERSE_CURL,
    "back squat" to MovementPattern.SQUAT,
    "leg press" to MovementPattern.LEG_PRESS,
    "romanian deadlift" to MovementPattern.ROMANIAN_DEADLIFT,
    "walking lunge" to MovementPattern.LUNGE,
    "leg extension" to MovementPattern.LEG_EXTENSION,
    "calf raise" to MovementPattern.CALF_RAISE
)

/** Fallback for custom (user-added) exercises that don't match a known name exactly. */
private fun defaultPatternFor(category: MuscleCategory): MovementPattern = when (category) {
    MuscleCategory.CHEST -> MovementPattern.BENCH_PRESS
    MuscleCategory.SHOULDERS -> MovementPattern.OVERHEAD_PRESS
    MuscleCategory.BACK -> MovementPattern.BENT_OVER_ROW
    MuscleCategory.LEGS -> MovementPattern.SQUAT
    MuscleCategory.ARMS -> MovementPattern.BARBELL_CURL
    MuscleCategory.FOREARMS -> MovementPattern.WRIST_CURL
}

private fun movementPatternFor(exerciseName: String, category: MuscleCategory): MovementPattern =
    EXACT_PATTERNS[exerciseName.trim().lowercase()] ?: defaultPatternFor(category)

@Composable
fun MovementDemoAnimation(exerciseName: String, category: MuscleCategory, modifier: Modifier = Modifier) {
    val pattern = movementPatternFor(exerciseName, category)
    val color = categoryColor(category)
    val transition = rememberInfiniteTransition()
    val periodMillis = when (pattern) {
        MovementPattern.WRIST_CURL, MovementPattern.REVERSE_WRIST_CURL, MovementPattern.CALF_RAISE -> 900
        MovementPattern.LATERAL_RAISE, MovementPattern.CABLE_FLY, MovementPattern.REAR_DELT_FLY,
        MovementPattern.FACE_PULL, MovementPattern.LEG_EXTENSION -> 1100
        else -> 1500
    }
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = periodMillis),
            repeatMode = RepeatMode.Reverse
        )
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(112.dp)
    ) {
        when (pattern) {
            MovementPattern.DEADLIFT -> drawDeadlift(phase, color)
            MovementPattern.BENT_OVER_ROW -> drawBentOverRow(phase, color)
            MovementPattern.LAT_PULLDOWN -> drawLatPulldown(phase, color)
            MovementPattern.PULL_UP -> drawPullUp(phase, color)
            MovementPattern.SEATED_CABLE_ROW -> drawSeatedCableRow(phase, color)
            MovementPattern.BENCH_PRESS -> drawBenchPress(phase, color)
            MovementPattern.INCLINE_DUMBBELL_PRESS -> drawInclineDumbbellPress(phase, color)
            MovementPattern.PUSH_UP -> drawPushUp(phase, color)
            MovementPattern.CABLE_FLY -> drawCableFly(phase, color)
            MovementPattern.BARBELL_CURL -> drawCurl(phase, color)
            MovementPattern.HAMMER_CURL -> drawHammerCurl(phase, color)
            MovementPattern.TRICEP_PUSHDOWN -> drawTricepPushdown(phase, color)
            MovementPattern.SKULL_CRUSHER -> drawSkullCrusher(phase, color)
            MovementPattern.OVERHEAD_PRESS -> drawOverheadPress(phase, color)
            MovementPattern.LATERAL_RAISE -> drawLateralRaise(phase, color)
            MovementPattern.REAR_DELT_FLY -> drawRearDeltFly(phase, color)
            MovementPattern.FACE_PULL -> drawFacePull(phase, color)
            MovementPattern.WRIST_CURL -> drawWristCurl(phase, color)
            MovementPattern.REVERSE_WRIST_CURL -> drawReverseWristCurl(phase, color)
            MovementPattern.REVERSE_CURL -> drawReverseCurl(phase, color)
            MovementPattern.SQUAT -> drawSquat(phase, color)
            MovementPattern.LEG_PRESS -> drawLegPress(phase, color)
            MovementPattern.ROMANIAN_DEADLIFT -> drawRomanianDeadlift(phase, color)
            MovementPattern.LUNGE -> drawLunge(phase, color)
            MovementPattern.LEG_EXTENSION -> drawLegExtension(phase, color)
            MovementPattern.CALF_RAISE -> drawCalfRaise(phase, color)
        }
    }
}

// ---- Shared drawing helpers ----

private fun lerp(from: Float, to: Float, t: Float): Float = from + (to - from) * t

/** One or more connected line segments, e.g. shoulder -> elbow -> hand. */
private fun DrawScope.limb(strokeWidth: Float, color: Color, points: List<Offset>) {
    for (i in 0 until points.size - 1) {
        drawLine(color = color, start = points[i], end = points[i + 1], strokeWidth = strokeWidth, cap = StrokeCap.Round)
    }
}

private fun DrawScope.head(center: Offset, radius: Float, color: Color) {
    drawCircle(color = color, radius = radius, center = center)
}

/** A horizontal barbell: a thin bar with a plate at each end. */
private fun DrawScope.bar(left: Offset, right: Offset, strokeWidth: Float, plateRadius: Float, color: Color) {
    drawLine(color = color, start = left, end = right, strokeWidth = strokeWidth * 0.55f, cap = StrokeCap.Round)
    drawCircle(color = color, radius = plateRadius, center = left)
    drawCircle(color = color, radius = plateRadius, center = right)
}

/** A single dumbbell held in one hand: a short bar with a small plate on each end. */
private fun DrawScope.dumbbell(center: Offset, strokeWidth: Float, plateRadius: Float, color: Color) {
    val half = strokeWidth * 1.7f
    val left = Offset(center.x - half, center.y)
    val right = Offset(center.x + half, center.y)
    drawLine(color = color, start = left, end = right, strokeWidth = strokeWidth * 0.5f, cap = StrokeCap.Round)
    drawCircle(color = color, radius = plateRadius, center = left)
    drawCircle(color = color, radius = plateRadius, center = right)
}

/** A faint line suggesting a machine/cable pulling toward [to] - marks a lift as machine-based. */
private fun DrawScope.cableLine(from: Offset, to: Offset, color: Color) {
    drawLine(color = color.copy(alpha = 0.30f), start = from, end = to, strokeWidth = size.height * 0.012f, cap = StrokeCap.Round)
}

/** A fixed overhead bar (pull-up bar) - thicker than a limb, with small end caps, that never moves. */
private fun DrawScope.fixedBar(left: Offset, right: Offset, strokeWidth: Float, color: Color) {
    drawLine(color = color, start = left, end = right, strokeWidth = strokeWidth * 0.6f, cap = StrokeCap.Round)
    drawLine(color = color.copy(alpha = 0.55f), start = Offset(left.x, left.y - strokeWidth * 0.9f), end = Offset(left.x, left.y + strokeWidth * 0.9f), strokeWidth = strokeWidth * 0.35f, cap = StrokeCap.Round)
    drawLine(color = color.copy(alpha = 0.55f), start = Offset(right.x, right.y - strokeWidth * 0.9f), end = Offset(right.x, right.y + strokeWidth * 0.9f), strokeWidth = strokeWidth * 0.35f, cap = StrokeCap.Round)
}

private fun DrawScope.ground(y: Float, color: Color) {
    drawLine(
        color = color.copy(alpha = 0.25f),
        start = Offset(size.width * 0.08f, y),
        end = Offset(size.width * 0.92f, y),
        strokeWidth = size.height * 0.018f,
        cap = StrokeCap.Round
    )
}

/** A flat horizontal line suggesting a bench, seat, or incline pad under the body. */
private fun DrawScope.seatLine(from: Offset, to: Offset, color: Color) {
    drawLine(color = color.copy(alpha = 0.25f), start = from, end = to, strokeWidth = size.height * 0.02f, cap = StrokeCap.Round)
}

// ---- Back ----

/** Standing figure hip-hinging a bar up off the floor to lockout, knees bending a little. */
private fun DrawScope.drawDeadlift(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.11f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = lerp(h * 0.66f, h * 0.60f, phase)
    val shoulderX = lerp(centerX - w * 0.03f, centerX, phase)
    val shoulderY = lerp(h * 0.48f, h * 0.34f, phase)
    val headCenter = Offset(shoulderX, shoulderY - headR - sw * 0.4f)
    val kneeY = lerp(h * 0.78f, h * 0.74f, phase)
    val footSpread = w * 0.06f

    val barY = lerp(groundY - h * 0.06f, hipY - h * 0.02f, phase)
    val leftHand = Offset(centerX - w * 0.05f, barY)
    val rightHand = Offset(centerX + w * 0.05f, barY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(shoulderX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread * 0.6f, kneeY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread * 0.6f, kneeY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(shoulderX, shoulderY), leftHand))
    limb(sw, color, listOf(Offset(shoulderX, shoulderY), rightHand))
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Standing figure bent forward at the hips, rowing a bar up to the torso and back down. */
private fun DrawScope.drawBentOverRow(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.09f
    val plateR = h * 0.095f
    val groundY = h * 0.90f

    val hip = Offset(w * 0.52f, h * 0.62f)
    val torsoLength = h * 0.30f
    val shoulder = Offset(hip.x - torsoLength * 0.62f, hip.y - torsoLength * 0.78f)
    val headCenter = Offset(shoulder.x - headR * 0.5f, shoulder.y - headR - sw * 0.3f)
    val footSpread = w * 0.05f

    val lowBarY = groundY - h * 0.10f
    val highBarY = shoulder.y + h * 0.10f
    val barY = lerp(lowBarY, highBarY, phase)
    val handSpread = w * 0.10f
    val leftHand = Offset(shoulder.x - handSpread, barY)
    val rightHand = Offset(shoulder.x + handSpread, barY)

    val elbowY = lerp(shoulder.y + (lowBarY - shoulder.y) * 0.55f, shoulder.y + h * 0.06f, phase)
    val elbowSpread = lerp(handSpread * 0.7f, handSpread * 1.3f, phase)
    val leftElbow = Offset(shoulder.x - elbowSpread, elbowY)
    val rightElbow = Offset(shoulder.x + elbowSpread, elbowY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(shoulder, hip))
    limb(sw, color, listOf(hip, Offset(hip.x - footSpread, groundY)))
    limb(sw, color, listOf(hip, Offset(hip.x + footSpread, groundY)))
    limb(sw, color, listOf(shoulder, leftElbow, leftHand))
    limb(sw, color, listOf(shoulder, rightElbow, rightHand))
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Seated figure pulling a cable bar down from overhead to the upper chest. */
private fun DrawScope.drawLatPulldown(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f
    val groundY = h * 0.92f

    val centerX = w * 0.5f
    val hipY = h * 0.68f
    val shoulderY = h * 0.40f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.3f)
    val kneeX = centerX + w * 0.14f
    val kneeY = h * 0.78f
    val footX = centerX + w * 0.10f

    val pulleyPoint = Offset(centerX, h * 0.02f)
    val barY = lerp(headCenter.y - h * 0.10f, shoulderY + h * 0.04f, phase)
    val handSpread = w * 0.20f
    val leftHand = Offset(centerX - handSpread, barY)
    val rightHand = Offset(centerX + handSpread, barY)
    val elbowY = lerp(shoulderY - h * 0.02f, shoulderY + h * 0.10f, phase)
    val elbowSpread = lerp(handSpread * 0.9f, handSpread * 0.5f, phase)
    val leftElbow = Offset(centerX - elbowSpread, elbowY)
    val rightElbow = Offset(centerX + elbowSpread, elbowY)

    cableLine(pulleyPoint, Offset(centerX, barY), color)
    seatLine(Offset(centerX - w * 0.10f, hipY + sw * 0.6f), Offset(centerX + w * 0.10f, hipY + sw * 0.6f), color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(kneeX, kneeY), Offset(footX, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), leftElbow, leftHand))
    limb(sw, color, listOf(Offset(centerX, shoulderY), rightElbow, rightHand))
    bar(leftHand, rightHand, sw, h * 0.06f, color)
}

/** Figure hanging from a fixed overhead bar, pulling the body up and lowering back down. */
private fun DrawScope.drawPullUp(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f

    val centerX = w * 0.5f
    val barY = h * 0.14f
    val handSpread = w * 0.16f
    val leftHand = Offset(centerX - handSpread, barY)
    val rightHand = Offset(centerX + handSpread, barY)

    val shoulderY = lerp(barY + h * 0.32f, barY + h * 0.10f, phase)
    val hipY = shoulderY + h * 0.20f
    val kneeY = hipY + h * 0.14f
    val footY = kneeY + h * 0.08f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.3f)

    val elbowY = lerp(shoulderY + h * 0.02f, (shoulderY + barY) / 2f + h * 0.02f, phase)
    val elbowSpread = lerp(handSpread * 0.85f, handSpread * 0.5f, phase)
    val leftElbow = Offset(centerX - elbowSpread, elbowY)
    val rightElbow = Offset(centerX + elbowSpread, elbowY)

    fixedBar(Offset(centerX - handSpread * 1.6f, barY), Offset(centerX + handSpread * 1.6f, barY), sw, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + w * 0.03f, kneeY), Offset(centerX + w * 0.05f, footY)))
    limb(sw, color, listOf(leftHand, leftElbow, Offset(centerX, shoulderY)))
    limb(sw, color, listOf(rightHand, rightElbow, Offset(centerX, shoulderY)))
}

/** Seated figure, legs extended forward, pulling a cable handle horizontally into the torso. */
private fun DrawScope.drawSeatedCableRow(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f

    val hipY = h * 0.66f
    val hipX = w * 0.42f
    val shoulderX = lerp(hipX + w * 0.12f, hipX - w * 0.02f, phase)
    val shoulderY = lerp(h * 0.44f, h * 0.36f, phase)
    val headCenter = Offset(shoulderX, shoulderY - headR - sw * 0.3f)
    val footX = hipX + w * 0.34f

    val stackPoint = Offset(w * 0.90f, hipY)
    val handX = lerp(w * 0.62f, shoulderX + w * 0.06f, phase)
    val elbowX = lerp(shoulderX + w * 0.16f, shoulderX + w * 0.02f, phase)

    cableLine(stackPoint, Offset(handX, shoulderY), color)
    seatLine(Offset(hipX - w * 0.06f, hipY + sw * 0.5f), Offset(hipX + w * 0.06f, hipY + sw * 0.5f), color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(shoulderX, shoulderY), Offset(hipX, hipY)))
    limb(sw, color, listOf(Offset(hipX, hipY), Offset(footX, hipY)))
    limb(sw, color, listOf(Offset(shoulderX, shoulderY), Offset(elbowX, shoulderY), Offset(handX, shoulderY)))
    dumbbell(Offset(handX, shoulderY), sw, h * 0.055f, color)
}

// ---- Chest ----

/** Figure lying on a bench, one knee bent to the floor, pressing a bar up off the chest. */
private fun DrawScope.drawBenchPress(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.10f

    val shoulderX = w * 0.32f
    val hipX = w * 0.62f
    val torsoY = h * 0.56f
    val headCenter = Offset(shoulderX - headR - sw * 0.6f, torsoY - sw * 0.2f)
    val kneeX = hipX + w * 0.06f
    val kneeY = torsoY + h * 0.16f
    val footX = hipX - w * 0.02f
    val floorY = h * 0.88f

    val chestX = shoulderX + (hipX - shoulderX) * 0.2f
    val closeBarY = torsoY - h * 0.10f
    val farBarY = torsoY - h * 0.42f
    val barY = lerp(closeBarY, farBarY, phase)
    val handSpread = w * 0.15f
    val leftHand = Offset(chestX - handSpread, barY)
    val rightHand = Offset(chestX + handSpread, barY)

    seatLine(Offset(shoulderX - w * 0.05f, torsoY + sw * 0.7f), Offset(hipX + w * 0.05f, torsoY + sw * 0.7f), color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(shoulderX, torsoY), Offset(hipX, torsoY)))
    limb(sw, color, listOf(Offset(hipX, torsoY), Offset(kneeX, kneeY), Offset(footX, floorY)))
    limb(sw, color, listOf(Offset(chestX, torsoY), leftHand))
    limb(sw, color, listOf(Offset(chestX, torsoY), rightHand))
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Figure on a raised incline bench, pressing two dumbbells up and together over the upper chest. */
private fun DrawScope.drawInclineDumbbellPress(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.09f
    val plateR = h * 0.075f

    val shoulder = Offset(w * 0.26f, h * 0.42f)
    val hip = Offset(w * 0.60f, h * 0.64f)
    val headCenter = Offset(shoulder.x - headR - sw * 0.6f, shoulder.y - sw * 0.1f)
    val kneeX = hip.x + w * 0.06f
    val kneeY = hip.y + h * 0.14f
    val footX = hip.x - w * 0.02f
    val floorY = h * 0.88f

    val chestX = lerp(shoulder.x, hip.x, 0.22f)
    val chestY = lerp(shoulder.y, hip.y, 0.22f)
    val closeY = chestY - h * 0.08f
    val farY = chestY - h * 0.40f
    val barY = lerp(closeY, farY, phase)
    val handSpread = lerp(w * 0.13f, w * 0.05f, phase)
    val leftHand = Offset(chestX - handSpread, barY)
    val rightHand = Offset(chestX + handSpread, barY)

    seatLine(Offset(shoulder.x - w * 0.04f, shoulder.y + sw * 0.8f), Offset(hip.x + w * 0.05f, hip.y + sw * 0.7f), color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(shoulder, hip))
    limb(sw, color, listOf(hip, Offset(kneeX, kneeY), Offset(footX, floorY)))
    limb(sw, color, listOf(Offset(chestX, chestY), leftHand))
    limb(sw, color, listOf(Offset(chestX, chestY), rightHand))
    dumbbell(leftHand, sw, plateR, color)
    dumbbell(rightHand, sw, plateR, color)
}

/** Bodyweight plank figure, hands and feet planted, the whole body rising and lowering. */
private fun DrawScope.drawPushUp(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.085f
    val groundY = h * 0.86f

    val bodyY = lerp(groundY - h * 0.06f, groundY - h * 0.24f, phase)
    val shoulder = Offset(w * 0.36f, bodyY)
    val hip = Offset(w * 0.62f, bodyY + h * 0.015f)
    val headCenter = Offset(shoulder.x - headR - sw * 0.7f, shoulder.y)
    val foot = Offset(w * 0.86f, groundY)
    val hand = Offset(shoulder.x, groundY)
    val elbowX = shoulder.x + w * 0.05f * (1f - phase)
    val elbowY = (shoulder.y + groundY) / 2f

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(shoulder, hip))
    limb(sw, color, listOf(hip, foot))
    limb(sw, color, listOf(shoulder, Offset(elbowX, elbowY), hand))
}

/** Standing figure sweeping two cables from wide out at the sides to meet in front of the chest. */
private fun DrawScope.drawCableFly(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.62f
    val shoulderY = h * 0.36f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f

    val leftHandX = lerp(centerX - w * 0.36f, centerX - w * 0.04f, phase)
    val rightHandX = lerp(centerX + w * 0.36f, centerX + w * 0.04f, phase)
    val handY = shoulderY - h * 0.02f * phase
    val leftElbow = Offset((centerX + leftHandX) / 2f, shoulderY + h * 0.02f)
    val rightElbow = Offset((centerX + rightHandX) / 2f, shoulderY + h * 0.02f)

    cableLine(Offset(0f, shoulderY), Offset(leftHandX, handY), color)
    cableLine(Offset(w, shoulderY), Offset(rightHandX, handY), color)
    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), leftElbow, Offset(leftHandX, handY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), rightElbow, Offset(rightHandX, handY)))
    drawCircle(color = color, radius = h * 0.035f, center = Offset(leftHandX, handY))
    drawCircle(color = color, radius = h * 0.035f, center = Offset(rightHandX, handY))
}

// ---- Arms ----

/** Standing figure with the upper arm fixed at the side, curling a barbell from thigh to shoulder. */
private fun DrawScope.drawCurl(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.085f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.62f
    val shoulderY = h * 0.34f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f
    val elbow = Offset(centerX + w * 0.12f, h * 0.58f)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), elbow))

    val forearmLength = h * 0.24f
    rotate(degrees = -100f * phase, pivot = elbow) {
        val hand = Offset(elbow.x, elbow.y - forearmLength)
        limb(sw, color, listOf(elbow, hand))
        bar(Offset(hand.x - w * 0.10f, hand.y), Offset(hand.x + w * 0.10f, hand.y), sw, plateR, color)
    }
}

/** Standing figure curling a dumbbell in each hand, palms facing in, close to the body. */
private fun DrawScope.drawHammerCurl(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.07f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.62f
    val shoulderY = h * 0.34f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f
    val leftElbow = Offset(centerX - w * 0.09f, h * 0.58f)
    val rightElbow = Offset(centerX + w * 0.09f, h * 0.58f)
    val forearmLength = h * 0.22f

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), leftElbow))
    limb(sw, color, listOf(Offset(centerX, shoulderY), rightElbow))

    rotate(degrees = -80f * phase, pivot = leftElbow) {
        val hand = Offset(leftElbow.x, leftElbow.y - forearmLength)
        limb(sw, color, listOf(leftElbow, hand))
        dumbbell(hand, sw, plateR, color)
    }
    rotate(degrees = 80f * phase, pivot = rightElbow) {
        val hand = Offset(rightElbow.x, rightElbow.y - forearmLength)
        limb(sw, color, listOf(rightElbow, hand))
        dumbbell(hand, sw, plateR, color)
    }
}

/** Standing figure at a high cable, upper arm pinned to the torso, pushing a bar down to lockout. */
private fun DrawScope.drawTricepPushdown(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.06f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.62f
    val shoulderY = h * 0.34f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f
    val elbow = Offset(centerX + w * 0.06f, h * 0.50f)
    val forearmLength = h * 0.22f

    cableLine(Offset(centerX + w * 0.06f, 0f), elbow, color)
    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), elbow))

    rotate(degrees = 100f * phase, pivot = elbow) {
        val hand = Offset(elbow.x, elbow.y - forearmLength)
        limb(sw, color, listOf(elbow, hand))
        bar(Offset(hand.x - w * 0.08f, hand.y), Offset(hand.x + w * 0.08f, hand.y), sw, plateR, color)
    }
}

/** Figure lying on a bench, upper arms fixed pointing up, hinging a narrow bar to the forehead and back. */
private fun DrawScope.drawSkullCrusher(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f
    val plateR = h * 0.065f

    val shoulderX = w * 0.32f
    val hipX = w * 0.62f
    val torsoY = h * 0.56f
    val headCenter = Offset(shoulderX - headR - sw * 0.6f, torsoY - sw * 0.2f)
    val kneeX = hipX + w * 0.06f
    val kneeY = torsoY + h * 0.16f
    val footX = hipX - w * 0.02f
    val floorY = h * 0.88f

    val elbow = Offset(shoulderX + w * 0.05f, torsoY - h * 0.22f)
    val handX = lerp(headCenter.x + w * 0.14f, elbow.x, phase)
    val handY = lerp(headCenter.y + h * 0.02f, elbow.y - h * 0.16f, phase)

    seatLine(Offset(shoulderX - w * 0.05f, torsoY + sw * 0.7f), Offset(hipX + w * 0.05f, torsoY + sw * 0.7f), color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(shoulderX, torsoY), Offset(hipX, torsoY)))
    limb(sw, color, listOf(Offset(hipX, torsoY), Offset(kneeX, kneeY), Offset(footX, floorY)))
    limb(sw, color, listOf(Offset(shoulderX, torsoY), elbow))
    limb(sw, color, listOf(elbow, Offset(handX, handY)))
    bar(Offset(handX - w * 0.06f, handY), Offset(handX + w * 0.06f, handY), sw, plateR, color)
}

// ---- Shoulders ----

/** Standing figure pressing a bar from the shoulders straight overhead and back down. */
private fun DrawScope.drawOverheadPress(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.10f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.60f
    val shoulderY = h * 0.36f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.07f

    val rackedBarY = shoulderY - h * 0.02f
    val overheadBarY = headCenter.y - headR - h * 0.10f
    val barY = lerp(rackedBarY, overheadBarY, phase)
    val handSpread = w * 0.16f
    val leftHand = Offset(centerX - handSpread, barY)
    val rightHand = Offset(centerX + handSpread, barY)

    val elbowY = lerp(shoulderY + h * 0.06f, (shoulderY + barY) / 2f, phase)
    val elbowSpread = lerp(handSpread * 0.75f, handSpread * 0.4f, phase)
    val leftElbow = Offset(centerX - elbowSpread, elbowY)
    val rightElbow = Offset(centerX + elbowSpread, elbowY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), leftElbow, leftHand))
    limb(sw, color, listOf(Offset(centerX, shoulderY), rightElbow, rightHand))
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Standing figure raising two dumbbells out to the sides to shoulder height and back down. */
private fun DrawScope.drawLateralRaise(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.065f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.62f
    val shoulderY = h * 0.36f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f

    val leftHandX = lerp(centerX - w * 0.04f, centerX - w * 0.32f, phase)
    val rightHandX = lerp(centerX + w * 0.04f, centerX + w * 0.32f, phase)
    val handY = lerp(hipY, shoulderY, phase)
    val leftElbow = Offset(lerp(centerX - w * 0.03f, centerX - w * 0.18f, phase), lerp(hipY - h * 0.05f, shoulderY, phase))
    val rightElbow = Offset(lerp(centerX + w * 0.03f, centerX + w * 0.18f, phase), lerp(hipY - h * 0.05f, shoulderY, phase))

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), leftElbow, Offset(leftHandX, handY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), rightElbow, Offset(rightHandX, handY)))
    dumbbell(Offset(leftHandX, handY), sw, plateR, color)
    dumbbell(Offset(rightHandX, handY), sw, plateR, color)
}

/** Bent-over figure sweeping two dumbbells out to the sides (reverse fly) and back together. */
private fun DrawScope.drawRearDeltFly(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.09f
    val plateR = h * 0.06f
    val groundY = h * 0.90f

    val hip = Offset(w * 0.52f, h * 0.62f)
    val torsoLength = h * 0.30f
    val shoulder = Offset(hip.x - torsoLength * 0.62f, hip.y - torsoLength * 0.78f)
    val headCenter = Offset(shoulder.x - headR * 0.5f, shoulder.y - headR - sw * 0.3f)
    val footSpread = w * 0.05f

    val leftHandX = lerp(shoulder.x - w * 0.03f, shoulder.x - w * 0.26f, phase)
    val rightHandX = lerp(shoulder.x + w * 0.03f, shoulder.x + w * 0.26f, phase)
    val handY = lerp(shoulder.y + h * 0.14f, shoulder.y - h * 0.02f, phase)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(shoulder, hip))
    limb(sw, color, listOf(hip, Offset(hip.x - footSpread, groundY)))
    limb(sw, color, listOf(hip, Offset(hip.x + footSpread, groundY)))
    limb(sw, color, listOf(shoulder, Offset(leftHandX, handY)))
    limb(sw, color, listOf(shoulder, Offset(rightHandX, handY)))
    dumbbell(Offset(leftHandX, handY), sw, plateR, color)
    dumbbell(Offset(rightHandX, handY), sw, plateR, color)
}

/** Standing figure pulling a cable rope in toward the face, elbows flaring high and wide. */
private fun DrawScope.drawFacePull(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.62f
    val shoulderY = h * 0.36f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f

    val leftHandX = lerp(centerX - w * 0.02f, centerX - w * 0.16f, phase)
    val rightHandX = lerp(centerX + w * 0.02f, centerX + w * 0.16f, phase)
    val handY = lerp(shoulderY, headCenter.y + headR * 0.6f, phase)
    val leftElbow = Offset(lerp(centerX - w * 0.05f, centerX - w * 0.30f, phase), lerp(shoulderY + h * 0.05f, shoulderY - h * 0.06f, phase))
    val rightElbow = Offset(lerp(centerX + w * 0.05f, centerX + w * 0.30f, phase), lerp(shoulderY + h * 0.05f, shoulderY - h * 0.06f, phase))

    cableLine(Offset(w * 0.96f, shoulderY), Offset((leftHandX + rightHandX) / 2f, handY), color)
    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), leftElbow, Offset(leftHandX, handY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), rightElbow, Offset(rightHandX, handY)))
    drawCircle(color = color, radius = h * 0.03f, center = Offset(leftHandX, handY))
    drawCircle(color = color, radius = h * 0.03f, center = Offset(rightHandX, handY))
}

// ---- Forearms ----

/** Seated figure with the forearm braced on the knee, curling a light bar up with just the wrist. */
private fun DrawScope.drawWristCurl(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f
    val plateR = h * 0.07f
    val floorY = h * 0.90f

    val hip = Offset(w * 0.40f, h * 0.62f)
    val shoulder = Offset(hip.x - w * 0.02f, h * 0.36f)
    val headCenter = Offset(shoulder.x, shoulder.y - headR - sw * 0.3f)
    val knee = Offset(hip.x + w * 0.22f, h * 0.62f)
    val foot = Offset(hip.x + w * 0.02f, floorY)

    val pivot = Offset(knee.x + w * 0.10f, knee.y - h * 0.02f)
    val elbow = Offset(shoulder.x + w * 0.05f, h * 0.52f)

    head(headCenter, headR, color)
    limb(sw, color, listOf(shoulder, hip))
    limb(sw, color, listOf(hip, knee))
    limb(sw, color, listOf(knee, foot))
    limb(sw, color, listOf(shoulder, elbow, pivot))

    val handLength = h * 0.10f
    rotate(degrees = -35f * phase, pivot = pivot) {
        val hand = Offset(pivot.x, pivot.y - handLength)
        limb(sw, color, listOf(pivot, hand))
        bar(Offset(hand.x - w * 0.08f, hand.y), Offset(hand.x + w * 0.08f, hand.y), sw, plateR, color)
    }
}

/** Same seated setup as the wrist curl, but the wrist extends the bar upward the other way. */
private fun DrawScope.drawReverseWristCurl(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f
    val plateR = h * 0.07f
    val floorY = h * 0.90f

    val hip = Offset(w * 0.40f, h * 0.62f)
    val shoulder = Offset(hip.x - w * 0.02f, h * 0.36f)
    val headCenter = Offset(shoulder.x, shoulder.y - headR - sw * 0.3f)
    val knee = Offset(hip.x + w * 0.22f, h * 0.62f)
    val foot = Offset(hip.x + w * 0.02f, floorY)

    val pivot = Offset(knee.x + w * 0.10f, knee.y - h * 0.02f)
    val elbow = Offset(shoulder.x + w * 0.05f, h * 0.52f)

    head(headCenter, headR, color)
    limb(sw, color, listOf(shoulder, hip))
    limb(sw, color, listOf(hip, knee))
    limb(sw, color, listOf(knee, foot))
    limb(sw, color, listOf(shoulder, elbow, pivot))

    val handLength = h * 0.10f
    rotate(degrees = 35f * phase, pivot = pivot) {
        val hand = Offset(pivot.x, pivot.y + handLength)
        limb(sw, color, listOf(pivot, hand))
        bar(Offset(hand.x - w * 0.08f, hand.y), Offset(hand.x + w * 0.08f, hand.y), sw, plateR, color)
    }
}

/** Standing curl with an overhand grip - a shorter, stricter range than the underhand barbell curl. */
private fun DrawScope.drawReverseCurl(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.075f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.62f
    val shoulderY = h * 0.34f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f
    val elbow = Offset(centerX + w * 0.14f, h * 0.58f)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), elbow))

    val forearmLength = h * 0.22f
    rotate(degrees = -85f * phase, pivot = elbow) {
        val hand = Offset(elbow.x, elbow.y - forearmLength)
        limb(sw, color, listOf(elbow, hand))
        bar(Offset(hand.x - w * 0.09f, hand.y), Offset(hand.x + w * 0.09f, hand.y), sw, plateR, color)
    }
}

// ---- Legs ----

/** Standing figure with a bar racked across the shoulders, squatting down and back up. */
private fun DrawScope.drawSquat(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.10f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val shoulderY = lerp(h * 0.30f, h * 0.46f, phase)
    val hipY = lerp(h * 0.55f, h * 0.70f, phase)
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val kneeY = lerp(h * 0.74f, h * 0.80f, phase)
    val kneeForward = w * 0.06f * phase
    val footSpread = w * 0.09f

    val barY = shoulderY - sw * 0.7f
    val handSpread = w * 0.20f
    val leftHand = Offset(centerX - handSpread, barY)
    val rightHand = Offset(centerX + handSpread, barY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread * 0.7f + kneeForward, kneeY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread * 0.7f + kneeForward, kneeY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX - w * 0.06f, shoulderY), leftHand))
    limb(sw, color, listOf(Offset(centerX + w * 0.06f, shoulderY), rightHand))
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Reclined seated figure pressing a foot platform away with the legs, from bent to extended. */
private fun DrawScope.drawLegPress(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.09f

    val shoulder = Offset(w * 0.24f, h * 0.48f)
    val hip = Offset(w * 0.42f, h * 0.62f)
    val headCenter = Offset(shoulder.x - headR * 0.6f, shoulder.y - headR - sw * 0.3f)

    val footX = lerp(hip.x + w * 0.16f, hip.x + w * 0.44f, phase)
    val footY = lerp(hip.y - h * 0.10f, hip.y - h * 0.20f, phase)
    val kneeX = (hip.x + footX) / 2f + w * 0.02f
    val kneeY = (hip.y + footY) / 2f - h * 0.03f

    seatLine(Offset(shoulder.x - w * 0.04f, shoulder.y + sw * 0.8f), Offset(hip.x + w * 0.04f, hip.y + sw * 0.6f), color)
    drawLine(color = color.copy(alpha = 0.35f), start = Offset(footX, footY - h * 0.09f), end = Offset(footX, footY + h * 0.09f), strokeWidth = h * 0.03f, cap = StrokeCap.Round)
    head(headCenter, headR, color)
    limb(sw, color, listOf(shoulder, hip))
    limb(sw, color, listOf(hip, Offset(kneeX, kneeY), Offset(footX, footY)))
}

/** Standing figure hip-hinging with almost-straight legs, the bar sliding down the shins and back up. */
private fun DrawScope.drawRomanianDeadlift(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.10f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipX = lerp(centerX + w * 0.10f, centerX, phase)
    val hipY = h * 0.60f
    val shoulderX = lerp(centerX - w * 0.08f, centerX, phase)
    val shoulderY = lerp(h * 0.46f, h * 0.34f, phase)
    val headCenter = Offset(shoulderX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.05f

    val barY = lerp(groundY - h * 0.10f, hipY - h * 0.02f, phase)
    val leftHand = Offset(hipX - w * 0.04f, barY)
    val rightHand = Offset(hipX + w * 0.04f, barY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(shoulderX, shoulderY), Offset(hipX, hipY)))
    limb(sw, color, listOf(Offset(hipX, hipY), Offset(hipX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(hipX, hipY), Offset(hipX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(shoulderX, shoulderY), leftHand))
    limb(sw, color, listOf(Offset(shoulderX, shoulderY), rightHand))
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Standing figure stepping into a lunge - one leg forward and bent, the other trailing behind. */
private fun DrawScope.drawLunge(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f
    val plateR = h * 0.06f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = lerp(h * 0.56f, h * 0.72f, phase)
    val shoulderY = lerp(h * 0.30f, h * 0.42f, phase)
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)

    val frontFootX = centerX + w * 0.16f
    val frontKneeX = centerX + w * 0.10f
    val frontKneeY = hipY - h * 0.02f

    val backFootX = centerX - w * 0.14f
    val backKneeX = centerX - w * 0.06f
    val backKneeY = lerp(hipY + h * 0.10f, groundY - h * 0.06f, phase)

    val handY = hipY + h * 0.06f
    val leftHandX = centerX - w * 0.10f
    val rightHandX = centerX + w * 0.10f

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(frontKneeX, frontKneeY), Offset(frontFootX, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(backKneeX, backKneeY), Offset(backFootX, groundY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(leftHandX, handY)))
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(rightHandX, handY)))
    dumbbell(Offset(leftHandX, handY), sw, plateR, color)
    dumbbell(Offset(rightHandX, handY), sw, plateR, color)
}

/** Seated figure, upper body still, the lower leg swinging from bent to fully extended out front. */
private fun DrawScope.drawLegExtension(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f

    val centerX = w * 0.42f
    val hipY = h * 0.62f
    val shoulderY = h * 0.36f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.3f)
    val kneeX = centerX + w * 0.20f
    val kneeY = hipY - h * 0.02f

    val footX = lerp(kneeX, kneeX + w * 0.22f, phase)
    val footY = lerp(kneeY + h * 0.20f, kneeY + h * 0.02f, phase)

    seatLine(Offset(centerX - w * 0.06f, hipY + sw * 0.5f), Offset(centerX + w * 0.06f, hipY + sw * 0.5f), color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(kneeX, kneeY)))
    limb(sw, color, listOf(Offset(kneeX, kneeY), Offset(footX, footY)))
    drawCircle(color = color.copy(alpha = 0.6f), radius = h * 0.03f, center = Offset(footX, footY))
}

/** Standing figure with a bar racked on the shoulders, rising onto the toes and back down. */
private fun DrawScope.drawCalfRaise(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.09f
    val groundY = h * 0.90f
    val lift = h * 0.035f * phase

    val centerX = w * 0.5f
    val shoulderY = h * 0.34f - lift
    val hipY = h * 0.60f - lift
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f

    val barY = shoulderY - sw * 0.7f
    val handSpread = w * 0.16f
    val leftHand = Offset(centerX - handSpread, barY)
    val rightHand = Offset(centerX + handSpread, barY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, listOf(Offset(centerX, shoulderY), Offset(centerX, hipY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX - footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX, hipY), Offset(centerX + footSpread, groundY)))
    limb(sw, color, listOf(Offset(centerX - w * 0.06f, shoulderY), leftHand))
    limb(sw, color, listOf(Offset(centerX + w * 0.06f, shoulderY), rightHand))
    bar(leftHand, rightHand, sw, plateR, color)
}
