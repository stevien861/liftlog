package com.stevie.liftlog.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.data.MuscleCategory

/**
 * A small looping Canvas animation illustrating the general movement pattern for a muscle
 * category (press / pull / squat / curl) - not a real video, just a lightweight, always-available,
 * dependency-free visual cue shown on the exercise detail screen and referenced in onboarding.
 */
private enum class MovementPattern { VERTICAL_PRESS, HORIZONTAL_PULL, SQUAT, CURL, WRIST_CURL }

private fun movementPatternFor(category: MuscleCategory): MovementPattern = when (category) {
    MuscleCategory.CHEST -> MovementPattern.VERTICAL_PRESS
    MuscleCategory.SHOULDERS -> MovementPattern.VERTICAL_PRESS
    MuscleCategory.BACK -> MovementPattern.HORIZONTAL_PULL
    MuscleCategory.LEGS -> MovementPattern.SQUAT
    MuscleCategory.ARMS -> MovementPattern.CURL
    MuscleCategory.FOREARMS -> MovementPattern.WRIST_CURL
}

@Composable
fun MovementDemoAnimation(category: MuscleCategory, modifier: Modifier = Modifier) {
    val pattern = movementPatternFor(category)
    val color = categoryColor(category)
    val transition = rememberInfiniteTransition()
    val periodMillis = if (pattern == MovementPattern.WRIST_CURL) 900 else 1400
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = periodMillis),
            repeatMode = RepeatMode.Reverse
        )
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(96.dp)
    ) {
        val barLength = size.width * 0.5f
        val plateRadius = size.height * 0.16f
        val strokeWidth = size.height * 0.08f
        val centerX = size.width / 2f

        when (pattern) {
            MovementPattern.VERTICAL_PRESS -> {
                val travel = size.height * 0.35f
                val barY = size.height * 0.68f - phase * travel
                drawBarbell(centerX, barY, barLength, plateRadius, strokeWidth, color)
            }

            MovementPattern.HORIZONTAL_PULL -> {
                val travel = size.width * 0.22f
                val barX = centerX - travel / 2f + phase * travel
                drawBarbell(barX, size.height / 2f, barLength * 0.7f, plateRadius, strokeWidth, color)
            }

            MovementPattern.SQUAT -> {
                val travel = size.height * 0.28f
                val barY = size.height * 0.32f + phase * travel
                drawBarbell(centerX, barY, barLength, plateRadius, strokeWidth, color)
            }

            MovementPattern.CURL -> {
                val pivot = Offset(centerX, size.height * 0.85f)
                val armLength = size.height * 0.55f
                rotate(degrees = -80f * phase, pivot = pivot) {
                    drawBarbell(pivot.x, pivot.y - armLength, barLength * 0.6f, plateRadius * 0.8f, strokeWidth * 0.8f, color)
                }
            }

            MovementPattern.WRIST_CURL -> {
                val pivot = Offset(centerX, size.height * 0.6f)
                val armLength = size.height * 0.22f
                rotate(degrees = -35f * phase, pivot = pivot) {
                    drawBarbell(pivot.x, pivot.y - armLength, barLength * 0.4f, plateRadius * 0.6f, strokeWidth * 0.6f, color)
                }
            }
        }
    }
}

private fun DrawScope.drawBarbell(
    x: Float,
    y: Float,
    barLength: Float,
    plateRadius: Float,
    strokeWidth: Float,
    color: Color
) {
    drawLine(
        color = color,
        start = Offset(x - barLength / 2f, y),
        end = Offset(x + barLength / 2f, y),
        strokeWidth = strokeWidth,
        cap = StrokeCap.Round
    )
    drawCircle(color = color, radius = plateRadius, center = Offset(x - barLength / 2f, y))
    drawCircle(color = color, radius = plateRadius, center = Offset(x + barLength / 2f, y))
}
