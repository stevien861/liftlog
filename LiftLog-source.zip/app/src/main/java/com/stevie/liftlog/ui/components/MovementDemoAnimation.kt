package com.stevie.liftlog.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.data.MuscleCategory

/**
 * A small looping Canvas animation illustrating the correct movement pattern for a muscle
 * category, drawn as a simple lifter figure actually performing the lift (a standing overhead
 * press, a lying bench press, a bent-over row, a back squat, a standing curl, a seated wrist
 * curl) rather than just a floating barbell - not a real video, just a lightweight,
 * always-available, dependency-free visual cue shown on the exercise detail screen and
 * referenced in onboarding.
 */
private enum class MovementPattern { OVERHEAD_PRESS, BENCH_PRESS, BENT_OVER_ROW, SQUAT, CURL, WRIST_CURL }

private fun movementPatternFor(category: MuscleCategory): MovementPattern = when (category) {
    MuscleCategory.CHEST -> MovementPattern.BENCH_PRESS
    MuscleCategory.SHOULDERS -> MovementPattern.OVERHEAD_PRESS
    MuscleCategory.BACK -> MovementPattern.BENT_OVER_ROW
    MuscleCategory.LEGS -> MovementPattern.SQUAT
    MuscleCategory.ARMS -> MovementPattern.CURL
    MuscleCategory.FOREARMS -> MovementPattern.WRIST_CURL
}

@Composable
fun MovementDemoAnimation(category: MuscleCategory, modifier: Modifier = Modifier) {
    val pattern = movementPatternFor(category)
    val color = categoryColor(category)
    val transition = rememberInfiniteTransition()
    val periodMillis = if (pattern == MovementPattern.WRIST_CURL) 900 else 1400
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = periodMillis),
            repeatMode = RepeatMode.Reverse
        )
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(112.dp)
    ) {
        when (pattern) {
            MovementPattern.OVERHEAD_PRESS -> drawOverheadPress(phase, color)
            MovementPattern.BENCH_PRESS -> drawBenchPress(phase, color)
            MovementPattern.BENT_OVER_ROW -> drawBentOverRow(phase, color)
            MovementPattern.SQUAT -> drawSquat(phase, color)
            MovementPattern.CURL -> drawCurl(phase, color)
            MovementPattern.WRIST_CURL -> drawWristCurl(phase, color)
        }
    }
}

// ---- Shared drawing helpers ----

private fun lerp(from: Float, to: Float, t: Float): Float = from + (to - from) * t

/** One or more connected line segments, e.g. shoulder -> elbow -> hand. */
private fun DrawScope.limb(strokeWidth: Float, color: Color, vararg points: Offset) {
    for (i in 0 until points.size - 1) {
        drawLine(color = color, start = points[i], end = points[i + 1], strokeWidth = strokeWidth, cap = StrokeCap.Round)
    }
}

private fun DrawScope.head(center: Offset, radius: Float, color: Color) {
    drawCircle(color = color, radius = radius, center = center)
}

/** A horizontal barbell: a thin bar with a plate at each end. */
private fun DrawScope.bar(left: Offset, right: Offset, strokeWidth: Float, plateRadius: Float, color: Color) {
    drawLine(color = color, start = left, end = right, strokeWidth = strokeWidth * 0.55f, cap = StrokeCap.Round)
    drawCircle(color = color, radius = plateRadius, center = left)
    drawCircle(color = color, radius = plateRadius, center = right)
}

private fun DrawScope.ground(y: Float, color: Color) {
    drawLine(
        color = color.copy(alpha = 0.25f),
        start = Offset(size.width * 0.08f, y),
        end = Offset(size.width * 0.92f, y),
        strokeWidth = size.height * 0.018f,
        cap = StrokeCap.Round
    )
}

// ---- Per-exercise lifter figures ----

/** Standing figure pressing a bar from the shoulders straight overhead and back down. */
private fun DrawScope.drawOverheadPress(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.10f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.60f
    val shoulderY = h * 0.36f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.07f

    val rackedBarY = shoulderY - h * 0.02f
    val overheadBarY = headCenter.y - headR - h * 0.10f
    val barY = lerp(rackedBarY, overheadBarY, phase)
    val handSpread = w * 0.16f
    val leftHand = Offset(centerX - handSpread, barY)
    val rightHand = Offset(centerX + handSpread, barY)

    val elbowY = lerp(shoulderY + h * 0.06f, (shoulderY + barY) / 2f, phase)
    val elbowSpread = lerp(handSpread * 0.75f, handSpread * 0.4f, phase)
    val leftElbow = Offset(centerX - elbowSpread, elbowY)
    val rightElbow = Offset(centerX + elbowSpread, elbowY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, Offset(centerX, shoulderY), Offset(centerX, hipY))
    limb(sw, color, Offset(centerX, hipY), Offset(centerX - footSpread, groundY))
    limb(sw, color, Offset(centerX, hipY), Offset(centerX + footSpread, groundY))
    limb(sw, color, Offset(centerX, shoulderY), leftElbow, leftHand)
    limb(sw, color, Offset(centerX, shoulderY), rightElbow, rightHand)
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Figure lying on a bench, one knee bent to the floor, pressing a bar up off the chest. */
private fun DrawScope.drawBenchPress(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.10f

    val shoulderX = w * 0.32f
    val hipX = w * 0.62f
    val torsoY = h * 0.56f
    val headCenter = Offset(shoulderX - headR - sw * 0.6f, torsoY - sw * 0.2f)
    val kneeX = hipX + w * 0.06f
    val kneeY = torsoY + h * 0.16f
    val footX = hipX - w * 0.02f
    val floorY = h * 0.88f

    val chestX = shoulderX + (hipX - shoulderX) * 0.2f
    val closeBarY = torsoY - h * 0.10f
    val farBarY = torsoY - h * 0.42f
    val barY = lerp(closeBarY, farBarY, phase)
    val handSpread = w * 0.15f
    val leftHand = Offset(chestX - handSpread, barY)
    val rightHand = Offset(chestX + handSpread, barY)

    // The bench itself, under the body.
    drawLine(
        color = color.copy(alpha = 0.25f),
        start = Offset(shoulderX - w * 0.05f, torsoY + sw * 0.7f),
        end = Offset(hipX + w * 0.05f, torsoY + sw * 0.7f),
        strokeWidth = h * 0.02f,
        cap = StrokeCap.Round
    )

    head(headCenter, headR, color)
    limb(sw, color, Offset(shoulderX, torsoY), Offset(hipX, torsoY))
    limb(sw, color, Offset(hipX, torsoY), Offset(kneeX, kneeY), Offset(footX, floorY))
    limb(sw, color, Offset(chestX, torsoY), leftHand)
    limb(sw, color, Offset(chestX, torsoY), rightHand)
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Standing figure bent forward at the hips, rowing a bar up to the torso and back down. */
private fun DrawScope.drawBentOverRow(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.09f
    val plateR = h * 0.095f
    val groundY = h * 0.90f

    val hip = Offset(w * 0.52f, h * 0.62f)
    val torsoLength = h * 0.30f
    // A fixed forward lean - the bend itself doesn't animate, only the pull does.
    val shoulder = Offset(hip.x - torsoLength * 0.62f, hip.y - torsoLength * 0.78f)
    val headCenter = Offset(shoulder.x - headR * 0.5f, shoulder.y - headR - sw * 0.3f)
    val footSpread = w * 0.05f

    val lowBarY = groundY - h * 0.10f
    val highBarY = shoulder.y + h * 0.10f
    val barY = lerp(lowBarY, highBarY, phase)
    val handSpread = w * 0.10f
    val leftHand = Offset(shoulder.x - handSpread, barY)
    val rightHand = Offset(shoulder.x + handSpread, barY)

    val elbowY = lerp(shoulder.y + (lowBarY - shoulder.y) * 0.55f, shoulder.y + h * 0.06f, phase)
    val elbowSpread = lerp(handSpread * 0.7f, handSpread * 1.3f, phase)
    val leftElbow = Offset(shoulder.x - elbowSpread, elbowY)
    val rightElbow = Offset(shoulder.x + elbowSpread, elbowY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, shoulder, hip)
    limb(sw, color, hip, Offset(hip.x - footSpread, groundY))
    limb(sw, color, hip, Offset(hip.x + footSpread, groundY))
    limb(sw, color, shoulder, leftElbow, leftHand)
    limb(sw, color, shoulder, rightElbow, rightHand)
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Standing figure with a bar racked across the shoulders, squatting down and back up. */
private fun DrawScope.drawSquat(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.10f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val shoulderY = lerp(h * 0.30f, h * 0.46f, phase)
    val hipY = lerp(h * 0.55f, h * 0.70f, phase)
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val kneeY = lerp(h * 0.74f, h * 0.80f, phase)
    val kneeForward = w * 0.06f * phase
    val footSpread = w * 0.09f

    val barY = shoulderY - sw * 0.7f
    val handSpread = w * 0.20f
    val leftHand = Offset(centerX - handSpread, barY)
    val rightHand = Offset(centerX + handSpread, barY)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, Offset(centerX, shoulderY), Offset(centerX, hipY))
    limb(sw, color, Offset(centerX, hipY), Offset(centerX - footSpread * 0.7f + kneeForward, kneeY), Offset(centerX - footSpread, groundY))
    limb(sw, color, Offset(centerX, hipY), Offset(centerX + footSpread * 0.7f + kneeForward, kneeY), Offset(centerX + footSpread, groundY))
    limb(sw, color, Offset(centerX - w * 0.06f, shoulderY), leftHand)
    limb(sw, color, Offset(centerX + w * 0.06f, shoulderY), rightHand)
    bar(leftHand, rightHand, sw, plateR, color)
}

/** Standing figure with the upper arm fixed at the side, curling a bar from thigh to shoulder. */
private fun DrawScope.drawCurl(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.055f
    val headR = h * 0.095f
    val plateR = h * 0.085f
    val groundY = h * 0.90f

    val centerX = w * 0.5f
    val hipY = h * 0.62f
    val shoulderY = h * 0.34f
    val headCenter = Offset(centerX, shoulderY - headR - sw * 0.4f)
    val footSpread = w * 0.06f
    val elbow = Offset(centerX + w * 0.12f, h * 0.58f)

    ground(groundY, color)
    head(headCenter, headR, color)
    limb(sw, color, Offset(centerX, shoulderY), Offset(centerX, hipY))
    limb(sw, color, Offset(centerX, hipY), Offset(centerX - footSpread, groundY))
    limb(sw, color, Offset(centerX, hipY), Offset(centerX + footSpread, groundY))
    limb(sw, color, Offset(centerX, shoulderY), elbow)

    val forearmLength = h * 0.24f
    rotate(degrees = -100f * phase, pivot = elbow) {
        val hand = Offset(elbow.x, elbow.y - forearmLength)
        limb(sw, color, elbow, hand)
        bar(Offset(hand.x - w * 0.10f, hand.y), Offset(hand.x + w * 0.10f, hand.y), sw, plateR, color)
    }
}

/** Seated figure with the forearm braced on the knee, curling a light bar with just the wrist. */
private fun DrawScope.drawWristCurl(phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.05f
    val headR = h * 0.09f
    val plateR = h * 0.07f
    val floorY = h * 0.90f

    val hip = Offset(w * 0.40f, h * 0.62f)
    val shoulder = Offset(hip.x - w * 0.02f, h * 0.36f)
    val headCenter = Offset(shoulder.x, shoulder.y - headR - sw * 0.3f)
    val knee = Offset(hip.x + w * 0.22f, h * 0.62f)
    val foot = Offset(hip.x + w * 0.02f, floorY)

    // The forearm rests on the knee - only the hand and bar pivot from here.
    val pivot = Offset(knee.x + w * 0.10f, knee.y - h * 0.02f)
    val elbow = Offset(shoulder.x + w * 0.05f, h * 0.52f)

    head(headCenter, headR, color)
    limb(sw, color, shoulder, hip)
    limb(sw, color, hip, knee)
    limb(sw, color, knee, foot)
    limb(sw, color, shoulder, elbow, pivot)

    val handLength = h * 0.10f
    rotate(degrees = -35f * phase, pivot = pivot) {
        val hand = Offset(pivot.x, pivot.y - handLength)
        limb(sw, color, pivot, hand)
        bar(Offset(hand.x - w * 0.08f, hand.y), Offset(hand.x + w * 0.08f, hand.y), sw, plateR, color)
    }
}
