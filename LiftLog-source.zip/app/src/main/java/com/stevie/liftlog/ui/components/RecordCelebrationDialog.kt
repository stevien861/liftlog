package com.stevie.liftlog.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.stevie.liftlog.stats.NewRecord
import com.stevie.liftlog.stats.RecordType
import com.stevie.liftlog.util.CelebrationEffects

/** A short celebration whenever a logged set breaks an all-time record - see [com.stevie.liftlog.stats.PersonalRecords]. */
@Composable
fun RecordCelebrationDialog(exerciseName: String, records: List<NewRecord>, onDismiss: () -> Unit) {
    if (records.isEmpty()) return

    val context = LocalContext.current
    LaunchedEffect(records) { CelebrationEffects.play(context) }

    ConfettiOverlay(trigger = records)

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.EmojiEvents, contentDescription = null) },
        title = { Text("New personal record!") },
        text = {
            Column {
                Text(exerciseName, style = MaterialTheme.typography.titleMedium)
                records.forEach { record ->
                    Text(
                        when (record.type) {
                            RecordType.HEAVIEST_WEIGHT -> "New heaviest weight: ${formatKg(record.valueKg)}kg"
                            RecordType.BEST_ESTIMATED_ONE_REP_MAX ->
                                "New best estimated 1-rep max: ${formatKg(record.valueKg)}kg"
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("Nice!") }
        }
    )
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
