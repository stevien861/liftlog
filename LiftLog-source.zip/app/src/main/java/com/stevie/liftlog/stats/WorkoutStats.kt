package com.stevie.liftlog.stats

import com.stevie.liftlog.data.SetEntryEntity

/**
 * The two personal-record types LiftLog tracks per exercise:
 *  - [RecordType.HEAVIEST_WEIGHT]: the most weight ever lifted for any single set.
 *  - [RecordType.BEST_ESTIMATED_ONE_REP_MAX]: the highest estimated 1-rep max ([PersonalRecords.estimatedOneRepMax])
 *    across any set, which rewards a heavy-for-reps set even if it isn't a new outright weight PR.
 */
enum class RecordType { HEAVIEST_WEIGHT, BEST_ESTIMATED_ONE_REP_MAX }

data class NewRecord(val type: RecordType, val valueKg: Double)

/**
 * All-time personal-record math. Kept as pure functions over a list of sets (no DB access) so it
 * can be unit tested directly, mirroring [com.stevie.liftlog.recommendation.ProgressionEngine].
 */
object PersonalRecords {

    /**
     * Epley formula - a standard, widely used estimate of what you could lift for one rep, based
     * on a heavier-than-1-rep set. Deliberately simple (the same spirit as [com.stevie.liftlog.recommendation.ProgressionEngine]):
     * an estimate to track trend and celebrate big sets, not a substitute for actually testing a 1RM.
     */
    fun estimatedOneRepMax(weightKg: Double, reps: Int): Double = when {
        reps <= 0 -> 0.0
        reps == 1 -> weightKg
        else -> weightKg * (1.0 + reps / 30.0)
    }

    fun bestWeightEver(history: List<SetEntryEntity>): Double? = history.maxOfOrNull { it.weightKg }

    fun bestEstimatedOneRepMaxEver(history: List<SetEntryEntity>): Double? =
        history.maxOfOrNull { estimatedOneRepMax(it.weightKg, it.reps) }

    /**
     * Compares a just-logged set against the history that existed BEFORE it was logged (pass the
     * snapshot from before the insert), and returns which all-time record(s), if any, it just
     * broke. Returns nothing for the very first set ever logged for an exercise - there's no
     * previous best yet to beat, so it's a baseline rather than a "record".
     */
    fun checkForNewRecords(priorHistory: List<SetEntryEntity>, newSet: SetEntryEntity): List<NewRecord> {
        if (priorHistory.isEmpty()) return emptyList()

        val records = mutableListOf<NewRecord>()

        val priorBestWeight = bestWeightEver(priorHistory) ?: 0.0
        if (newSet.weightKg > priorBestWeight) {
            records += NewRecord(RecordType.HEAVIEST_WEIGHT, newSet.weightKg)
        }

        val priorBest1rm = bestEstimatedOneRepMaxEver(priorHistory) ?: 0.0
        val new1rm = estimatedOneRepMax(newSet.weightKg, newSet.reps)
        if (new1rm > priorBest1rm) {
            records += NewRecord(RecordType.BEST_ESTIMATED_ONE_REP_MAX, new1rm)
        }

        return records
    }
}

/** Consistency and workload stats shown on the Stats screen - not tied to any one exercise. */
object WorkoutStats {

    /**
     * Consecutive days (ending today or yesterday) with at least one set logged. If nothing is
     * logged yet today, the streak still counts through yesterday - today just hasn't broken it
     * yet. Two or more missed days in a row resets it to 0.
     */
    fun computeStreakDays(workoutDatesEpochDay: Set<Long>, todayEpochDay: Long): Int {
        if (workoutDatesEpochDay.isEmpty()) return 0

        var day = todayEpochDay
        if (!workoutDatesEpochDay.contains(day)) {
            day -= 1
            if (!workoutDatesEpochDay.contains(day)) return 0
        }

        var streak = 0
        while (workoutDatesEpochDay.contains(day)) {
            streak++
            day -= 1
        }
        return streak
    }

    fun totalVolumeKg(sets: List<SetEntryEntity>): Double = sets.sumOf { it.weightKg * it.reps }

    /** Total volume (weight x reps, summed across every set) in the trailing [days] days, inclusive of today. */
    fun volumeInLastNDays(sets: List<SetEntryEntity>, todayEpochDay: Long, days: Int): Double {
        val cutoff = todayEpochDay - days + 1
        return sets.filter { it.dateEpochDay in cutoff..todayEpochDay }.sumOf { it.weightKg * it.reps }
    }
}
