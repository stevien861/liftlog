package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.repository.WorkoutRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Backs both the "all categories" home screen (grouping [exercises] by
 * category client-side) and a single category's exercise list.
 */
class ExerciseListViewModel(private val repository: WorkoutRepository) : ViewModel() {

    val exercises: StateFlow<List<ExerciseEntity>> = repository.observeExercises()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun exercisesFor(category: MuscleCategory): List<ExerciseEntity> =
        exercises.value.filter { it.category == category }

    fun addExercise(
        name: String,
        category: MuscleCategory,
        repRangeLow: Int,
        repRangeHigh: Int,
        weightIncrementKg: Double,
        targetSets: Int,
        startingWeightKg: Double?
    ) {
        if (name.isBlank() || repRangeLow <= 0 || repRangeHigh < repRangeLow ||
            weightIncrementKg <= 0 || targetSets <= 0
        ) return
        viewModelScope.launch {
            repository.addExercise(
                name = name.trim(),
                category = category,
                repRangeLow = repRangeLow,
                repRangeHigh = repRangeHigh,
                weightIncrementKg = weightIncrementKg,
                targetSets = targetSets,
                startingWeightKg = startingWeightKg
            )
        }
    }

    fun archiveExercise(exercise: ExerciseEntity) {
        viewModelScope.launch { repository.archiveExercise(exercise) }
    }
}
