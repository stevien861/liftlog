package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.achievements.Achievement
import com.stevie.liftlog.achievements.AchievementEngine
import com.stevie.liftlog.achievements.AchievementProgress
import com.stevie.liftlog.achievements.Achievements
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.stats.PersonalRecords
import com.stevie.liftlog.stats.WorkoutStats
import com.stevie.liftlog.util.AppPreferences
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

/** One exercise's all-time bests, for the personal-records list on the Stats screen. */
data class ExerciseRecord(
    val exercise: ExerciseEntity,
    val bestWeightKg: Double,
    val bestEstimatedOneRepMaxKg: Double
)

/** One achievement plus whether it's currently unlocked, for the Stats screen's badge shelf. */
data class AchievementDisplay(val achievement: Achievement, val unlocked: Boolean)

class StatsViewModel(
    private val repository: WorkoutRepository,
    private val preferences: AppPreferences
) : ViewModel() {

    private val today = LocalDate.now().toEpochDay()

    val streakDays: StateFlow<Int> = repository.observeWorkoutDates()
        .map { dates -> WorkoutStats.computeStreakDays(dates.toSet(), today) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val thisWeekVolumeKg: StateFlow<Double> = repository.observeAllSets()
        .map { sets -> WorkoutStats.volumeInLastNDays(sets, today, 7) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    /** Volume for the 7 days before the current 7-day window, for a simple week-over-week comparison. */
    val previousWeekVolumeKg: StateFlow<Double> = repository.observeAllSets()
        .map { sets ->
            val trailingTwoWeeks = WorkoutStats.volumeInLastNDays(sets, today, 14)
            val thisWeek = WorkoutStats.volumeInLastNDays(sets, today, 7)
            trailingTwoWeeks - thisWeek
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    val personalRecords: StateFlow<List<ExerciseRecord>> = combine(
        repository.observeExercises(),
        repository.observeAllSets()
    ) { exercises, sets ->
        val byExercise = sets.groupBy { it.exerciseId }
        exercises.mapNotNull { exercise ->
            val history = byExercise[exercise.id] ?: return@mapNotNull null
            val bestWeight = PersonalRecords.bestWeightEver(history) ?: return@mapNotNull null
            val best1rm = PersonalRecords.bestEstimatedOneRepMaxEver(history) ?: bestWeight
            ExerciseRecord(exercise, bestWeight, best1rm)
        }.sortedByDescending { it.bestEstimatedOneRepMaxKg }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /**
     * Recomputed whenever sets, routines, body weight or exercises change - reads the
     * SharedPreferences-backed counters fresh each time this runs, so it stays reasonably current
     * without needing its own polling.
     */
    val achievements: StateFlow<List<AchievementDisplay>> = combine(
        repository.observeAllSets(),
        repository.observeRoutines(),
        repository.observeBodyWeightHistory(),
        repository.observeExercises()
    ) { sets, routines, bodyWeightEntries, exercises ->
        val categoryByExerciseId = exercises.associate { it.id to it.category }
        val workoutDates = sets.map { it.dateEpochDay }.toSet()
        val streak = WorkoutStats.computeStreakDays(workoutDates, today)
        val categoriesWithSets = sets.mapNotNull { categoryByExerciseId[it.exerciseId] }.toSet().size

        val progress = AchievementProgress(
            hasLoggedAnySet = sets.isNotEmpty(),
            streakDays = streak,
            recordsBrokenCount = preferences.recordsBrokenCount,
            hasCustomRoutine = routines.any { it.isCustom },
            workoutsCompletedCount = preferences.workoutsCompletedCount,
            plateCalculatorUsesCount = preferences.plateCalculatorUsesCount,
            bodyWeightEntryCount = bodyWeightEntries.size,
            categoriesWithSetsCount = categoriesWithSets,
            totalCategoryCount = MuscleCategory.entries.size
        )
        val unlockedIds = AchievementEngine.unlockedIds(progress)
        Achievements.ALL.map { AchievementDisplay(it, unlocked = it.id in unlockedIds) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}
