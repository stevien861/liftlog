package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.stats.PersonalRecords
import com.stevie.liftlog.stats.WorkoutStats
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

/** One exercise's all-time bests, for the personal-records list on the Stats screen. */
data class ExerciseRecord(
    val exercise: ExerciseEntity,
    val bestWeightKg: Double,
    val bestEstimatedOneRepMaxKg: Double
)

class StatsViewModel(repository: WorkoutRepository) : ViewModel() {

    private val today = LocalDate.now().toEpochDay()

    val streakDays: StateFlow<Int> = repository.observeWorkoutDates()
        .map { dates -> WorkoutStats.computeStreakDays(dates.toSet(), today) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val thisWeekVolumeKg: StateFlow<Double> = repository.observeAllSets()
        .map { sets -> WorkoutStats.volumeInLastNDays(sets, today, 7) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    /** Volume for the 7 days before the current 7-day window, for a simple week-over-week comparison. */
    val previousWeekVolumeKg: StateFlow<Double> = repository.observeAllSets()
        .map { sets ->
            val trailingTwoWeeks = WorkoutStats.volumeInLastNDays(sets, today, 14)
            val thisWeek = WorkoutStats.volumeInLastNDays(sets, today, 7)
            trailingTwoWeeks - thisWeek
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    val personalRecords: StateFlow<List<ExerciseRecord>> = combine(
        repository.observeExercises(),
        repository.observeAllSets()
    ) { exercises, sets ->
        val byExercise = sets.groupBy { it.exerciseId }
        exercises.mapNotNull { exercise ->
            val history = byExercise[exercise.id] ?: return@mapNotNull null
            val bestWeight = PersonalRecords.bestWeightEver(history) ?: return@mapNotNull null
            val best1rm = PersonalRecords.bestEstimatedOneRepMaxEver(history) ?: bestWeight
            ExerciseRecord(exercise, bestWeight, best1rm)
        }.sortedByDescending { it.bestEstimatedOneRepMaxKg }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}
