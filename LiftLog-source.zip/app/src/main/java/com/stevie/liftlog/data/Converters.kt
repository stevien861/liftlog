package com.stevie.liftlog.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromCategory(category: MuscleCategory): String = category.name

    @TypeConverter
    fun toCategory(value: String): MuscleCategory = MuscleCategory.fromStorageName(value)
}
