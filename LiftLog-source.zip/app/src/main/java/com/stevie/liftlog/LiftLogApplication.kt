package com.stevie.liftlog

import android.app.Application
import com.stevie.liftlog.data.AppDatabase
import com.stevie.liftlog.repository.WorkoutRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LiftLogApplication : Application() {

    /** Lives as long as the process; owns the DB + repository singletons. */
    val applicationScope = CoroutineScope(SupervisorJob())

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val repository: WorkoutRepository by lazy { WorkoutRepository(database) }

    override fun onCreate() {
        super.onCreate()
        applicationScope.launch {
            repository.ensureSeeded()
        }
    }
}
