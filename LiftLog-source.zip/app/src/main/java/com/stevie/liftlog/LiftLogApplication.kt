package com.stevie.liftlog

import android.app.Application
import android.content.Intent
import com.stevie.liftlog.data.AppDatabase
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.util.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

class LiftLogApplication : Application() {

    /** Lives as long as the process; owns the DB + repository singletons. */
    val applicationScope = CoroutineScope(SupervisorJob())

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val repository: WorkoutRepository by lazy { WorkoutRepository(database) }
    val preferences: AppPreferences by lazy { AppPreferences(this) }

    override fun onCreate() {
        super.onCreate()
        installCrashHandler()
        applicationScope.launch {
            repository.ensureSeeded()
        }
    }

    /**
     * Replaces the default "app has stopped" dialog with a screen that shows
     * the actual stack trace, since there's no way to pull logcat off the
     * device this app is being tested on. See [CrashActivity].
     */
    private fun installCrashHandler() {
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val writer = StringWriter()
                throwable.printStackTrace(PrintWriter(writer))
                val intent = CrashActivity.intentFor(this, writer.toString())
                startActivity(intent)
            } catch (_: Throwable) {
                // If even showing the crash screen fails, fall back to
                // whatever Android would normally have done.
            } finally {
                previousHandler?.uncaughtException(thread, throwable)
                exitProcess(1)
            }
        }
    }
}
