package com.stevie.liftlog.data

/**
 * Built-in workout routines, seeded the first time the app runs (alongside [DefaultExercises]).
 * Each routine references exercises BY NAME here, because the real [RoutineExerciseEntity] rows
 * need the exercises' real database IDs, which only exist after [DefaultExercises] has been
 * inserted - see `WorkoutRepository.ensureSeeded()`, which looks each name up and skips any it
 * can't find (e.g. if the user had already renamed or deleted one).
 *
 * Chosen as a professional trainer would lay out a beginner/intermediate split: each day balances
 * a heavy compound lift with supporting movements, and no single day stacks two very heavy
 * spinal-loading lifts (e.g. Squat and Deadlift never share a day here).
 */
object DefaultRoutines {

    data class Template(val name: String, val exerciseNamesInOrder: List<String>)

    fun seed(): List<Template> = listOf(
        Template(
            name = "Push Day",
            exerciseNamesInOrder = listOf(
                "Barbell Bench Press",
                "Overhead Press",
                "Incline Dumbbell Press",
                "Lateral Raise",
                "Tricep Pushdown"
            )
        ),
        Template(
            name = "Pull Day",
            exerciseNamesInOrder = listOf(
                "Deadlift",
                "Barbell Row",
                "Lat Pulldown",
                "Seated Cable Row",
                "Barbell Bicep Curl",
                "Face Pull"
            )
        ),
        Template(
            name = "Leg Day",
            exerciseNamesInOrder = listOf(
                "Back Squat",
                "Romanian Deadlift",
                "Leg Press",
                "Leg Extension",
                "Calf Raise"
            )
        ),
        Template(
            name = "Full Body",
            exerciseNamesInOrder = listOf(
                "Back Squat",
                "Barbell Bench Press",
                "Barbell Row",
                "Overhead Press"
            )
        )
    )
}
