package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.data.BodyWeightEntity
import com.stevie.liftlog.repository.WorkoutRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class BodyWeightViewModel(private val repository: WorkoutRepository) : ViewModel() {

    val history: StateFlow<List<BodyWeightEntity>> = repository.observeBodyWeightHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun logWeight(weightKg: Double, date: LocalDate = LocalDate.now()) {
        if (weightKg <= 0) return
        viewModelScope.launch { repository.logBodyWeight(date, weightKg) }
    }

    fun deleteEntry(entry: BodyWeightEntity) {
        viewModelScope.launch { repository.deleteBodyWeightEntry(entry) }
    }
}
