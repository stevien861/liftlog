package com.stevie.liftlog.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val Blue = Color(0xFF4C6FFF)
private val BlueDark = Color(0xFF9DB2FF)
private val Green = Color(0xFF2ECC71)
private val Amber = Color(0xFFF5A623)
private val Red = Color(0xFFE45858)
private val Purple = Color(0xFF9B59B6)
private val PurpleDark = Color(0xFFCBA6DD)
private val Flame = Color(0xFFFF7A45)

val LightColors = lightColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    secondary = Green,
    tertiary = Purple,
    background = Color(0xFFFAFAFC),
    surface = Color.White,
    error = Red
)

val DarkColors = darkColorScheme(
    primary = BlueDark,
    onPrimary = Color(0xFF102040),
    secondary = Green,
    tertiary = PurpleDark,
    background = Color(0xFF15161A),
    surface = Color(0xFF1E1F24),
    error = Red
)

// Semantic colors used by the recommendation card and stat tiles - not part of the base
// Material3 scheme, exposed here so screens stay consistent.
object LiftLogColors {
    val increase = Green
    val hold = Amber
    val decrease = Red
    val streak = Flame
}

/**
 * Slightly softer, friendlier corners than Material3's defaults (12dp -> 18dp on the medium
 * shape that every plain Card picks up), applied app-wide via MaterialTheme rather than each
 * screen setting its own shape.
 */
val LiftLogShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun LiftLogTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Off by default: Android's Material You extracts a scheme from the phone wallpaper, which
    // often mutes everything toward gray/one-note. LiftLog's own blue/purple/amber/green palette
    // is deliberately vivid, so it stays on unless the device can't render it (pre-Android 12
    // falls back to the static schemes below either way).
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = LiftLogTypography,
        shapes = LiftLogShapes,
        content = content
    )
}
