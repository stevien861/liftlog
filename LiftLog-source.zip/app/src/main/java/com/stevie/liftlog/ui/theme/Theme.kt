package com.stevie.liftlog.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val Blue = Color(0xFF4C6FFF)
private val BlueDark = Color(0xFF9DB2FF)
private val Green = Color(0xFF2ECC71)
private val Amber = Color(0xFFF5A623)
private val Red = Color(0xFFE45858)

val LightColors = lightColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    secondary = Green,
    background = Color(0xFFFAFAFC),
    surface = Color.White,
    error = Red
)

val DarkColors = darkColorScheme(
    primary = BlueDark,
    onPrimary = Color(0xFF102040),
    secondary = Green,
    background = Color(0xFF15161A),
    surface = Color(0xFF1E1F24),
    error = Red
)

// Semantic colors used by the recommendation card - not part of the base
// Material3 scheme, exposed here so screens stay consistent.
object LiftLogColors {
    val increase = Green
    val hold = Amber
    val decrease = Red
}

@Composable
fun LiftLogTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = LiftLogTypography,
        content = content
    )
}
