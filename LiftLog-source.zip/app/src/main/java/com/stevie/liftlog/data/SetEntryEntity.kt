package com.stevie.liftlog.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One logged set: a given [exerciseId], on a given day ([dateEpochDay], as
 * returned by `LocalDate.toEpochDay()`), at a given weight/reps. A workout
 * "session" for an exercise is simply every [SetEntryEntity] sharing the same
 * [exerciseId] and [dateEpochDay].
 */
@Entity(
    tableName = "set_entries",
    foreignKeys = [
        ForeignKey(
            entity = ExerciseEntity::class,
            parentColumns = ["id"],
            childColumns = ["exerciseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("exerciseId"), Index("dateEpochDay")]
)
data class SetEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val exerciseId: Long,
    val dateEpochDay: Long,
    val setNumber: Int,
    val weightKg: Double,
    val reps: Int,
    val notes: String = ""
)
