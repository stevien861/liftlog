package com.stevie.liftlog.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SetDao {

    @Query("SELECT * FROM set_entries ORDER BY dateEpochDay DESC, id DESC")
    fun observeAll(): Flow<List<SetEntryEntity>>

    @Query("SELECT * FROM set_entries WHERE exerciseId = :exerciseId ORDER BY dateEpochDay DESC, setNumber ASC")
    fun observeForExercise(exerciseId: Long): Flow<List<SetEntryEntity>>

    @Query("SELECT * FROM set_entries WHERE exerciseId = :exerciseId ORDER BY dateEpochDay DESC, setNumber ASC")
    suspend fun getForExerciseOnce(exerciseId: Long): List<SetEntryEntity>

    @Query("SELECT * FROM set_entries WHERE exerciseId = :exerciseId AND dateEpochDay = :dateEpochDay ORDER BY setNumber ASC")
    fun observeForExerciseOnDate(exerciseId: Long, dateEpochDay: Long): Flow<List<SetEntryEntity>>

    @Query("SELECT DISTINCT dateEpochDay FROM set_entries ORDER BY dateEpochDay DESC")
    fun observeWorkoutDates(): Flow<List<Long>>

    @Query(
        """SELECT * FROM set_entries WHERE dateEpochDay = :dateEpochDay
           ORDER BY exerciseId, setNumber ASC"""
    )
    fun observeForDate(dateEpochDay: Long): Flow<List<SetEntryEntity>>

    @Query("SELECT * FROM set_entries")
    suspend fun getAllOnce(): List<SetEntryEntity>

    @Query("SELECT MAX(setNumber) FROM set_entries WHERE exerciseId = :exerciseId AND dateEpochDay = :dateEpochDay")
    suspend fun maxSetNumber(exerciseId: Long, dateEpochDay: Long): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(set: SetEntryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(sets: List<SetEntryEntity>)

    @Update
    suspend fun update(set: SetEntryEntity)

    @Delete
    suspend fun delete(set: SetEntryEntity)

    @Query("DELETE FROM set_entries")
    suspend fun deleteAll()

    @Query("DELETE FROM set_entries WHERE exerciseId = :exerciseId AND dateEpochDay = :dateEpochDay")
    suspend fun deleteForExerciseOnDate(exerciseId: Long, dateEpochDay: Long)
}
