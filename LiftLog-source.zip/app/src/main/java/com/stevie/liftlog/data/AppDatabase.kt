package com.stevie.liftlog.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        ExerciseEntity::class,
        SetEntryEntity::class,
        RoutineEntity::class,
        RoutineExerciseEntity::class,
        BodyWeightEntity::class
    ],
    version = 3,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun exerciseDao(): ExerciseDao
    abstract fun setDao(): SetDao
    abstract fun maintenanceDao(): MaintenanceDao
    abstract fun routineDao(): RoutineDao
    abstract fun bodyWeightDao(): BodyWeightDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Note: seeding the starter exercise list (and default routines) is
        // done explicitly by WorkoutRepository.ensureSeeded() the first time
        // the app runs, rather than in a Room.Callback.onCreate here - that
        // keeps the "insert if empty" logic in one obvious, testable place
        // instead of depending on exactly when Room lazily opens the
        // database file.
        //
        // fallbackToDestructiveMigration() covers the version 1 -> 2 bump
        // that added routines/body weight, and the version 2 -> 3 bump that
        // added ExerciseEntity.targetSets/startingWeightKg: this app has no
        // real users with data on an old schema yet, so wiping and reseeding
        // on upgrade is far simpler and safer than hand-writing a Migration
        // for a schema that was never in wide use. If this matters later
        // (i.e. once real user data exists across schema changes), replace
        // this with an explicit Migration instead of bumping the destructive
        // fallback.
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "liftlog.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
