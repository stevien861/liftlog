package com.stevie.liftlog.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [ExerciseEntity::class, SetEntryEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun exerciseDao(): ExerciseDao
    abstract fun setDao(): SetDao
    abstract fun maintenanceDao(): MaintenanceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Note: seeding the starter exercise list is done explicitly by
        // WorkoutRepository.ensureSeeded() the first time the app runs,
        // rather than in a Room.Callback.onCreate here - that keeps the
        // "insert if empty" logic in one obvious, testable place instead of
        // depending on exactly when Room lazily opens the database file.
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "liftlog.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
