package com.stevie.liftlog.data

import androidx.room.Dao
import androidx.room.Query

/**
 * A couple of table-wide maintenance queries that don't fit naturally on
 * [ExerciseDao] (which otherwise only deals with single rows / lists for
 * display), kept separate so that DAO stays focused on what the UI needs.
 */
@Dao
interface MaintenanceDao {
    @Query("DELETE FROM exercises")
    suspend fun deleteAllExercises()
}
