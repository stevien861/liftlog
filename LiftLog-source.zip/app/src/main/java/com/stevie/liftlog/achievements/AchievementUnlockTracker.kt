package com.stevie.liftlog.achievements

import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.util.AppPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Shared by any ViewModel that wants a celebratory popup the moment an achievement unlocks,
 * rather than the person only noticing it later on the Stats badge shelf. Call [checkAndQueue]
 * after an action that could unlock one (logging a set, finishing a workout); a screen collects
 * [pending] and shows its first entry, then calls [dismissCurrent].
 */
class AchievementUnlockTracker(
    private val repository: WorkoutRepository,
    private val preferences: AppPreferences
) {
    private val _pending = MutableStateFlow<List<Achievement>>(emptyList())
    val pending: StateFlow<List<Achievement>> = _pending.asStateFlow()

    suspend fun checkAndQueue() {
        val newlyUnlocked = repository.checkForNewlyUnlockedAchievements(
            AchievementCounters(
                recordsBrokenCount = preferences.recordsBrokenCount,
                workoutsCompletedCount = preferences.workoutsCompletedCount,
                plateCalculatorUsesCount = preferences.plateCalculatorUsesCount
            ),
            preferences.seenAchievementIds
        )
        if (newlyUnlocked.isNotEmpty()) {
            preferences.seenAchievementIds = preferences.seenAchievementIds + newlyUnlocked.map { it.id.name }
            _pending.value = _pending.value + newlyUnlocked
        }
    }

    fun dismissCurrent() {
        _pending.value = _pending.value.drop(1)
    }
}
