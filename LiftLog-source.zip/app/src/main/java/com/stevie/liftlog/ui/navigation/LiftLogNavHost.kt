package com.stevie.liftlog.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.screens.CategoriesScreen
import com.stevie.liftlog.ui.screens.ExerciseDetailScreen
import com.stevie.liftlog.ui.screens.ExerciseListScreen
import com.stevie.liftlog.ui.screens.SettingsScreen

object Routes {
    const val CATEGORIES = "categories"
    const val CATEGORY = "category/{categoryName}"
    const val EXERCISE = "exercise/{exerciseId}"
    const val SETTINGS = "settings"

    fun category(category: MuscleCategory) = "category/${category.name}"
    fun exercise(exerciseId: Long) = "exercise/$exerciseId"
}

@Composable
fun LiftLogNavHost(repository: WorkoutRepository, navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.CATEGORIES) {

        composable(Routes.CATEGORIES) {
            CategoriesScreen(
                repository = repository,
                onCategoryClick = { navController.navigate(Routes.category(it)) },
                onSettingsClick = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(
            route = Routes.CATEGORY,
            arguments = listOf(navArgument("categoryName") { type = NavType.StringType })
        ) { backStackEntry ->
            val categoryName = backStackEntry.arguments?.getString("categoryName") ?: MuscleCategory.BACK.name
            ExerciseListScreen(
                repository = repository,
                category = MuscleCategory.fromStorageName(categoryName),
                onExerciseClick = { navController.navigate(Routes.exercise(it)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.EXERCISE,
            arguments = listOf(navArgument("exerciseId") { type = NavType.LongType })
        ) { backStackEntry ->
            val exerciseId = backStackEntry.arguments?.getLong("exerciseId") ?: 0L
            ExerciseDetailScreen(
                repository = repository,
                exerciseId = exerciseId,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
