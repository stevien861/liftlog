package com.stevie.liftlog.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.BottomDestination
import com.stevie.liftlog.ui.screens.BodyWeightScreen
import com.stevie.liftlog.ui.screens.CategoriesScreen
import com.stevie.liftlog.ui.screens.ExerciseDetailScreen
import com.stevie.liftlog.ui.screens.ExerciseListScreen
import com.stevie.liftlog.ui.screens.HomeScreen
import com.stevie.liftlog.ui.screens.OnboardingScreen
import com.stevie.liftlog.ui.screens.RoutineEditorScreen
import com.stevie.liftlog.ui.screens.RoutinesScreen
import com.stevie.liftlog.ui.screens.SettingsScreen
import com.stevie.liftlog.ui.screens.StatsScreen
import com.stevie.liftlog.ui.screens.WorkoutSessionScreen
import com.stevie.liftlog.util.AppPreferences

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val CATEGORIES = "categories"
    const val CATEGORY = "category/{categoryName}"
    const val EXERCISE = "exercise/{exerciseId}"
    const val SETTINGS = "settings"
    const val ROUTINES = "routines"
    const val ROUTINE_EDITOR = "routine_editor?routineId={routineId}"
    const val WORKOUT = "workout?routineId={routineId}"
    const val STATS = "stats"
    const val BODY_WEIGHT = "body_weight"

    /** Sentinel used in place of a real routine ID on [ROUTINE_EDITOR] / [WORKOUT] to mean "none" (new routine / freestyle workout). */
    const val NO_ROUTINE_ID = -1L

    fun category(category: MuscleCategory) = "category/${category.name}"
    fun exercise(exerciseId: Long) = "exercise/$exerciseId"
    fun routineEditor(routineId: Long?) =
        if (routineId != null) "routine_editor?routineId=$routineId" else "routine_editor"
    fun workout(routineId: Long?) =
        if (routineId != null) "workout?routineId=$routineId" else "workout"
}

@Composable
fun LiftLogNavHost(
    repository: WorkoutRepository,
    preferences: AppPreferences,
    startDestination: String = Routes.HOME,
    navController: NavHostController = rememberNavController()
) {
    fun navigateToTab(destination: BottomDestination) {
        val route = when (destination) {
            BottomDestination.HOME -> Routes.HOME
            BottomDestination.ROUTINES -> Routes.ROUTINES
            BottomDestination.STATS -> Routes.STATS
            BottomDestination.SETTINGS -> Routes.SETTINGS
        }
        navController.navigate(route) {
            popUpTo(Routes.HOME) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    NavHost(navController = navController, startDestination = startDestination) {

        composable(Routes.ONBOARDING) {
            OnboardingScreen(onFinish = {
                preferences.onboardingComplete = true
                navController.navigate(Routes.HOME) {
                    popUpTo(Routes.ONBOARDING) { inclusive = true }
                }
            })
        }

        composable(Routes.HOME) {
            HomeScreen(
                repository = repository,
                onStartWorkout = { routineId -> navController.navigate(Routes.workout(routineId)) },
                onBrowseExercises = { navController.navigate(Routes.CATEGORIES) },
                onCategoryClick = { navController.navigate(Routes.category(it)) },
                onNavigate = { navigateToTab(it) }
            )
        }

        composable(Routes.CATEGORIES) {
            CategoriesScreen(
                repository = repository,
                onCategoryClick = { navController.navigate(Routes.category(it)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.CATEGORY,
            arguments = listOf(navArgument("categoryName") { type = NavType.StringType })
        ) { backStackEntry ->
            val categoryName = backStackEntry.arguments?.getString("categoryName") ?: MuscleCategory.BACK.name
            ExerciseListScreen(
                repository = repository,
                category = MuscleCategory.fromStorageName(categoryName),
                onExerciseClick = { navController.navigate(Routes.exercise(it)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.EXERCISE,
            arguments = listOf(navArgument("exerciseId") { type = NavType.LongType })
        ) { backStackEntry ->
            val exerciseId = backStackEntry.arguments?.getLong("exerciseId") ?: 0L
            ExerciseDetailScreen(
                repository = repository,
                exerciseId = exerciseId,
                barWeightKg = preferences.barWeightKg.toDouble(),
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                repository = repository,
                preferences = preferences,
                onNavigate = { navigateToTab(it) }
            )
        }

        composable(Routes.ROUTINES) {
            RoutinesScreen(
                repository = repository,
                onStartRoutine = { navController.navigate(Routes.workout(it)) },
                onEditRoutine = { navController.navigate(Routes.routineEditor(it)) },
                onCreateRoutine = { navController.navigate(Routes.routineEditor(null)) },
                onNavigate = { navigateToTab(it) }
            )
        }

        composable(
            route = Routes.ROUTINE_EDITOR,
            arguments = listOf(navArgument("routineId") { type = NavType.LongType; defaultValue = Routes.NO_ROUTINE_ID })
        ) { backStackEntry ->
            val routineIdArg = backStackEntry.arguments?.getLong("routineId") ?: Routes.NO_ROUTINE_ID
            RoutineEditorScreen(
                repository = repository,
                routineId = if (routineIdArg == Routes.NO_ROUTINE_ID) null else routineIdArg,
                onBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.WORKOUT,
            arguments = listOf(navArgument("routineId") { type = NavType.LongType; defaultValue = Routes.NO_ROUTINE_ID })
        ) { backStackEntry ->
            val routineIdArg = backStackEntry.arguments?.getLong("routineId") ?: Routes.NO_ROUTINE_ID
            WorkoutSessionScreen(
                repository = repository,
                routineId = if (routineIdArg == Routes.NO_ROUTINE_ID) null else routineIdArg,
                onExit = { navController.popBackStack() }
            )
        }

        composable(Routes.STATS) {
            StatsScreen(
                repository = repository,
                onOpenBodyWeight = { navController.navigate(Routes.BODY_WEIGHT) },
                onNavigate = { navigateToTab(it) }
            )
        }

        composable(Routes.BODY_WEIGHT) {
            BodyWeightScreen(repository = repository, onBack = { navController.popBackStack() })
        }
    }
}
