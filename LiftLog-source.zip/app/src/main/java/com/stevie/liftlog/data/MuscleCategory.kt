package com.stevie.liftlog.data

/**
 * The six muscle-group categories exercises are organised into, exactly as
 * requested: Back, Chest, Arms, Shoulders, Forearms, Legs.
 */
enum class MuscleCategory(val displayName: String) {
    BACK("Back"),
    CHEST("Chest"),
    ARMS("Arms"),
    SHOULDERS("Shoulders"),
    FOREARMS("Forearms"),
    LEGS("Legs");

    companion object {
        fun fromStorageName(name: String): MuscleCategory =
            entries.firstOrNull { it.name == name } ?: BACK
    }
}
