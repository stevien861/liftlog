package com.stevie.liftlog.recommendation

/** One suggested warm-up set: lighter than the working weight, with more reps than the work set. */
data class WarmupSet(val weightKg: Double, val reps: Int)

/**
 * Standard percentage-based warm-up ramp: a couple of light, higher-rep sets building up to your
 * working weight, so you're not attempting your heaviest set of the day completely cold. This is
 * a suggestion only - the user logs (or ignores) these like any other set, and nothing here is
 * written to the database automatically.
 */
object WarmupCalculator {

    /** (percent of working weight, reps) for each warm-up step, lightest first. */
    private val STEPS = listOf(0.4 to 8, 0.6 to 5, 0.8 to 3)

    fun suggest(workingWeightKg: Double, barWeightKg: Double = PlateCalculator.DEFAULT_BAR_WEIGHT_KG): List<WarmupSet> {
        if (workingWeightKg <= barWeightKg) return emptyList()

        val seenWeights = HashSet<Double>()
        return STEPS.mapNotNull { (percent, reps) ->
            val raw = workingWeightKg * percent
            if (raw <= barWeightKg) return@mapNotNull null
            val rounded = roundToNearestQuarterKg(raw)
            if (!seenWeights.add(rounded)) return@mapNotNull null
            WarmupSet(rounded, reps)
        }
    }

    private fun roundToNearestQuarterKg(value: Double): Double = Math.round(value * 4.0) / 4.0
}
