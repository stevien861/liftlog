package com.stevie.liftlog

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Last-resort crash screen. Registered as the app's default uncaught
 * exception handler in [LiftLogApplication] so that a bug shows up as
 * readable, selectable text on screen (easy to screenshot and share)
 * instead of the generic system "app has stopped" dialog, which throws
 * away the actual error.
 */
class CrashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = intent.getStringExtra(EXTRA_STACK_TRACE)
            ?: "(no stack trace was captured)"
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CrashScreen(trace)
                }
            }
        }
    }

    companion object {
        private const val EXTRA_STACK_TRACE = "stack_trace"

        fun intentFor(context: Context, stackTrace: String): Intent =
            Intent(context, CrashActivity::class.java).apply {
                putExtra(EXTRA_STACK_TRACE, stackTrace)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
    }
}

@Composable
private fun CrashScreen(trace: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "LiftLog hit a bug",
            style = MaterialTheme.typography.headlineSmall
        )
        Text(
            text = "Screenshot everything below (scroll if needed) and send it back - " +
                "this is the exact error, not a generic crash message.",
            style = MaterialTheme.typography.bodyMedium
        )
        SelectionContainer {
            Text(
                text = trace,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
