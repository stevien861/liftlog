package com.stevie.liftlog.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.PlateCalculatorDialog
import com.stevie.liftlog.ui.components.ProgressLineChart
import com.stevie.liftlog.ui.components.RecordCelebrationDialog
import com.stevie.liftlog.ui.components.RecommendationCard
import com.stevie.liftlog.ui.components.WarmupSuggestionCard
import com.stevie.liftlog.viewmodel.ExerciseDetailViewModel
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExerciseDetailScreen(
    repository: WorkoutRepository,
    exerciseId: Long,
    barWeightKg: Double,
    onBack: () -> Unit
) {
    val viewModel: ExerciseDetailViewModel =
        viewModel(factory = LiftLogViewModelFactory(repository, exerciseId = exerciseId))

    val exercise by viewModel.exercise.collectAsStateWithLifecycle()
    val recommendation by viewModel.recommendation.collectAsStateWithLifecycle()
    val sessions by viewModel.sessionsNewestFirst.collectAsStateWithLifecycle()
    val justBrokenRecords by viewModel.justBrokenRecords.collectAsStateWithLifecycle()

    var showMenu by remember { mutableStateOf(false) }
    var showEditTargets by remember { mutableStateOf(false) }
    var showPlateCalculator by remember { mutableStateOf(false) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var weightInput by remember { mutableStateOf("") }
    var repsInput by remember { mutableStateOf("") }

    val context = LocalContext.current
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEE d MMM") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(exercise?.name ?: "") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Edit rep range / weight step") },
                            onClick = { showMenu = false; showEditTargets = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Archive exercise") },
                            onClick = {
                                showMenu = false
                                viewModel.archiveExercise(onDone = onBack)
                            }
                        )
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                RecommendationCard(recommendation = recommendation)
            }

            recommendation?.suggestedWeightKg?.let { suggestedWeight ->
                item {
                    WarmupSuggestionCard(workingWeightKg = suggestedWeight, barWeightKg = barWeightKg)
                }
            }

            item {
                val chartPoints = sessions.reversed().map { (_, sets) -> sets.maxOf { it.weightKg }.toFloat() }
                Card {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Top working weight over time", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        ProgressLineChart(points = chartPoints)
                    }
                }
            }

            item {
                Card {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Log a set", style = MaterialTheme.typography.titleMedium)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                selectedDate.format(dateFormatter),
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                val initial = selectedDate
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        selectedDate = LocalDate.of(year, month + 1, dayOfMonth)
                                    },
                                    initial.year,
                                    initial.monthValue - 1,
                                    initial.dayOfMonth
                                ).show()
                            }) { Text("Change date") }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = weightInput,
                                onValueChange = { weightInput = it },
                                label = { Text("Weight (kg)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = repsInput,
                                onValueChange = { repsInput = it },
                                label = { Text("Reps") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        val weightValue = weightInput.toDoubleOrNull()
                        val repsValue = repsInput.toIntOrNull()

                        OutlinedButton(
                            onClick = { showPlateCalculator = true },
                            enabled = weightValue != null && weightValue > 0,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                        ) { Text("Plate calculator") }

                        Button(
                            onClick = {
                                viewModel.logSet(selectedDate, weightValue!!, repsValue!!)
                                repsInput = ""
                            },
                            enabled = weightValue != null && weightValue > 0 && repsValue != null && repsValue > 0,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) { Text("Add set") }

                        val todaySets = sessions.firstOrNull { it.first == selectedDate }?.second.orEmpty()
                        if (todaySets.isNotEmpty()) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                            Text(
                                "Sets logged for ${selectedDate.format(dateFormatter)}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            todaySets.forEach { set ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Set ${set.setNumber}: ${formatKg(set.weightKg)} kg x ${set.reps} reps")
                                    IconButton(onClick = { viewModel.deleteSet(set) }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Delete set")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text("History", style = MaterialTheme.typography.titleMedium)
            }

            if (sessions.isEmpty()) {
                item {
                    Text(
                        "No sets logged yet.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(sessions, key = { it.first.toEpochDay() }) { (date, sets) ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(date.format(dateFormatter), style = MaterialTheme.typography.labelLarge)
                            sets.forEach { set ->
                                Text(
                                    "Set ${set.setNumber}: ${formatKg(set.weightKg)} kg x ${set.reps} reps",
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditTargets && exercise != null) {
        EditTargetsDialog(
            repLow = exercise!!.targetRepRangeLow,
            repHigh = exercise!!.targetRepRangeHigh,
            increment = exercise!!.weightIncrementKg,
            onDismiss = { showEditTargets = false },
            onConfirm = { low, high, inc ->
                viewModel.updateTargets(low, high, inc)
                showEditTargets = false
            }
        )
    }

    if (showPlateCalculator) {
        val target = weightInput.toDoubleOrNull() ?: recommendation?.suggestedWeightKg ?: barWeightKg
        PlateCalculatorDialog(
            targetWeightKg = target,
            barWeightKg = barWeightKg,
            onDismiss = { showPlateCalculator = false }
        )
    }

    if (justBrokenRecords.isNotEmpty()) {
        RecordCelebrationDialog(
            exerciseName = exercise?.name ?: "",
            records = justBrokenRecords,
            onDismiss = { viewModel.clearRecordCelebration() }
        )
    }
}

@Composable
private fun EditTargetsDialog(
    repLow: Int,
    repHigh: Int,
    increment: Double,
    onDismiss: () -> Unit,
    onConfirm: (Int, Int, Double) -> Unit
) {
    var low by remember { mutableStateOf(repLow.toString()) }
    var high by remember { mutableStateOf(repHigh.toString()) }
    var inc by remember { mutableStateOf(formatKg(increment)) }

    val lowInt = low.toIntOrNull()
    val highInt = high.toIntOrNull()
    val incDouble = inc.toDoubleOrNull()
    val isValid = lowInt != null && highInt != null && lowInt > 0 && highInt >= lowInt &&
        incDouble != null && incDouble > 0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rep range & weight step") },
        text = {
            Column {
                Text(
                    "This controls when LiftLog recommends going up or down in weight for this exercise.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = low,
                        onValueChange = { low = it },
                        label = { Text("Rep min") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = high,
                        onValueChange = { high = it },
                        label = { Text("Rep max") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = inc,
                    onValueChange = { inc = it },
                    label = { Text("Weight step (kg)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(lowInt!!, highInt!!, incDouble!!) }, enabled = isValid) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
