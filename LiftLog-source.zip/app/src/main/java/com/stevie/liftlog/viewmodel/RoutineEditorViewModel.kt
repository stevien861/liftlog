package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.RoutineEntity
import com.stevie.liftlog.repository.WorkoutRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Backs the routine editor: create a new routine, or edit an existing one when [routineId] is
 * non-null (loads its current name + exercise selection/order once, on init).
 */
class RoutineEditorViewModel(
    private val repository: WorkoutRepository,
    routineId: Long?
) : ViewModel() {

    val allExercises: StateFlow<List<ExerciseEntity>> = repository.observeExercises()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _name = MutableStateFlow("")
    val name: StateFlow<String> = _name.asStateFlow()

    /** Chosen exercise IDs, in the order they'll be performed. */
    private val _selectedExerciseIds = MutableStateFlow<List<Long>>(emptyList())
    val selectedExerciseIds: StateFlow<List<Long>> = _selectedExerciseIds.asStateFlow()

    private val _isLoadingExisting = MutableStateFlow(routineId != null)
    val isLoadingExisting: StateFlow<Boolean> = _isLoadingExisting.asStateFlow()

    private var existingRoutine: RoutineEntity? = null

    init {
        if (routineId != null) {
            viewModelScope.launch {
                existingRoutine = repository.observeRoutine(routineId).first()
                _name.value = existingRoutine?.name ?: ""
                _selectedExerciseIds.value = repository.observeRoutineExercises(routineId)
                    .first()
                    .sortedBy { it.sortOrder }
                    .map { it.exerciseId }
                _isLoadingExisting.value = false
            }
        }
    }

    fun updateName(newName: String) {
        _name.value = newName
    }

    fun toggleExercise(exerciseId: Long) {
        val current = _selectedExerciseIds.value
        _selectedExerciseIds.value = if (current.contains(exerciseId)) current - exerciseId else current + exerciseId
    }

    fun moveExercise(fromIndex: Int, toIndex: Int) {
        val list = _selectedExerciseIds.value.toMutableList()
        if (fromIndex !in list.indices || toIndex !in list.indices) return
        val item = list.removeAt(fromIndex)
        list.add(toIndex, item)
        _selectedExerciseIds.value = list
    }

    fun canSave(): Boolean = _name.value.isNotBlank() && _selectedExerciseIds.value.isNotEmpty()

    fun save(onDone: () -> Unit) {
        if (!canSave()) return
        viewModelScope.launch {
            val routine = existingRoutine
            if (routine != null) {
                repository.updateRoutine(routine, _name.value.trim(), _selectedExerciseIds.value)
            } else {
                repository.createRoutine(_name.value.trim(), _selectedExerciseIds.value)
            }
            onDone()
        }
    }
}
