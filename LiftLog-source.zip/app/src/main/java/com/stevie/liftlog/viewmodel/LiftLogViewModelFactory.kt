package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.util.AppPreferences

/**
 * A small hand-written [ViewModelProvider.Factory] instead of a DI framework
 * (Hilt, etc.) - this app is simple enough that one factory covering every
 * ViewModel is easier to read than the extra build-time ceremony a DI
 * framework needs.
 *
 * Most ViewModels only need [repository]. A few need one of the optional
 * extras: [preferences] (Settings, the guided workout's rest timer),
 * [exerciseId] (exercise detail), or [routineId] (the guided workout and the
 * routine editor - null there means "freestyle" / "new routine").
 */
class LiftLogViewModelFactory(
    private val repository: WorkoutRepository,
    private val preferences: AppPreferences? = null,
    private val exerciseId: Long? = null,
    private val routineId: Long? = null
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ExerciseListViewModel::class.java) ->
                ExerciseListViewModel(repository) as T

            modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
                SettingsViewModel(
                    repository,
                    requireNotNull(preferences) { "preferences is required for SettingsViewModel" }
                ) as T

            modelClass.isAssignableFrom(ExerciseDetailViewModel::class.java) ->
                ExerciseDetailViewModel(
                    repository,
                    requireNotNull(preferences) { "preferences is required for ExerciseDetailViewModel" },
                    requireNotNull(exerciseId) { "exerciseId is required for ExerciseDetailViewModel" }
                ) as T

            modelClass.isAssignableFrom(HomeViewModel::class.java) ->
                HomeViewModel(repository) as T

            modelClass.isAssignableFrom(RoutinesViewModel::class.java) ->
                RoutinesViewModel(repository) as T

            modelClass.isAssignableFrom(RoutineEditorViewModel::class.java) ->
                RoutineEditorViewModel(repository, routineId) as T

            modelClass.isAssignableFrom(WorkoutSessionViewModel::class.java) ->
                WorkoutSessionViewModel(
                    repository,
                    requireNotNull(preferences) { "preferences is required for WorkoutSessionViewModel" },
                    routineId
                ) as T

            modelClass.isAssignableFrom(StatsViewModel::class.java) ->
                StatsViewModel(
                    repository,
                    requireNotNull(preferences) { "preferences is required for StatsViewModel" }
                ) as T

            modelClass.isAssignableFrom(BodyWeightViewModel::class.java) ->
                BodyWeightViewModel(repository) as T

            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
