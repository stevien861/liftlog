package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.stevie.liftlog.repository.WorkoutRepository

/**
 * A small hand-written [ViewModelProvider.Factory] instead of a DI framework
 * (Hilt, etc.) - this app is simple enough that one factory covering the
 * three ViewModels is easier to read than the extra build-time ceremony a DI
 * framework needs.
 *
 * [exerciseId] is only required by [ExerciseDetailViewModel]; pass null when
 * creating one of the other two.
 */
class LiftLogViewModelFactory(
    private val repository: WorkoutRepository,
    private val exerciseId: Long? = null
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ExerciseListViewModel::class.java) ->
                ExerciseListViewModel(repository) as T

            modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
                SettingsViewModel(repository) as T

            modelClass.isAssignableFrom(ExerciseDetailViewModel::class.java) ->
                ExerciseDetailViewModel(
                    repository,
                    requireNotNull(exerciseId) { "exerciseId is required for ExerciseDetailViewModel" }
                ) as T

            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
