package com.stevie.liftlog.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.stevie.liftlog.data.MuscleCategory

/**
 * A distinct icon + accent color per muscle category, purely cosmetic (category cards, the
 * routine editor's exercise picker, etc.) - keeps the six categories visually easy to tell apart
 * at a glance instead of every card looking identical.
 */
fun categoryIcon(category: MuscleCategory): ImageVector = when (category) {
    MuscleCategory.BACK -> Icons.Filled.AccessibilityNew
    MuscleCategory.CHEST -> Icons.Filled.FitnessCenter
    MuscleCategory.ARMS -> Icons.Filled.Bolt
    MuscleCategory.SHOULDERS -> Icons.Filled.Whatshot
    MuscleCategory.FOREARMS -> Icons.Filled.PanTool
    MuscleCategory.LEGS -> Icons.Filled.DirectionsRun
}

@Composable
fun categoryColor(category: MuscleCategory): Color = when (category) {
    MuscleCategory.BACK -> Color(0xFF4C6FFF)
    MuscleCategory.CHEST -> Color(0xFFE45858)
    MuscleCategory.ARMS -> Color(0xFFF5A623)
    MuscleCategory.SHOULDERS -> Color(0xFF9B59B6)
    MuscleCategory.FOREARMS -> Color(0xFF16A085)
    MuscleCategory.LEGS -> Color(0xFF2ECC71)
}
