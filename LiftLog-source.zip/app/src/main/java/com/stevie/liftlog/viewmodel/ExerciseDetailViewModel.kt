package com.stevie.liftlog.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stevie.liftlog.achievements.Achievement
import com.stevie.liftlog.achievements.AchievementUnlockTracker
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.SetEntryEntity
import com.stevie.liftlog.recommendation.Recommendation
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.stats.NewRecord
import com.stevie.liftlog.util.AppPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * Everything needed by the exercise detail screen: the exercise itself, its
 * full logged history (newest first), the live progression recommendation,
 * and the ability to log/edit/delete sets and edit the exercise's targets.
 */
class ExerciseDetailViewModel(
    private val repository: WorkoutRepository,
    private val preferences: AppPreferences,
    private val exerciseId: Long
) : ViewModel() {

    val exercise: StateFlow<ExerciseEntity?> = repository.observeExercise(exerciseId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val history: StateFlow<List<SetEntryEntity>> = repository.observeSetsForExercise(exerciseId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val recommendation: StateFlow<Recommendation?> = repository.observeRecommendation(exerciseId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /** Sessions grouped by date, newest first - what the history/chart UI actually renders. */
    val sessionsNewestFirst: StateFlow<List<Pair<LocalDate, List<SetEntryEntity>>>> = repository
        .observeSetsForExercise(exerciseId)
        .map { sets ->
            sets.groupBy { LocalDate.ofEpochDay(it.dateEpochDay) }
                .toSortedMap(compareByDescending { it })
                .map { (date, s) -> date to s.sortedBy { it.setNumber } }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Non-null right after a set is logged that broke an all-time record; the screen shows a celebration then calls [clearRecordCelebration]. */
    private val _justBrokenRecords = MutableStateFlow<List<NewRecord>>(emptyList())
    val justBrokenRecords: StateFlow<List<NewRecord>> = _justBrokenRecords.asStateFlow()

    private val achievementTracker = AchievementUnlockTracker(repository, preferences)
    val pendingAchievements: StateFlow<List<Achievement>> = achievementTracker.pending

    fun dismissAchievementCelebration() = achievementTracker.dismissCurrent()

    fun logSet(date: LocalDate, weightKg: Double, reps: Int) {
        if (weightKg <= 0 || reps <= 0) return
        viewModelScope.launch {
            val records = repository.logSetAndCheckRecords(exerciseId, date, weightKg, reps)
            if (records.isNotEmpty()) {
                _justBrokenRecords.value = records
                preferences.incrementRecordsBrokenCount(records.size)
            }
            achievementTracker.checkAndQueue()
        }
    }

    /** Called by the screen when the plate calculator dialog is opened, for the "Plate Master" achievement. */
    fun onPlateCalculatorOpened() {
        preferences.incrementPlateCalculatorUsesCount()
    }

    fun clearRecordCelebration() {
        _justBrokenRecords.value = emptyList()
    }

    fun deleteSet(set: SetEntryEntity) {
        viewModelScope.launch { repository.deleteSet(set) }
    }

    fun updateTargets(repRangeLow: Int, repRangeHigh: Int, weightIncrementKg: Double) {
        val current = exercise.value ?: return
        if (repRangeLow <= 0 || repRangeHigh < repRangeLow || weightIncrementKg <= 0) return
        viewModelScope.launch {
            repository.updateExercise(
                current.copy(
                    targetRepRangeLow = repRangeLow,
                    targetRepRangeHigh = repRangeHigh,
                    weightIncrementKg = weightIncrementKg
                )
            )
        }
    }

    fun archiveExercise(onDone: () -> Unit) {
        val current = exercise.value ?: return
        viewModelScope.launch {
            repository.archiveExercise(current)
            onDone()
        }
    }
}
