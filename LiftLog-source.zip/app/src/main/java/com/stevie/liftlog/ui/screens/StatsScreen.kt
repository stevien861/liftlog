package com.stevie.liftlog.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.LiftLogApplication
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.BottomDestination
import com.stevie.liftlog.ui.components.IconBadge
import com.stevie.liftlog.ui.components.LiftLogBottomBar
import com.stevie.liftlog.ui.components.SectionHeader
import com.stevie.liftlog.ui.components.StatTile
import com.stevie.liftlog.ui.theme.LiftLogColors
import com.stevie.liftlog.viewmodel.AchievementDisplay
import com.stevie.liftlog.viewmodel.ExerciseRecord
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory
import com.stevie.liftlog.viewmodel.StatsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    repository: WorkoutRepository,
    onOpenBodyWeight: () -> Unit,
    onNavigate: (BottomDestination) -> Unit
) {
    val context = LocalContext.current
    val preferences = remember { (context.applicationContext as LiftLogApplication).preferences }

    val viewModel: StatsViewModel = viewModel(
        factory = LiftLogViewModelFactory(repository, preferences = preferences)
    )
    val streakDays by viewModel.streakDays.collectAsStateWithLifecycle()
    val thisWeek by viewModel.thisWeekVolumeKg.collectAsStateWithLifecycle()
    val previousWeek by viewModel.previousWeekVolumeKg.collectAsStateWithLifecycle()
    val records by viewModel.personalRecords.collectAsStateWithLifecycle()
    val achievements by viewModel.achievements.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Stats") },
                actions = {
                    IconButton(onClick = onOpenBodyWeight) {
                        Icon(Icons.Filled.MonitorWeight, contentDescription = "Body weight")
                    }
                }
            )
        },
        bottomBar = { LiftLogBottomBar(current = BottomDestination.STATS, onSelect = onNavigate) }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Filled.LocalFireDepartment,
                        value = if (streakDays == 1) "1 day" else "$streakDays days",
                        label = "Current streak",
                        tint = LiftLogColors.streak
                    )
                    StatTile(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Filled.Bolt,
                        value = "${formatKg(thisWeek)}kg",
                        label = weekComparisonLabel(thisWeek, previousWeek),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            item { SectionHeader(title = "Badges") }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    achievements.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            row.forEach { display ->
                                BadgeCard(display, modifier = Modifier.weight(1f))
                            }
                            if (row.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            item { SectionHeader(title = "Personal records") }

            if (records.isEmpty()) {
                item {
                    Text(
                        "Log a few sessions to start building your personal-record list here.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(records, key = { it.exercise.id }) { record ->
                    RecordRow(record)
                }
            }
        }
    }
}

@Composable
private fun RecordRow(record: ExerciseRecord) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                IconBadge(icon = Icons.Filled.EmojiEvents, tint = LiftLogColors.hold, size = 34.dp)
                Text(
                    record.exercise.name,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(start = 12.dp)
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${formatKg(record.bestWeightKg)}kg best set", style = MaterialTheme.typography.labelLarge)
                Text(
                    "~${formatKg(record.bestEstimatedOneRepMaxKg)}kg est. 1RM",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun BadgeCard(display: AchievementDisplay, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = if (display.unlocked) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(
                if (display.unlocked) Icons.Filled.WorkspacePremium else Icons.Filled.Lock,
                contentDescription = null,
                tint = if (display.unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                display.achievement.title,
                style = MaterialTheme.typography.labelLarge,
                color = if (display.unlocked) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.padding(top = 6.dp)
            )
            Text(
                display.achievement.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

private fun weekComparisonLabel(thisWeek: Double, previousWeek: Double): String = when {
    previousWeek <= 0.0 && thisWeek <= 0.0 -> "No sets logged yet"
    previousWeek <= 0.0 -> "First week logged"
    else -> {
        val percent = Math.round((thisWeek - previousWeek) / previousWeek * 100)
        when {
            percent > 0 -> "+$percent% vs last week"
            percent < 0 -> "$percent% vs last week"
            else -> "Same as last week"
        }
    }
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
