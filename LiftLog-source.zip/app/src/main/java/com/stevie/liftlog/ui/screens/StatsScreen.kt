package com.stevie.liftlog.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stevie.liftlog.repository.WorkoutRepository
import com.stevie.liftlog.ui.components.BottomDestination
import com.stevie.liftlog.ui.components.LiftLogBottomBar
import com.stevie.liftlog.viewmodel.ExerciseRecord
import com.stevie.liftlog.viewmodel.LiftLogViewModelFactory
import com.stevie.liftlog.viewmodel.StatsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    repository: WorkoutRepository,
    onOpenBodyWeight: () -> Unit,
    onNavigate: (BottomDestination) -> Unit
) {
    val viewModel: StatsViewModel = viewModel(factory = LiftLogViewModelFactory(repository))
    val streakDays by viewModel.streakDays.collectAsStateWithLifecycle()
    val thisWeek by viewModel.thisWeekVolumeKg.collectAsStateWithLifecycle()
    val previousWeek by viewModel.previousWeekVolumeKg.collectAsStateWithLifecycle()
    val records by viewModel.personalRecords.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Stats") },
                actions = {
                    IconButton(onClick = onOpenBodyWeight) {
                        Icon(Icons.Filled.MonitorWeight, contentDescription = "Body weight")
                    }
                }
            )
        },
        bottomBar = { LiftLogBottomBar(current = BottomDestination.STATS, onSelect = onNavigate) }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Card(modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "Streak",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                if (streakDays == 1) "1 day" else "$streakDays days",
                                style = MaterialTheme.typography.titleLarge
                            )
                        }
                    }
                    Card(modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "This week",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text("${formatKg(thisWeek)}kg", style = MaterialTheme.typography.titleLarge)
                            Text(
                                weekComparisonLabel(thisWeek, previousWeek),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                Text("Personal records", style = MaterialTheme.typography.titleMedium)
            }

            if (records.isEmpty()) {
                item {
                    Text(
                        "Log a few sessions to start building your personal-record list here.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(records, key = { it.exercise.id }) { record ->
                    RecordRow(record)
                }
            }
        }
    }
}

@Composable
private fun RecordRow(record: ExerciseRecord) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(record.exercise.name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Text("${formatKg(record.bestWeightKg)}kg best set", style = MaterialTheme.typography.labelLarge)
                Text(
                    "~${formatKg(record.bestEstimatedOneRepMaxKg)}kg est. 1RM",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun weekComparisonLabel(thisWeek: Double, previousWeek: Double): String = when {
    previousWeek <= 0.0 && thisWeek <= 0.0 -> "No sets logged yet"
    previousWeek <= 0.0 -> "First week logged"
    else -> {
        val percent = Math.round((thisWeek - previousWeek) / previousWeek * 100)
        when {
            percent > 0 -> "+$percent% vs last week"
            percent < 0 -> "$percent% vs last week"
            else -> "Same as last week"
        }
    }
}

private fun formatKg(value: Double): String =
    if (value == Math.floor(value)) value.toInt().toString() else value.toString()
