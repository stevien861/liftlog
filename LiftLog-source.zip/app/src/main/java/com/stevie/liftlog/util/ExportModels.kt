package com.stevie.liftlog.util

import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.data.SetEntryEntity
import kotlinx.serialization.Serializable

/**
 * Plain, JSON-friendly mirrors of the Room entities, used only for
 * export/import so the on-disk backup format doesn't silently change shape
 * if the Room schema evolves later.
 */
@Serializable
data class ExportedExercise(
    val id: Long,
    val name: String,
    val category: String,
    val targetRepRangeLow: Int,
    val targetRepRangeHigh: Int,
    val weightIncrementKg: Double,
    val isCustom: Boolean,
    val notes: String,
    val isArchived: Boolean
)

@Serializable
data class ExportedSet(
    val id: Long,
    val exerciseId: Long,
    val dateEpochDay: Long,
    val setNumber: Int,
    val weightKg: Double,
    val reps: Int,
    val notes: String
)

@Serializable
data class ExportPayload(
    val formatVersion: Int = 1,
    val exportedAtEpochDay: Long,
    val exercises: List<ExportedExercise>,
    val sets: List<ExportedSet>
)

fun ExerciseEntity.toExported() = ExportedExercise(
    id = id,
    name = name,
    category = category.name,
    targetRepRangeLow = targetRepRangeLow,
    targetRepRangeHigh = targetRepRangeHigh,
    weightIncrementKg = weightIncrementKg,
    isCustom = isCustom,
    notes = notes,
    isArchived = isArchived
)

fun ExportedExercise.toEntity(overrideId: Long? = null) = ExerciseEntity(
    id = overrideId ?: id,
    name = name,
    category = MuscleCategory.fromStorageName(category),
    targetRepRangeLow = targetRepRangeLow,
    targetRepRangeHigh = targetRepRangeHigh,
    weightIncrementKg = weightIncrementKg,
    isCustom = isCustom,
    notes = notes,
    isArchived = isArchived
)

fun SetEntryEntity.toExported() = ExportedSet(
    id = id,
    exerciseId = exerciseId,
    dateEpochDay = dateEpochDay,
    setNumber = setNumber,
    weightKg = weightKg,
    reps = reps,
    notes = notes
)

fun ExportedSet.toEntity(overrideId: Long? = null, overrideExerciseId: Long? = null) = SetEntryEntity(
    id = overrideId ?: id,
    exerciseId = overrideExerciseId ?: exerciseId,
    dateEpochDay = dateEpochDay,
    setNumber = setNumber,
    weightKg = weightKg,
    reps = reps,
    notes = notes
)
