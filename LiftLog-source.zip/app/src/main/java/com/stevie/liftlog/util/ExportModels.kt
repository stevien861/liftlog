package com.stevie.liftlog.util

import com.stevie.liftlog.data.BodyWeightEntity
import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.data.RoutineEntity
import com.stevie.liftlog.data.RoutineExerciseEntity
import com.stevie.liftlog.data.SetEntryEntity
import kotlinx.serialization.Serializable

/**
 * Plain, JSON-friendly mirrors of the Room entities, used only for
 * export/import so the on-disk backup format doesn't silently change shape
 * if the Room schema evolves later.
 */
@Serializable
data class ExportedExercise(
    val id: Long,
    val name: String,
    val category: String,
    val targetRepRangeLow: Int,
    val targetRepRangeHigh: Int,
    val weightIncrementKg: Double,
    val isCustom: Boolean,
    val notes: String,
    val isArchived: Boolean,
    // Defaulted so a backup written before target sets/starting weight existed still imports fine.
    val targetSets: Int = 3,
    val startingWeightKg: Double? = null
)

@Serializable
data class ExportedSet(
    val id: Long,
    val exerciseId: Long,
    val dateEpochDay: Long,
    val setNumber: Int,
    val weightKg: Double,
    val reps: Int,
    val notes: String
)

@Serializable
data class ExportedRoutine(
    val id: Long,
    val name: String,
    val isCustom: Boolean,
    val sortOrder: Int
)

@Serializable
data class ExportedRoutineExercise(
    val id: Long,
    val routineId: Long,
    val exerciseId: Long,
    val sortOrder: Int
)

@Serializable
data class ExportedBodyWeight(
    val id: Long,
    val dateEpochDay: Long,
    val weightKg: Double
)

@Serializable
data class ExportPayload(
    val formatVersion: Int = 3,
    val exportedAtEpochDay: Long,
    val exercises: List<ExportedExercise>,
    val sets: List<ExportedSet>,
    // Default to empty so a backup written by an older LiftLog version (before routines/body
    // weight existed) still imports fine - ignoreUnknownKeys on the Json instance handles the
    // reverse direction (a newer backup opened by an older app build).
    val routines: List<ExportedRoutine> = emptyList(),
    val routineExercises: List<ExportedRoutineExercise> = emptyList(),
    val bodyWeightEntries: List<ExportedBodyWeight> = emptyList()
)

fun ExerciseEntity.toExported() = ExportedExercise(
    id = id,
    name = name,
    category = category.name,
    targetRepRangeLow = targetRepRangeLow,
    targetRepRangeHigh = targetRepRangeHigh,
    weightIncrementKg = weightIncrementKg,
    isCustom = isCustom,
    notes = notes,
    isArchived = isArchived,
    targetSets = targetSets,
    startingWeightKg = startingWeightKg
)

fun ExportedExercise.toEntity(overrideId: Long? = null) = ExerciseEntity(
    id = overrideId ?: id,
    name = name,
    category = MuscleCategory.fromStorageName(category),
    targetRepRangeLow = targetRepRangeLow,
    targetRepRangeHigh = targetRepRangeHigh,
    weightIncrementKg = weightIncrementKg,
    isCustom = isCustom,
    notes = notes,
    isArchived = isArchived,
    targetSets = targetSets,
    startingWeightKg = startingWeightKg
)

fun SetEntryEntity.toExported() = ExportedSet(
    id = id,
    exerciseId = exerciseId,
    dateEpochDay = dateEpochDay,
    setNumber = setNumber,
    weightKg = weightKg,
    reps = reps,
    notes = notes
)

fun ExportedSet.toEntity(overrideId: Long? = null, overrideExerciseId: Long? = null) = SetEntryEntity(
    id = overrideId ?: id,
    exerciseId = overrideExerciseId ?: exerciseId,
    dateEpochDay = dateEpochDay,
    setNumber = setNumber,
    weightKg = weightKg,
    reps = reps,
    notes = notes
)

fun RoutineEntity.toExported() = ExportedRoutine(id = id, name = name, isCustom = isCustom, sortOrder = sortOrder)

fun ExportedRoutine.toEntity(overrideId: Long? = null) = RoutineEntity(
    id = overrideId ?: id,
    name = name,
    isCustom = isCustom,
    sortOrder = sortOrder
)

fun RoutineExerciseEntity.toExported() = ExportedRoutineExercise(
    id = id,
    routineId = routineId,
    exerciseId = exerciseId,
    sortOrder = sortOrder
)

fun ExportedRoutineExercise.toEntity(overrideId: Long? = null, overrideRoutineId: Long? = null, overrideExerciseId: Long? = null) =
    RoutineExerciseEntity(
        id = overrideId ?: id,
        routineId = overrideRoutineId ?: routineId,
        exerciseId = overrideExerciseId ?: exerciseId,
        sortOrder = sortOrder
    )

fun BodyWeightEntity.toExported() = ExportedBodyWeight(id = id, dateEpochDay = dateEpochDay, weightKg = weightKg)

fun ExportedBodyWeight.toEntity(overrideId: Long? = null) = BodyWeightEntity(
    id = overrideId ?: id,
    dateEpochDay = dateEpochDay,
    weightKg = weightKg
)
