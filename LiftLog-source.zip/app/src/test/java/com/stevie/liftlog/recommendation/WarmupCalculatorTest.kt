package com.stevie.liftlog.recommendation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Scenarios verified against a standalone Python mirror before being ported here. */
class WarmupCalculatorTest {

    @Test
    fun `at or below bar weight suggests no warmup`() {
        assertTrue(WarmupCalculator.suggest(20.0).isEmpty())
        assertTrue(WarmupCalculator.suggest(15.0).isEmpty())
    }

    @Test
    fun `a moderate working weight suggests an ascending ramp with descending reps`() {
        val sets = WarmupCalculator.suggest(100.0)
        assertEquals(3, sets.size)
        assertEquals(40.0, sets[0].weightKg, 0.001)
        assertEquals(8, sets[0].reps)
        assertEquals(60.0, sets[1].weightKg, 0.001)
        assertEquals(5, sets[1].reps)
        assertEquals(80.0, sets[2].weightKg, 0.001)
        assertEquals(3, sets[2].reps)
    }

    @Test
    fun `weights below the bar are dropped rather than shown as bar-only sets`() {
        // 40% of 40kg is 16kg, below a 20kg bar - that step should be skipped entirely.
        val sets = WarmupCalculator.suggest(40.0)
        assertTrue(sets.all { it.weightKg > 20.0 })
    }

    @Test
    fun `suggested weights are always below the working weight`() {
        val sets = WarmupCalculator.suggest(140.0)
        assertTrue(sets.all { it.weightKg < 140.0 })
    }
}
