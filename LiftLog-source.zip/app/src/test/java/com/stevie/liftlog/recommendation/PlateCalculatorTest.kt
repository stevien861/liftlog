package com.stevie.liftlog.recommendation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Scenarios verified against a standalone Python mirror before being ported here. */
class PlateCalculatorTest {

    @Test
    fun `at or below bar weight needs no plates`() {
        val result = PlateCalculator.calculate(targetWeightKg = 10.0)
        assertTrue(result.platesPerSide.isEmpty())
        assertEquals(20.0, result.achievedTotalKg, 0.001)

        val exact = PlateCalculator.calculate(targetWeightKg = 20.0)
        assertTrue(exact.platesPerSide.isEmpty())
    }

    @Test
    fun `55kg loads 15 and 2point5 per side`() {
        val result = PlateCalculator.calculate(targetWeightKg = 55.0)
        assertEquals(listOf(15.0, 2.5), result.platesPerSide)
        assertEquals(55.0, result.achievedTotalKg, 0.001)
        assertTrue(result.isExact)
    }

    @Test
    fun `100kg loads heaviest plates first`() {
        val result = PlateCalculator.calculate(targetWeightKg = 100.0)
        assertEquals(listOf(25.0, 15.0), result.platesPerSide)
        assertTrue(result.isExact)
    }

    @Test
    fun `140kg needs two 25s and a 10 per side`() {
        val result = PlateCalculator.calculate(targetWeightKg = 140.0)
        assertEquals(listOf(25.0, 25.0, 10.0), result.platesPerSide)
        assertEquals(140.0, result.achievedTotalKg, 0.001)
    }

    @Test
    fun `a target unreachable with 1point25kg plates rounds down and is not exact`() {
        val result = PlateCalculator.calculate(targetWeightKg = 101.25)
        assertEquals(100.0, result.achievedTotalKg, 0.001)
        assertFalse(result.isExact)
    }
}
