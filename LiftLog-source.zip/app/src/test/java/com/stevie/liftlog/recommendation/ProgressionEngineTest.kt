package com.stevie.liftlog.recommendation

import com.stevie.liftlog.data.ExerciseEntity
import com.stevie.liftlog.data.MuscleCategory
import com.stevie.liftlog.data.SetEntryEntity
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Unit tests for the progressive-overload logic. These run on the plain JVM
 * (no emulator/device needed): `./gradlew testDebugUnitTest`.
 *
 * The scenarios here were verified against a standalone re-implementation of
 * the same logic before being ported into ProgressionEngine.kt, and are
 * mirrored here as real Kotlin/JUnit tests so `./gradlew test` keeps them
 * honest going forward.
 */
class ProgressionEngineTest {

    private fun exercise(low: Int = 8, high: Int = 12, increment: Double = 2.5) = ExerciseEntity(
        id = 1,
        name = "Test Exercise",
        category = MuscleCategory.CHEST,
        targetRepRangeLow = low,
        targetRepRangeHigh = high,
        weightIncrementKg = increment
    )

    private fun set(date: Long, weight: Double, reps: Int, setNumber: Int = 1) = SetEntryEntity(
        exerciseId = 1,
        dateEpochDay = date,
        setNumber = setNumber,
        weightKg = weight,
        reps = reps
    )

    @Test
    fun `no history returns insufficient data`() {
        val result = ProgressionEngine.recommend(exercise(), emptyList())
        assertEquals(RecommendationAction.INSUFFICIENT_DATA, result.action)
    }

    @Test
    fun `hitting the top rep target on every working set recommends an increase`() {
        val history = listOf(
            set(1, 60.0, 12, 1),
            set(1, 60.0, 12, 2),
            set(1, 60.0, 13, 3)
        )
        val result = ProgressionEngine.recommend(exercise(), history)
        assertEquals(RecommendationAction.INCREASE, result.action)
        assertEquals(62.5, result.suggestedWeightKg!!, 0.001)
    }

    @Test
    fun `reps inside range but below top holds the weight`() {
        val history = listOf(
            set(1, 60.0, 10, 1),
            set(1, 60.0, 9, 2),
            set(1, 60.0, 10, 3)
        )
        val result = ProgressionEngine.recommend(exercise(), history)
        assertEquals(RecommendationAction.HOLD, result.action)
        assertEquals(60.0, result.suggestedWeightKg!!, 0.001)
    }

    @Test
    fun `first miss below the rep floor holds rather than deloads`() {
        val history = listOf(
            set(1, 60.0, 7, 1),
            set(1, 60.0, 8, 2)
        )
        val result = ProgressionEngine.recommend(exercise(), history)
        assertEquals(RecommendationAction.HOLD, result.action)
        assertEquals(60.0, result.suggestedWeightKg!!, 0.001)
    }

    @Test
    fun `missing the rep floor two sessions running at the same weight recommends a deload`() {
        val history = listOf(
            set(1, 60.0, 6, 1),
            set(1, 60.0, 7, 2),
            set(2, 60.0, 7, 1),
            set(2, 60.0, 6, 2)
        )
        val result = ProgressionEngine.recommend(exercise(), history)
        assertEquals(RecommendationAction.DECREASE, result.action)
        assertEquals(54.0, result.suggestedWeightKg!!, 0.001) // 60 * 0.9, rounded to nearest 0.5
    }

    @Test
    fun `missing reps right after a weight increase does not trigger a deload`() {
        val history = listOf(
            set(1, 57.5, 12, 1),
            set(1, 57.5, 12, 2),
            set(2, 60.0, 7, 1),
            set(2, 60.0, 6, 2)
        )
        val result = ProgressionEngine.recommend(exercise(), history)
        assertEquals(RecommendationAction.HOLD, result.action)
        assertEquals(60.0, result.suggestedWeightKg!!, 0.001)
    }

    @Test
    fun `warmup sets below the working weight are ignored`() {
        val history = listOf(
            set(1, 20.0, 12, 1),
            set(1, 40.0, 12, 2),
            set(1, 60.0, 12, 3),
            set(1, 60.0, 13, 4)
        )
        val result = ProgressionEngine.recommend(exercise(), history)
        assertEquals(RecommendationAction.INCREASE, result.action)
    }
}
