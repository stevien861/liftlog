package com.stevie.liftlog.achievements

import org.junit.Assert.assertEquals
import org.junit.Test

/** Scenarios verified against a standalone Python mirror before being ported here. */
class AchievementEngineTest {

    private fun baseProgress(
        hasLoggedAnySet: Boolean = false,
        streakDays: Int = 0,
        recordsBrokenCount: Int = 0,
        hasCustomRoutine: Boolean = false,
        workoutsCompletedCount: Int = 0,
        plateCalculatorUsesCount: Int = 0,
        bodyWeightEntryCount: Int = 0,
        categoriesWithSetsCount: Int = 0,
        totalCategoryCount: Int = 6
    ) = AchievementProgress(
        hasLoggedAnySet, streakDays, recordsBrokenCount, hasCustomRoutine, workoutsCompletedCount,
        plateCalculatorUsesCount, bodyWeightEntryCount, categoriesWithSetsCount, totalCategoryCount
    )

    @Test
    fun `nothing unlocked from a totally fresh install`() {
        assertEquals(emptySet<AchievementId>(), AchievementEngine.unlockedIds(baseProgress()))
    }

    @Test
    fun `logging one set unlocks First Steps only`() {
        val unlocked = AchievementEngine.unlockedIds(baseProgress(hasLoggedAnySet = true))
        assertEquals(setOf(AchievementId.FIRST_SET), unlocked)
    }

    @Test
    fun `streak thresholds are inclusive at 7 and 30 and not before`() {
        assertEquals(
            setOf(AchievementId.FIRST_SET),
            AchievementEngine.unlockedIds(baseProgress(hasLoggedAnySet = true, streakDays = 6))
        )
        assertEquals(
            setOf(AchievementId.FIRST_SET, AchievementId.WEEK_STREAK),
            AchievementEngine.unlockedIds(baseProgress(hasLoggedAnySet = true, streakDays = 7))
        )
        assertEquals(
            setOf(AchievementId.FIRST_SET, AchievementId.WEEK_STREAK, AchievementId.MONTH_STREAK),
            AchievementEngine.unlockedIds(baseProgress(hasLoggedAnySet = true, streakDays = 30))
        )
    }

    @Test
    fun `record thresholds are inclusive at 1 and 10`() {
        assertEquals(
            setOf(AchievementId.FIRST_RECORD),
            AchievementEngine.unlockedIds(baseProgress(recordsBrokenCount = 9))
        )
        assertEquals(
            setOf(AchievementId.FIRST_RECORD, AchievementId.RECORD_COLLECTOR),
            AchievementEngine.unlockedIds(baseProgress(recordsBrokenCount = 10))
        )
    }

    @Test
    fun `a custom routine unlocks Routine Builder`() {
        assertEquals(
            setOf(AchievementId.ROUTINE_BUILDER),
            AchievementEngine.unlockedIds(baseProgress(hasCustomRoutine = true))
        )
    }

    @Test
    fun `workout count thresholds are inclusive at 10 and 50`() {
        assertEquals(emptySet<AchievementId>(), AchievementEngine.unlockedIds(baseProgress(workoutsCompletedCount = 9)))
        assertEquals(
            setOf(AchievementId.TEN_WORKOUTS),
            AchievementEngine.unlockedIds(baseProgress(workoutsCompletedCount = 10))
        )
        assertEquals(
            setOf(AchievementId.TEN_WORKOUTS, AchievementId.FIFTY_WORKOUTS),
            AchievementEngine.unlockedIds(baseProgress(workoutsCompletedCount = 50))
        )
    }

    @Test
    fun `plate calculator threshold is inclusive at 5`() {
        assertEquals(emptySet<AchievementId>(), AchievementEngine.unlockedIds(baseProgress(plateCalculatorUsesCount = 4)))
        assertEquals(
            setOf(AchievementId.PLATE_MASTER),
            AchievementEngine.unlockedIds(baseProgress(plateCalculatorUsesCount = 5))
        )
    }

    @Test
    fun `body weight threshold is inclusive at 7`() {
        assertEquals(emptySet<AchievementId>(), AchievementEngine.unlockedIds(baseProgress(bodyWeightEntryCount = 6)))
        assertEquals(
            setOf(AchievementId.BODY_AWARE),
            AchievementEngine.unlockedIds(baseProgress(bodyWeightEntryCount = 7))
        )
    }

    @Test
    fun `all rounder needs a set logged in every category, not just most`() {
        assertEquals(
            emptySet<AchievementId>(),
            AchievementEngine.unlockedIds(baseProgress(categoriesWithSetsCount = 5, totalCategoryCount = 6))
        )
        assertEquals(
            setOf(AchievementId.ALL_ROUNDER),
            AchievementEngine.unlockedIds(baseProgress(categoriesWithSetsCount = 6, totalCategoryCount = 6))
        )
    }

    @Test
    fun `everything unlocked at once`() {
        val progress = AchievementProgress(
            hasLoggedAnySet = true,
            streakDays = 30,
            recordsBrokenCount = 10,
            hasCustomRoutine = true,
            workoutsCompletedCount = 50,
            plateCalculatorUsesCount = 5,
            bodyWeightEntryCount = 7,
            categoriesWithSetsCount = 6,
            totalCategoryCount = 6
        )
        assertEquals(AchievementId.entries.toSet(), AchievementEngine.unlockedIds(progress))
    }
}
