package com.stevie.liftlog.stats

import com.stevie.liftlog.data.SetEntryEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for personal-record and streak/volume math. Scenarios were verified against a
 * standalone Python mirror before being ported here, same approach as ProgressionEngineTest.
 */
class WorkoutStatsTest {

    private fun set(exerciseId: Long, date: Long, weight: Double, reps: Int) = SetEntryEntity(
        exerciseId = exerciseId,
        dateEpochDay = date,
        setNumber = 1,
        weightKg = weight,
        reps = reps
    )

    // ---- PersonalRecords ---------------------------------------------------

    @Test
    fun `estimated one rep max uses the actual weight for a single rep`() {
        assertEquals(100.0, PersonalRecords.estimatedOneRepMax(100.0, 1), 0.001)
    }

    @Test
    fun `estimated one rep max grows with reps via the Epley formula`() {
        assertEquals(116.666, PersonalRecords.estimatedOneRepMax(100.0, 5), 0.01)
        assertEquals(133.333, PersonalRecords.estimatedOneRepMax(100.0, 10), 0.01)
    }

    @Test
    fun `no prior history means no records - it's a baseline, not a PR`() {
        val newSet = set(1, 10, 100.0, 5)
        val records = PersonalRecords.checkForNewRecords(emptyList(), newSet)
        assertTrue(records.isEmpty())
    }

    @Test
    fun `heavier than ever before is a heaviest-weight record`() {
        val prior = listOf(set(1, 1, 80.0, 5))
        val newSet = set(1, 2, 90.0, 5)
        val records = PersonalRecords.checkForNewRecords(prior, newSet)
        assertTrue(records.any { it.type == RecordType.HEAVIEST_WEIGHT })
    }

    @Test
    fun `same weight for more reps is a 1RM record but not a weight record`() {
        val prior = listOf(set(1, 1, 80.0, 5))
        val newSet = set(1, 2, 80.0, 10)
        val records = PersonalRecords.checkForNewRecords(prior, newSet)
        assertTrue(records.any { it.type == RecordType.BEST_ESTIMATED_ONE_REP_MAX })
        assertTrue(records.none { it.type == RecordType.HEAVIEST_WEIGHT })
    }

    @Test
    fun `a lighter, lower-rep set breaks no records`() {
        val prior = listOf(set(1, 1, 80.0, 10))
        val newSet = set(1, 2, 60.0, 5)
        val records = PersonalRecords.checkForNewRecords(prior, newSet)
        assertTrue(records.isEmpty())
    }

    // ---- WorkoutStats --------------------------------------------------------

    @Test
    fun `streak is zero with no workouts logged`() {
        assertEquals(0, WorkoutStats.computeStreakDays(emptySet(), 20_000L))
    }

    @Test
    fun `streak counts today when today has a workout`() {
        assertEquals(1, WorkoutStats.computeStreakDays(setOf(20_000L), 20_000L))
    }

    @Test
    fun `streak still counts through yesterday when today has no workout yet`() {
        assertEquals(1, WorkoutStats.computeStreakDays(setOf(19_999L), 20_000L))
    }

    @Test
    fun `streak resets after a full missed day`() {
        assertEquals(0, WorkoutStats.computeStreakDays(setOf(19_998L), 20_000L))
    }

    @Test
    fun `streak counts a consecutive run ending today`() {
        val dates = setOf(20_000L, 19_999L, 19_998L, 19_997L, 19_996L)
        assertEquals(5, WorkoutStats.computeStreakDays(dates, 20_000L))
    }

    @Test
    fun `total volume is weight times reps summed across sets`() {
        val sets = listOf(set(1, 1, 100.0, 5), set(1, 1, 100.0, 5), set(2, 1, 50.0, 10))
        assertEquals(1500.0, WorkoutStats.totalVolumeKg(sets), 0.001)
    }

    @Test
    fun `volume in last N days excludes sets outside the window`() {
        val sets = listOf(
            set(1, 100, 100.0, 5), // in window
            set(1, 90, 100.0, 5) // 10 days before day 100, outside a 7-day window ending on day 100
        )
        val volume = WorkoutStats.volumeInLastNDays(sets, todayEpochDay = 100, days = 7)
        assertEquals(500.0, volume, 0.001)
    }
}
