# LiftLog

A native Android app (Kotlin + Jetpack Compose) for tracking your weight
lifting progress: exercises organised into Back, Chest, Arms, Shoulders,
Forearms and Legs; sets logged per day; progress history and a simple chart
per exercise; and a built-in recommendation for when to move weight up or
down.

## Getting the APK without installing anything

This repo includes `.github/workflows/build-apk.yml`, a GitHub Actions
workflow that builds an installable APK in the cloud - no Android Studio, no
SDK, nothing installed on your own machine. Every push to `main` (or running
it manually from the Actions tab) produces `app-debug.apk` and attaches it to
a release tagged **apk-latest** at:

```
https://github.com/<your-username>/<this-repo>/releases/tag/apk-latest
```

That link stays up to date with the newest successful build - open it
directly from your Android phone's browser, tap `app-debug.apk` to download
it, then open the download to install (you'll need to allow "install unknown
apps" for whichever app you downloaded it with, e.g. Chrome). The workflow
also runs the unit tests in
`app/src/test/java/com/stevie/liftlog/recommendation/ProgressionEngineTest.kt`
on every build.

## Getting started in Android Studio (optional)

If you do get access to Android Studio later, you can still open and edit
the project normally:

1. Install [Android Studio](https://developer.android.com/studio) (this was
   built against Android Studio Koala/Ladybug-era tooling - anything fairly
   recent will work).
2. Open this folder (`LiftLog/`) as a project in Android Studio: **File ->
   Open** and select this folder.
3. **About the Gradle wrapper**: this project was generated in a sandboxed
   build environment with no internet access to Google's or Gradle's
   servers, so it ships `gradle/wrapper/gradle-wrapper.properties` (which
   tells Gradle which version to use, 8.7) but not the compiled
   `gradlew`/`gradlew.bat`/`gradle-wrapper.jar` files, since those can't be
   produced without downloading them. When you open the project, Android
   Studio will show a banner offering to generate the Gradle wrapper - click
   it (or go to **File -> Sync Project with Gradle Files**), and it'll set
   itself up automatically using your own internet connection. This is a
   one-time step.
4. Let Gradle sync (first sync downloads dependencies - AndroidX, Compose,
   Room, etc. - so it needs a normal internet connection and can take a few
   minutes).
5. Plug in your Android phone via USB (with USB debugging enabled in
   Developer Options), or start an emulator, and hit **Run**.

If you'd rather not use a phone over USB, **Build -> Generate Signed Bundle /
APK** produces an `.apk` you can copy to your phone and install directly
(you'll need to allow "install unknown apps" for whichever app you use to
open it).

## What it does

- **Categorised exercises.** Home screen shows the six muscle groups you
  asked for (Back, Chest, Arms, Shoulders, Forearms, Legs). Each comes
  pre-populated with common exercises (e.g. Deadlift, Bench Press, Overhead
  Press, Squat) so it's not empty on first launch - add your own from any
  category with the **+** button.
- **Daily logging.** Open an exercise, pick a date (defaults to today), and
  log each set's weight (kg) and reps. Sets are grouped into "sessions" by
  date automatically.
- **Progress tracking.** Each exercise screen shows a simple line chart of
  your top working weight per session, plus the full history underneath.
- **Weight recommendations.** See "How the recommendation works" below.
- **Backup / restore.** Settings -> Export saves everything (exercises +
  every logged set) to a JSON file you choose via Android's normal file
  picker - back it up to Drive, email it to yourself, whatever you like.
  Settings -> Import reads it back in, either replacing everything on the
  phone (for restoring onto a fresh install / new phone) or merging it in
  alongside what's already there.

## How the recommendation works

This is deliberately simple, transparent progressive overload logic rather
than anything opaque - you can read the whole thing in about two minutes at
`app/src/main/java/com/stevie/liftlog/recommendation/ProgressionEngine.kt`,
and its behaviour is pinned down by unit tests in
`app/src/test/java/com/stevie/liftlog/recommendation/ProgressionEngineTest.kt`
(run them with `./gradlew test`, no phone or emulator needed).

Each exercise has a target rep range (e.g. 8-12) and a weight increment
(e.g. +2.5kg) - both editable per exercise, since a heavy compound lift and
a small isolation move should progress differently. The logic looks at your
most recent logged session for that exercise:

1. **Hit the top of your rep range on every working set?** -> recommends
   adding weight (by the configured increment) next time. That's the reward
   for progressive overload.
2. **Missed the bottom of your rep range, and you also missed it at the same
   weight the session before?** -> recommends a ~10% deload, to let reps
   (and form) recover before pushing weight again.
3. **Missed the rep range, but only for the first time at this weight?** ->
   recommends repeating the same weight rather than jumping straight to a
   deload - one rough session doesn't mean the weight is wrong.
4. **Landed inside the rep range but not at the top?** -> recommends holding
   the weight and working on adding reps.
5. **No sessions logged yet** -> says so, rather than guessing.

Only sets at your session's heaviest weight count toward this ("working
sets") - lighter warm-up sets are ignored automatically.

This mirrors standard beginner/intermediate linear progression (similar in
spirit to programmes like Starting Strength or StrongLifts): add weight on
success, repeat on a one-off miss, deload on a repeated miss. It intentionally
doesn't try to be a full periodisation engine - if you outgrow it, the target
rep range and increment per exercise are exposed and editable, and the whole
recommendation function takes an exercise + its history and returns one
answer, so it's a small, self-contained place to extend later (e.g. adding
RPE-based logic) without touching the rest of the app.

## Project structure

```
app/src/main/java/com/stevie/liftlog/
  data/            Room entities, DAOs, database, default exercise seed list
  recommendation/  ProgressionEngine - the weight up/down/hold logic
  repository/      WorkoutRepository - the one place that talks to Room,
                   wires the recommendation engine to live data, and
                   handles JSON export/import
  viewmodel/       One ViewModel per screen family, plus a small hand-written
                   ViewModelProvider.Factory (no DI framework - this app is
                   small enough that Hilt would be more setup than it's worth)
  ui/
    screens/       CategoriesScreen, ExerciseListScreen, ExerciseDetailScreen,
                   SettingsScreen
    components/    RecommendationCard, ProgressLineChart (a small
                   dependency-free Canvas line chart - no external charting
                   library)
    navigation/    Single-Activity Navigation Compose graph
    theme/         Material 3 theme (supports Android 12+ dynamic colour,
                   falls back to a fixed blue/green palette on older phones)
```

All data is stored locally on your phone in a Room (SQLite) database - there
is no backend, no account, and nothing leaves your phone except when you
explicitly export a backup file.

## A note on how this was built

This project was generated and hand-reviewed in a sandboxed cloud
environment that has Java and Gradle but deliberately no access to Google's
Maven repository, Maven Central, or Gradle's own distribution servers - so a
real `./gradlew build` (or an emulator run) could not be executed here to
compile-verify it end to end. To compensate:

- The one piece of genuinely novel logic - the weight recommendation engine
  - was mirrored in a standalone Python script and run against ten edge
  cases (no data, hitting the top of the rep range, a first miss vs. a
  repeated miss at the same weight, missing right after a weight increase,
  warm-up sets being ignored, etc.) before being written into Kotlin, and
  the same scenarios are captured as real JUnit tests you can run yourself.
- Every source file was manually re-read for import correctness, and a
  bracket-balance sweep was run across the whole source tree.
- Library versions (Kotlin 1.9.24, AGP 8.5.2, Compose BOM 2024.06.00, Room
  2.6.1, Compose compiler 1.5.14, etc.) were chosen to be a known-compatible
  set as of when this was written, not verified by an actual build here.

In short: the logic has been checked as carefully as this environment
allows, but the very first Gradle sync you run in Android Studio is also
the first real compile this project has been through. If Android Studio
flags something on first sync (most likely a dependency version bump it
suggests, or the wrapper banner mentioned above), that's expected -
nothing here has been compiler-verified end to end yet.
